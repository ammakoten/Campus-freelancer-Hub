package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PesananSayaActivity extends AppCompatActivity {

    LinearLayout containerPesanan;
    ImageView btnBack;
    DatabaseHelper db;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesanan_saya);

        db = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        containerPesanan = findViewById(R.id.containerPesanan);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        loadPesanan();
    }

    private void loadPesanan() {
        containerPesanan.removeAllViews();
        Cursor cursor = db.getOrdersByClient(username);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String freelancer = cursor.getString(2);
                int serviceId = cursor.getInt(3);
                String serviceName = cursor.getString(4);
                String status = cursor.getString(5);
                String notes = cursor.getString(6);
                String resultFilePath = "";
                try {
                    resultFilePath = cursor.getString(10);
                } catch (Exception e) {
                    // Column might not exist if DB not upgraded properly or index issue
                }

                int rating = 0;
                try {
                    rating = cursor.getInt(9); // Assuming rating is at index 9 based on schema order
                } catch (Exception e) {
                    // Ignore
                }

                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerPesanan, false);

                TextView textNama = view.findViewById(R.id.textNamaJasa);
                TextView textHarga = view.findViewById(R.id.textHargaJasa);
                TextView textKategori = view.findViewById(R.id.textKategoriJasa);
                TextView textDeskripsi = view.findViewById(R.id.textDeskripsi);
                ImageView imgJasa = view.findViewById(R.id.imgJasaInfo);
                ImageView btnEdit = view.findViewById(R.id.btnEditJasa);
                ImageView btnDelete = view.findViewById(R.id.btnDeleteJasa);
                btnDelete.setVisibility(View.VISIBLE); // Clients can delete orders
                android.widget.Button btnDownload = view.findViewById(R.id.btnDownloadResult);
                android.widget.Button btnRate = view.findViewById(R.id.btnRate);
                TextView textRating = view.findViewById(R.id.textRating);

                // Display service name prominently
                textNama.setText(serviceName);
                textKategori.setText("Freelancer: " + freelancer);
                textHarga.setText("Status: " + status);

                // Display notes if available
                if (notes != null && !notes.isEmpty()) {
                    textDeskripsi.setText("Catatan: " + notes);
                    textDeskripsi.setVisibility(View.VISIBLE);
                } else {
                    textDeskripsi.setVisibility(View.GONE);
                }

                // Load service image
                Cursor jasaCursor = db.getJasaById(serviceId);
                if (jasaCursor != null && jasaCursor.moveToFirst()) {
                    String imagePath = jasaCursor.getColumnCount() > 6 ? jasaCursor.getString(6) : null;
                    if (imagePath != null && !imagePath.isEmpty()) {
                        java.io.File imageFile = new java.io.File(imagePath);
                        if (imageFile.exists()) {
                            imgJasa.setImageURI(android.net.Uri.fromFile(imageFile));
                            imgJasa.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        } else {
                            imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
                        }
                    } else {
                        imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
                    }
                    jasaCursor.close();
                } else {
                    imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
                }

                // Edit Notes
                btnEdit.setOnClickListener(v -> showEditDialog(id, notes));

                // Cancel Order
                btnDelete.setOnClickListener(v -> {
                    db.deleteOrder(id);
                    loadPesanan();
                    Toast.makeText(this, "Pesanan dibatalkan", Toast.LENGTH_SHORT).show();
                });

                // Download Result
                if (status.equals("Selesai") && resultFilePath != null && !resultFilePath.isEmpty()) {
                    btnDownload.setVisibility(View.VISIBLE);
                    String finalResultFilePath = resultFilePath;
                    btnDownload.setOnClickListener(v -> openFile(finalResultFilePath));
                } else {
                    btnDownload.setVisibility(View.GONE);
                }

                // Rating Logic
                if (status.equals("Selesai")) {
                    if (rating > 0) {
                        btnRate.setVisibility(View.GONE);
                        textRating.setVisibility(View.VISIBLE);
                        textRating.setText("Rating: " + rating + "/5");
                    } else {
                        btnRate.setVisibility(View.VISIBLE);
                        textRating.setVisibility(View.GONE);
                        btnRate.setOnClickListener(v -> showRatingDialog(id));
                    }
                } else {
                    btnRate.setVisibility(View.GONE);
                    textRating.setVisibility(View.GONE);
                }

                containerPesanan.addView(view);

            } while (cursor.moveToNext());
        }
    }

    private void openFile(String filePath) {
        if (filePath.startsWith("http://") || filePath.startsWith("https://")) {
            // Open URL in Browser
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
            intent.setData(android.net.Uri.parse(filePath));
            startActivity(intent);
        } else {
            // Existing Local File Logic
            java.io.File file = new java.io.File(filePath);
            if (file.exists()) {
                android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(this,
                        getApplicationContext().getPackageName() + ".fileprovider", file);

                android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "application/pdf"); // Default fallback

                String mimeType = "*/*";
                String extension = android.webkit.MimeTypeMap
                        .getFileExtensionFromUrl(android.net.Uri.fromFile(file).toString());
                if (extension != null) {
                    mimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                }
                if (mimeType != null) {
                    intent.setDataAndType(uri, mimeType);
                }

                intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);

                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "File tidak ditemukan / Link salah", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showEditDialog(int id, String currentNotes) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Catatan Pesanan");

        final EditText input = new EditText(this);
        input.setText(currentNotes);
        builder.setView(input);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            // We need a method to update notes, but currently only have updateOrderStatus.
            // I'll just update status to same status for now or add updateOrderNotes.
            // For simplicity and speed, I'll assume updateOrderStatus is enough or I should
            // add updateOrderNotes.
            // Let's add updateOrderNotes to DatabaseHelper quickly or just use raw query
            // here.
            // I'll use raw query here to avoid another file edit round trip if possible,
            // but cleaner to add method. I'll use raw query for speed.

            db.getWritableDatabase().execSQL("UPDATE orders SET notes=? WHERE id_order=?",
                    new Object[] { input.getText().toString(), id });
            loadPesanan();
            Toast.makeText(this, "Catatan diperbarui", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void showRatingDialog(int orderId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Beri Penilaian");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final android.widget.RatingBar ratingBar = new android.widget.RatingBar(this);
        ratingBar.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        ratingBar.setNumStars(5);
        ratingBar.setStepSize(1);
        layout.addView(ratingBar);

        builder.setView(layout);

        builder.setPositiveButton("Kirim", (dialog, which) -> {
            int rating = (int) ratingBar.getRating();
            if (rating > 0) {
                if (db.updateOrderRating(orderId, rating)) {
                    Toast.makeText(this, "Terima kasih atas penilaian Anda!", Toast.LENGTH_SHORT).show();
                    loadPesanan();
                    sendNotification("Rating Baru", "Anda menerima rating " + rating + " bintang!");
                } else {
                    Toast.makeText(this, "Gagal mengirim penilaian", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Mohon pilih bintang", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void sendNotification(String title, String content) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String channelId = "rating_notifications";
            CharSequence name = "Rating Notifications";
            String description = "Notifications for new ratings";
            int importance = android.app.NotificationManager.IMPORTANCE_HIGH;
            android.app.NotificationChannel channel = new android.app.NotificationChannel(channelId, name, importance);
            channel.setDescription(description);
            android.app.NotificationManager notificationManager = getSystemService(
                    android.app.NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        // Navigate to dashboard or generic page since we might not have a direct "View
        // Ratings" page
        android.content.Intent intent = new android.content.Intent(this, FreelancerActivity.class);
        intent.setFlags(
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);

        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(
                this, 0, intent,
                android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT);

        androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(this,
                "rating_notifications")
                .setSmallIcon(R.drawable.ic_notifications)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        androidx.core.app.NotificationManagerCompat notificationManager = androidx.core.app.NotificationManagerCompat
                .from(this);
        try {
            notificationManager.notify((int) System.currentTimeMillis(), builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }
}
