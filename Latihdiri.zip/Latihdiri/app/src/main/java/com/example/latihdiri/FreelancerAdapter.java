package com.example.latihdiri;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class FreelancerAdapter extends RecyclerView.Adapter<FreelancerAdapter.FreelancerViewHolder> {

    private Context context;
    private List<FreelancerItem> freelancerList;

    public FreelancerAdapter(Context context) {
        this.context = context;
        this.freelancerList = new ArrayList<>();
    }

    public void setFreelancers(List<FreelancerItem> freelancers) {
        this.freelancerList = freelancers;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FreelancerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_freelancer, parent, false);
        return new FreelancerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FreelancerViewHolder holder, int position) {
        FreelancerItem freelancer = freelancerList.get(position);

        holder.txtName.setText(freelancer.getUsername());

        // Display skills or "Freelancer" if no skills
        String skills = freelancer.getSkills();
        if (skills == null || skills.trim().isEmpty()) {
            holder.txtSkills.setText("Freelancer");
        } else {
            holder.txtSkills.setText(skills);
        }

        // Display rating
        DecimalFormat df = new DecimalFormat("#.#");
        holder.txtRating.setText(df.format(freelancer.getRating()));

        // Display Profile Image
        if (freelancer.getProfileImage() != null) {
            java.io.File f = new java.io.File(freelancer.getProfileImage());
            if (f.exists()) {
                holder.imgAvatar.setImageURI(android.net.Uri.fromFile(f));
                holder.imgAvatar.setImageTintList(null);
                holder.imgAvatar.setPadding(0, 0, 0, 0);
            } else {
                holder.imgAvatar.setImageResource(R.drawable.ic_person);
                holder.imgAvatar.setImageTintList(
                        androidx.core.content.ContextCompat.getColorStateList(context, R.color.text_secondary));
                int paddingDp = 8;
                float density = context.getResources().getDisplayMetrics().density;
                int paddingPixel = (int) (paddingDp * density);
                holder.imgAvatar.setPadding(paddingPixel, paddingPixel, paddingPixel, paddingPixel);
            }
        } else {
            holder.imgAvatar.setImageResource(R.drawable.ic_person);
            holder.imgAvatar.setImageTintList(
                    androidx.core.content.ContextCompat.getColorStateList(context, R.color.text_secondary));
            int paddingDp = 8;
            float density = context.getResources().getDisplayMetrics().density;
            int paddingPixel = (int) (paddingDp * density);
            holder.imgAvatar.setPadding(paddingPixel, paddingPixel, paddingPixel, paddingPixel);
        }
    }

    @Override
    public int getItemCount() {
        return freelancerList.size();
    }

    class FreelancerViewHolder extends RecyclerView.ViewHolder {
        TextView txtName, txtSkills, txtRating;
        ImageView imgAvatar;

        public FreelancerViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtFreelancerName);
            txtSkills = itemView.findViewById(R.id.txtFreelancerSkills);
            txtRating = itemView.findViewById(R.id.txtFreelancerRating);
            imgAvatar = itemView.findViewById(R.id.imgFreelancerAvatar);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    FreelancerItem item = freelancerList.get(position);
                    showFreelancerDetails(item);
                }
            });
        }

        private void showFreelancerDetails(FreelancerItem item) {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
            View dialogView = LayoutInflater.from(context).inflate(R.layout.item_freelancer, null); // Re-use layout or
                                                                                                    // simpler one
            // Ideally create a custom layout for dialog, but we can build it
            // programmatically or use a simple message for now as per "popup" request

            // Let's use a standard AlertDialog with message for simplicity and reliability,
            // or a custom view if we want the image. The user asked for "foto profil juga".
            // So a custom view is better.

            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(50, 40, 50, 40);
            layout.setGravity(android.view.Gravity.CENTER);

            ImageView img = new ImageView(context);
            int size = 200;
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.bottomMargin = 30;
            img.setLayoutParams(params);

            if (item.getProfileImage() != null) {
                java.io.File f = new java.io.File(item.getProfileImage());
                if (f.exists()) {
                    img.setImageURI(android.net.Uri.fromFile(f));
                    // Simple circle crop if possible, or just normal
                } else {
                    img.setImageResource(R.drawable.ic_person);
                }
            } else {
                img.setImageResource(R.drawable.ic_person);
            }
            layout.addView(img);

            TextView name = new TextView(context);
            name.setText(item.getUsername());
            name.setTextSize(20);
            name.setTypeface(null, android.graphics.Typeface.BOLD);
            name.setGravity(android.view.Gravity.CENTER);
            layout.addView(name);

            TextView details = new TextView(context);
            details.setText("\nEmail: " + (item.getEmail() != null ? item.getEmail() : "-") +
                    "\nNo HP: " + (item.getPhoneNumber() != null ? item.getPhoneNumber() : "-"));
            details.setTextSize(16);
            details.setGravity(android.view.Gravity.CENTER);
            layout.addView(details);

            builder.setView(layout);
            builder.setPositiveButton("Tutup", (dialog, which) -> dialog.dismiss());
            builder.setNeutralButton("Lihat Profil", (dialog, which) -> {
                android.app.AlertDialog.Builder imageDialogBuilder = new android.app.AlertDialog.Builder(context);
                ImageView fullImageView = new ImageView(context);
                fullImageView.setAdjustViewBounds(true);
                fullImageView.setPadding(20, 20, 20, 20);

                if (item.getProfileImage() != null) {
                    java.io.File f = new java.io.File(item.getProfileImage());
                    if (f.exists()) {
                        fullImageView.setImageURI(android.net.Uri.fromFile(f));
                    } else {
                        fullImageView.setImageResource(R.drawable.ic_person);
                    }
                } else {
                    fullImageView.setImageResource(R.drawable.ic_person);
                }

                imageDialogBuilder.setView(fullImageView);
                imageDialogBuilder.setPositiveButton("Tutup", (d, w) -> d.dismiss());
                imageDialogBuilder.show();
            });
            builder.show();
        }
    }

    // Data class for freelancer
    public static class FreelancerItem {
        private String username;
        private String skills;
        private double rating;
        private String profileImage;
        private String phoneNumber;
        private String email;

        public FreelancerItem(String username, String skills, double rating, String profileImage, String phoneNumber,
                String email) {
            this.username = username;
            this.skills = skills;
            this.rating = rating;
            this.profileImage = profileImage;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        public String getUsername() {
            return username;
        }

        public String getSkills() {
            return skills;
        }

        public double getRating() {
            return rating;
        }

        public String getProfileImage() {
            return profileImage;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public String getEmail() {
            return email;
        }
    }
}
