package com.example.latihdiri;

import android.util.Patterns;
import android.widget.EditText;
import com.google.android.material.textfield.TextInputLayout;

public class ValidationUtils {

    /**
     * Validate email format
     */
    public static boolean isValidEmail(String email) {
        return email != null && !email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    /**
     * Validate phone number (Indonesian format)
     */
    public static boolean isValidPhone(String phone) {
        if (phone == null || phone.isEmpty())
            return false;
        // Remove spaces and dashes
        String cleaned = phone.replaceAll("[\\s-]", "");
        // Indonesian phone: 10-13 digits, starts with 0 or +62
        return cleaned.matches("^(\\+62|62|0)[0-9]{9,12}$");
    }

    /**
     * Validate price (must be positive number)
     */
    public static boolean isValidPrice(String price) {
        if (price == null || price.isEmpty())
            return false;
        try {
            double p = Double.parseDouble(price);
            return p > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Validate required field
     */
    public static boolean isNotEmpty(String text) {
        return text != null && !text.trim().isEmpty();
    }

    /**
     * Validate minimum length
     */
    public static boolean hasMinLength(String text, int minLength) {
        return text != null && text.length() >= minLength;
    }

    /**
     * Validate maximum length
     */
    public static boolean hasMaxLength(String text, int maxLength) {
        return text != null && text.length() <= maxLength;
    }

    /**
     * Validate password strength
     */
    public static boolean isStrongPassword(String password) {
        if (password == null || password.length() < 6)
            return false;
        // At least 6 characters
        return true;
    }

    /**
     * Show error on TextInputLayout
     */
    public static void showError(TextInputLayout layout, String error) {
        if (layout != null) {
            layout.setError(error);
            layout.setErrorEnabled(true);
        }
    }

    /**
     * Clear error on TextInputLayout
     */
    public static void clearError(TextInputLayout layout) {
        if (layout != null) {
            layout.setError(null);
            layout.setErrorEnabled(false);
        }
    }

    /**
     * Validate EditText with TextInputLayout
     */
    public static boolean validateRequired(TextInputLayout layout, String fieldName) {
        EditText editText = layout.getEditText();
        if (editText == null)
            return false;

        String text = editText.getText().toString().trim();
        if (text.isEmpty()) {
            showError(layout, fieldName + " tidak boleh kosong");
            return false;
        }
        clearError(layout);
        return true;
    }

    /**
     * Validate email field
     */
    public static boolean validateEmail(TextInputLayout layout) {
        EditText editText = layout.getEditText();
        if (editText == null)
            return false;

        String email = editText.getText().toString().trim();
        if (email.isEmpty()) {
            showError(layout, "Email tidak boleh kosong");
            return false;
        }
        if (!isValidEmail(email)) {
            showError(layout, "Format email tidak valid");
            return false;
        }
        clearError(layout);
        return true;
    }

    /**
     * Validate phone field
     */
    public static boolean validatePhone(TextInputLayout layout) {
        EditText editText = layout.getEditText();
        if (editText == null)
            return false;

        String phone = editText.getText().toString().trim();
        if (phone.isEmpty()) {
            showError(layout, "Nomor telepon tidak boleh kosong");
            return false;
        }
        if (!isValidPhone(phone)) {
            showError(layout, "Format nomor telepon tidak valid");
            return false;
        }
        clearError(layout);
        return true;
    }

    /**
     * Validate price field
     */
    public static boolean validatePrice(TextInputLayout layout) {
        EditText editText = layout.getEditText();
        if (editText == null)
            return false;

        String price = editText.getText().toString().trim();
        if (price.isEmpty()) {
            showError(layout, "Harga tidak boleh kosong");
            return false;
        }
        if (!isValidPrice(price)) {
            showError(layout, "Harga harus berupa angka positif");
            return false;
        }
        clearError(layout);
        return true;
    }

    /**
     * Validate password field
     */
    public static boolean validatePassword(TextInputLayout layout) {
        EditText editText = layout.getEditText();
        if (editText == null)
            return false;

        String password = editText.getText().toString();
        if (password.isEmpty()) {
            showError(layout, "Password tidak boleh kosong");
            return false;
        }
        if (!isStrongPassword(password)) {
            showError(layout, "Password minimal 6 karakter");
            return false;
        }
        clearError(layout);
        return true;
    }

    /**
     * Validate image file
     */
    public static boolean isValidImageFile(String filename) {
        if (filename == null || filename.isEmpty())
            return false;
        String lower = filename.toLowerCase();
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
                lower.endsWith(".png") || lower.endsWith(".gif") ||
                lower.endsWith(".webp");
    }

    /**
     * Format currency (Indonesian Rupiah)
     */
    public static String formatCurrency(double amount) {
        return String.format("Rp %,.0f", amount);
    }

    /**
     * Format currency from string
     */
    public static String formatCurrency(String amount) {
        try {
            double value = Double.parseDouble(amount);
            return formatCurrency(value);
        } catch (NumberFormatException e) {
            return "Rp 0";
        }
    }
}
