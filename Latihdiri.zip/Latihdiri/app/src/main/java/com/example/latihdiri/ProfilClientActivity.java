package com.example.latihdiri;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ProfilClientActivity extends AppCompatActivity {

    private ImageView imgBanner, btnBack, btnEditBanner, imgProfile;
    private CardView cardProfile;
    private TextView textName, textUsername;
    private TextView textPhone, textEmail;
    private Button btnEditProfile;
    private LinearLayout containerOrderHistory;

    private DatabaseHelper db;
    private String currentUsername;
    private int userId;
    private boolean isPickingBanner = false;

    private final ActivityResultLauncher<String> pickImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    String type = isPickingBanner ? "banner" : "avatar";
                    String filename = type + "_" + currentUsername + "_" + System.currentTimeMillis() + ".jpg";
                    String path = saveToInternalStorage(uri, filename);

                    if (path != null) {
                        if (isPickingBanner) {
                            db.updateUserBanner(currentUsername, path);
                            imgBanner.setImageURI(Uri.fromFile(new File(path)));
                        } else {
                            db.updateUserProfileImage(currentUsername, path);
                            imgProfile.setImageURI(Uri.fromFile(new File(path)));
                        }
                        Toast.makeText(this, "Gambar diperbarui", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_client);

        if (getSupportActionBar() != null)
            getSupportActionBar().hide();

        db = new DatabaseHelper(this);
        currentUsername = getIntent().getStringExtra("username");

        initializeViews();
        loadProfileData();
        setupListeners();
    }

    private void initializeViews() {
        imgBanner = findViewById(R.id.imgBanner);
        btnBack = findViewById(R.id.btnBack);
        btnEditBanner = findViewById(R.id.btnEditBanner);
        imgProfile = findViewById(R.id.imgProfile);
        cardProfile = findViewById(R.id.cardProfile);
        textName = findViewById(R.id.textName);
        textUsername = findViewById(R.id.textUsername);
        textPhone = findViewById(R.id.textPhone);
        textEmail = findViewById(R.id.textEmail);
        btnEditProfile = findViewById(R.id.btnEditProfile);
        containerOrderHistory = findViewById(R.id.containerOrderHistory);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnEditBanner.setOnClickListener(v -> {
            isPickingBanner = true;
            pickImage.launch("image/*");
        });

        cardProfile.setOnClickListener(v -> {
            isPickingBanner = false;
            pickImage.launch("image/*");
        });

        btnEditProfile.setOnClickListener(v -> showEditProfileDialog());

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            getSharedPreferences("UserSession", MODE_PRIVATE).edit().clear().apply();
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadProfileData() {
        // Load User Info
        Cursor cursor = db.getUserByUsername(currentUsername);
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
            // 1=username, 2=email ... 5=profile_image, 6=full_name, 7=phone,
            // 12=banner_image

            String username = cursor.getString(1);
            String email = cursor.getString(2);
            String profileImg = cursor.getString(5);

            String fullName = cursor.getColumnCount() > 6 ? cursor.getString(6) : username;
            String phone = cursor.getColumnCount() > 7 ? cursor.getString(7) : "-";
            String bannerImg = cursor.getColumnCount() > 12 ? cursor.getString(12) : null;

            textUsername.setText("@" + username);
            textEmail.setText(email);
            textName.setText((fullName != null && !fullName.isEmpty()) ? fullName : username);
            textPhone.setText((phone != null && !phone.isEmpty()) ? phone : "-");

            // Load Images
            if (profileImg != null) {
                File f = new File(profileImg);
                if (f.exists())
                    imgProfile.setImageURI(Uri.fromFile(f));
            }
            if (bannerImg != null) {
                File f = new File(bannerImg);
                if (f.exists())
                    imgBanner.setImageURI(Uri.fromFile(f));
            }
        }
        cursor.close();

        // Load Order History
        loadOrderHistory();
    }

    private void loadOrderHistory() {
        containerOrderHistory.removeAllViews();
        Cursor cursor = db.getOrdersByClient(currentUsername);
        if (cursor.moveToFirst()) {
            do {
                // Schema: 0id, 1client, 2freelancer, 3svcId, 4svcName, 5status, 6notes,
                // 7date...
                String freelancer = cursor.getString(2);
                String svcName = cursor.getString(4);
                String status = cursor.getString(5);
                String notes = cursor.getString(6);

                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerOrderHistory, false);
                TextView tName = view.findViewById(R.id.textNamaJasa);
                TextView tPrice = view.findViewById(R.id.textHargaJasa);
                TextView tCat = view.findViewById(R.id.textKategoriJasa);

                view.findViewById(R.id.btnEditJasa).setVisibility(View.GONE);
                view.findViewById(R.id.btnDeleteJasa).setVisibility(View.GONE);
                view.findViewById(R.id.imgJasaInfo).setVisibility(View.GONE); // Simplify

                tName.setText("Freelancer: " + freelancer); // Should ideally fetch full name
                tPrice.setText("Jasa: " + svcName);
                tCat.setText("Status: " + status);

                if (status.equals("Pending"))
                    tCat.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
                else if (status.equals("Selesai"))
                    tCat.setTextColor(getResources().getColor(android.R.color.holo_green_dark));

                containerOrderHistory.addView(view);

                // Click to viewing Freelancer Info (or Order Details)
                view.setOnClickListener(v -> showFreelancerDetailsDialog(freelancer, svcName, status));

                // RATING LOGIC
                // Check if Rating exists
                int rating = 0;
                if (cursor.getColumnCount() > 9) {
                    rating = cursor.getInt(9);
                }

                android.widget.Button btnRate = view.findViewById(R.id.btnRate);
                TextView textRating = view.findViewById(R.id.textRating);

                if ("Selesai".equals(status)) {
                    if (rating > 0) {
                        btnRate.setVisibility(View.GONE);
                        textRating.setVisibility(View.VISIBLE);
                        textRating.setText("Rating: " + rating + "/5");
                    } else {
                        textRating.setVisibility(View.GONE);
                        btnRate.setVisibility(View.VISIBLE);
                        int finalOrderId = cursor.getInt(0); // id_order
                        btnRate.setOnClickListener(v -> showRatingDialog(finalOrderId));
                    }
                } else {
                    btnRate.setVisibility(View.GONE);
                    textRating.setVisibility(View.GONE);
                }
            } while (cursor.moveToNext());
        } else {
            TextView empty = new TextView(this);
            empty.setText("Belum ada riwayat pesanan.");
            empty.setPadding(0, 10, 0, 10);
            containerOrderHistory.addView(empty);
        }
        cursor.close();
    }

    private void showEditProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Profil");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputName = new EditText(this);
        inputName.setHint("Nama Lengkap");
        inputName.setText(textName.getText().toString());
        layout.addView(inputName);

        final EditText inputPhone = new EditText(this);
        inputPhone.setHint("Nomor HP");
        inputPhone.setText(textPhone.getText().toString());
        inputPhone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        layout.addView(inputPhone);

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            // Using existing updateDetailedProfile but passing current bio/skills if any
            // (client has none usually)
            // Or create updateClientProfile. I'll pass empty/null for bio/skills which
            // updateDetailedProfile handles

            if (db.updateDetailedProfile(userId,
                    inputName.getText().toString(),
                    inputPhone.getText().toString(),
                    null, null)) { // Bio/Skills null so they might be cleared if query clears them, checking
                                   // DatabaseHelper...
                // DatabaseHelper updateDetailedProfile updates ALL fields. Ideally I should
                // fetch existing or handle nulls inside DB helper.
                // Current helper implementation overwrites.
                // Since updateDetailedProfile sets all 4 fields, passing null here might set
                // Bio/Skills to NULL in DB.
                // This is fine for Client as they don't use Bio/Skills.

                Toast.makeText(this, "Profil diperbarui", Toast.LENGTH_SHORT).show();
                loadProfileData();
            } else {
                Toast.makeText(this, "Gagal update", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private String saveToInternalStorage(Uri uri, String fileName) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), fileName);
            OutputStream outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void showRatingDialog(int orderId) {
        String[] ratings = { "1", "2", "3", "4", "5" };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Beri Rating");
        builder.setSingleChoiceItems(ratings, -1, (dialog, which) -> {
            int rating = Integer.parseInt(ratings[which]);
            if (db.updateOrderRating(orderId, rating)) {
                Toast.makeText(this, "Terima kasih atas rating Anda!", Toast.LENGTH_SHORT).show();
                loadOrderHistory(); // Refresh list
            } else {
                Toast.makeText(this, "Gagal mengirim rating", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        });
        builder.setNegativeButton("Batal", null);
        builder.show();
    }

    private void showFreelancerDetailsDialog(String freelancerUsername, String svcName, String status) {
        String phone = "-";
        String bio = "-";

        Cursor c = db.getUserByUsername(freelancerUsername);
        if (c.moveToFirst()) {
            if (c.getColumnCount() > 7)
                phone = c.getString(7);
            if (c.getColumnCount() > 8)
                bio = c.getString(8);
        }
        c.close();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Detail Freelancer");
        builder.setMessage("Freelancer: " + freelancerUsername + "\n" +
                "No HP: " + (phone != null && !phone.isEmpty() ? phone : "-") + "\n" +
                "Bio: " + (bio != null && !bio.isEmpty() ? bio : "-") + "\n\n" +
                "Jasa: " + svcName + "\n" +
                "Status Pesanan: " + status);
        builder.setPositiveButton("Tutup", null);
        builder.show();
    }
}
