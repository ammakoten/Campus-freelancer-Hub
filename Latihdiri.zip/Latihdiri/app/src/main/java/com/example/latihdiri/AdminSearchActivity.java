package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AdminSearchActivity extends AppCompatActivity {

    LinearLayout containerUsers, containerServices, containerOrders;
    TextView titleUsers, titleServices, titleOrders, textNoResults;
    EditText searchBar;
    ImageView btnBack;
    DatabaseHelper db;
    String adminUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_search);

        db = new DatabaseHelper(this);
        adminUsername = getIntent().getStringExtra("username");

        btnBack = findViewById(R.id.btnBack);
        searchBar = findViewById(R.id.searchBar);
        containerUsers = findViewById(R.id.containerUsers);
        containerServices = findViewById(R.id.containerServices);
        containerOrders = findViewById(R.id.containerOrders);
        titleUsers = findViewById(R.id.titleUsers);
        titleServices = findViewById(R.id.titleServices);
        titleOrders = findViewById(R.id.titleOrders);
        textNoResults = findViewById(R.id.textNoResults);

        btnBack.setOnClickListener(v -> finish());

        searchBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    performAdminSearch(s.toString());
                    searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, R.drawable.ic_close, 0);
                } else {
                    clearResults();
                    searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0);
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

        searchBar.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                if (searchBar.getCompoundDrawables()[2] != null) {
                    if (event.getRawX() >= (searchBar.getRight() - searchBar.getCompoundDrawables()[2].getBounds().width() - 50)) {
                        searchBar.setText("");
                        return true;
                    }
                }
            }
            return false;
        });

        // If there's an initial query
        String initialQuery = getIntent().getStringExtra("search_query");
        if (initialQuery != null && !initialQuery.isEmpty()) {
            searchBar.setText(initialQuery);
        }
    }

    private void clearResults() {
        containerUsers.removeAllViews();
        containerServices.removeAllViews();
        containerOrders.removeAllViews();
        titleUsers.setVisibility(View.GONE);
        titleServices.setVisibility(View.GONE);
        titleOrders.setVisibility(View.GONE);
        textNoResults.setText("Mulai mengetik untuk mencari...");
        textNoResults.setVisibility(View.VISIBLE);
    }

    private void performAdminSearch(String query) {
        containerUsers.removeAllViews();
        containerServices.removeAllViews();
        containerOrders.removeAllViews();

        boolean hasResults = false;

        // Search Users
        Cursor userCursor = db.searchUsers(query);
        if (userCursor != null && userCursor.getCount() > 0) {
            titleUsers.setVisibility(View.VISIBLE);
            hasResults = true;
            while (userCursor.moveToNext()) {
                addUserItem(userCursor);
            }
            userCursor.close();
        } else {
            titleUsers.setVisibility(View.GONE);
        }

        // Search Services
        Cursor serviceCursor = db.searchJasa(query);
        if (serviceCursor != null && serviceCursor.getCount() > 0) {
            titleServices.setVisibility(View.VISIBLE);
            hasResults = true;
            while (serviceCursor.moveToNext()) {
                addServiceItem(serviceCursor);
            }
            serviceCursor.close();
        } else {
            titleServices.setVisibility(View.GONE);
        }

        // Search Orders
        Cursor orderCursor = db.searchOrders(query);
        if (orderCursor != null && orderCursor.getCount() > 0) {
            titleOrders.setVisibility(View.VISIBLE);
            hasResults = true;
            while (orderCursor.moveToNext()) {
                addOrderItem(orderCursor);
            }
            orderCursor.close();
        } else {
            titleOrders.setVisibility(View.GONE);
        }

        if (hasResults) {
            textNoResults.setVisibility(View.GONE);
        } else {
            textNoResults.setText("Tidak ada hasil untuk \"" + query + "\"");
            textNoResults.setVisibility(View.VISIBLE);
        }
    }

    private void addUserItem(Cursor cursor) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_user_admin, containerUsers, false);
        TextView textName = view.findViewById(R.id.textUserName);
        TextView textRole = view.findViewById(R.id.textUserRole);
        TextView textEmail = view.findViewById(R.id.textUserEmail);
        ImageView imgProfile = view.findViewById(R.id.imgUserProfile);
        
        String name = cursor.getString(cursor.getColumnIndexOrThrow("username"));
        String role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
        String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
        String profileImage = cursor.getString(cursor.getColumnIndexOrThrow("profile_image"));

        textName.setText(name);
        textRole.setText(role);
        textEmail.setText(email);

        if (profileImage != null && !profileImage.isEmpty()) {
            java.io.File f = new java.io.File(profileImage);
            if (f.exists()) {
                imgProfile.setImageURI(android.net.Uri.fromFile(f));
                imgProfile.setImageTintList(null);
                imgProfile.setPadding(0, 0, 0, 0);
            }
        }

        view.setOnClickListener(v -> {
            Intent intent = new Intent(this, KelolaAkunUserActivity.class);
            startActivity(intent);
        });
        containerUsers.addView(view);
    }

    private void addServiceItem(Cursor cursor) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerServices, false);
        TextView textNama = view.findViewById(R.id.textNamaJasa);
        TextView textHarga = view.findViewById(R.id.textHargaJasa);
        TextView textKategori = view.findViewById(R.id.textKategoriJasa);
        ImageView imgJasa = view.findViewById(R.id.imgJasaInfo);
        
        String nama = cursor.getString(cursor.getColumnIndexOrThrow("nama_jasa"));
        String harga = cursor.getString(cursor.getColumnIndexOrThrow("harga"));
        String kategori = cursor.getString(cursor.getColumnIndexOrThrow("kategori"));
        String freelancer = cursor.getString(cursor.getColumnIndexOrThrow("username"));
        String imagePath = cursor.getString(cursor.getColumnIndexOrThrow("image_path"));

        textNama.setText(nama);
        textHarga.setText(ValidationUtils.formatCurrency(harga));
        textKategori.setText(kategori + " • by " + freelancer);

        if (imagePath != null && !imagePath.isEmpty()) {
            java.io.File f = new java.io.File(imagePath);
            if (f.exists()) {
                imgJasa.setImageURI(android.net.Uri.fromFile(f));
                imgJasa.setScaleType(ImageView.ScaleType.CENTER_CROP);
            }
        }

        view.findViewById(R.id.btnEditJasa).setVisibility(View.GONE);
        view.findViewById(R.id.btnDeleteJasa).setVisibility(View.GONE);

        view.setOnClickListener(v -> {
            Intent intent = new Intent(this, KelolaJasaFreelancerActivity.class);
            startActivity(intent);
        });
        containerServices.addView(view);
    }

    private void addOrderItem(Cursor cursor) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_order_admin, containerOrders, false);
        TextView textClientName = view.findViewById(R.id.textClientName);
        TextView textFreelancerName = view.findViewById(R.id.textFreelancerName);
        TextView textServiceName = view.findViewById(R.id.textServiceName);
        TextView textStatus = view.findViewById(R.id.textStatus);
        TextView textDate = view.findViewById(R.id.textDate);
        
        int id = cursor.getInt(cursor.getColumnIndexOrThrow("id_order"));
        String service = cursor.getString(cursor.getColumnIndexOrThrow("service_name"));
        String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
        String client = cursor.getString(cursor.getColumnIndexOrThrow("client_username"));
        String freelancer = cursor.getString(cursor.getColumnIndexOrThrow("freelancer_username"));
        long date = 0;
        try {
            date = Long.parseLong(cursor.getString(cursor.getColumnIndexOrThrow("date")));
        } catch (Exception e) {}

        textClientName.setText(client);
        textFreelancerName.setText("Freelancer: " + freelancer);
        textServiceName.setText(service + " (#" + id + ")");
        textStatus.setText("Status: " + status);
        
        if (date > 0) {
            textDate.setText(java.text.DateFormat.getDateInstance().format(new java.util.Date(date)));
        }

        view.findViewById(R.id.btnUpdateStatus).setVisibility(View.GONE);

        view.setOnClickListener(v -> {
            Intent intent = new Intent(this, KelolaPesananActivity.class);
            startActivity(intent);
        });
        containerOrders.addView(view);
    }
}
