package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class KelolaAkunUserActivity extends AppCompatActivity {

    LinearLayout containerUsers;
    ImageView btnAddUser, btnBack;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kelola_akun_user);

        db = new DatabaseHelper(this);

        containerUsers = findViewById(R.id.containerUsers);
        btnAddUser = findViewById(R.id.btnAddUser);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());
        btnAddUser.setOnClickListener(v -> showDialogAddEdit(null));

        loadUsers();
    }

    private void loadUsers() {
        containerUsers.removeAllViews();
        Cursor cursor = db.getAllUsers();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String username = cursor.getString(1);
                String email = cursor.getString(2);
                String role = cursor.getString(4);
                String profileImage = cursor.getString(5); // profile_image column

                View view = LayoutInflater.from(this).inflate(R.layout.item_user_admin, containerUsers, false);

                TextView textNama = view.findViewById(R.id.textUserName);
                TextView textEmail = view.findViewById(R.id.textUserEmail);
                TextView textRole = view.findViewById(R.id.textUserRole);
                ImageView imgProfile = view.findViewById(R.id.imgUserProfile);
                ImageView btnEdit = view.findViewById(R.id.btnEditUser);
                ImageView btnDelete = view.findViewById(R.id.btnDeleteUser);

                textNama.setText(username);
                textEmail.setText(email);
                textRole.setText(role);

                // Load Profile Image
                if (profileImage != null && !profileImage.isEmpty()) {
                    java.io.File f = new java.io.File(profileImage);
                    if (f.exists()) {
                        imgProfile.setImageURI(android.net.Uri.fromFile(f));
                        imgProfile.setImageTintList(null);
                        imgProfile.setPadding(0, 0, 0, 0);
                    } else {
                        imgProfile.setImageResource(R.drawable.ic_person);
                    }
                } else {
                    imgProfile.setImageResource(R.drawable.ic_person);
                }

                btnEdit.setOnClickListener(v -> showDialogAddEdit(id, username, email, role));
                btnDelete.setOnClickListener(v -> {
                    db.deleteUser(id);
                    loadUsers();
                    Toast.makeText(this, "User dihapus", Toast.LENGTH_SHORT).show();
                });

                containerUsers.addView(view);

            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void showDialogAddEdit(Integer id, String... data) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputUsername = new EditText(this);
        inputUsername.setHint("Username");
        layout.addView(inputUsername);

        final EditText inputEmail = new EditText(this);
        inputEmail.setHint("Email");
        layout.addView(inputEmail);

        final EditText inputPassword = new EditText(this);
        inputPassword.setHint("Password");
        layout.addView(inputPassword);

        final EditText inputRole = new EditText(this);
        inputRole.setHint("Role (Freelancer/Client/Admin)");
        layout.addView(inputRole);

        if (data != null && data.length > 0) {
            inputUsername.setText(data[0]);
            inputEmail.setText(data[1]);
            inputRole.setText(data[2]);
            inputPassword.setHint("Password (Leave empty to keep)");
            builder.setTitle("Edit User");
        } else {
            builder.setTitle("Tambah User");
        }

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            String user = inputUsername.getText().toString();
            String email = inputEmail.getText().toString();
            String pass = inputPassword.getText().toString();
            String role = inputRole.getText().toString();

            if (id == null) {
                if (db.insertUser(user, email, pass, role)) {
                    Toast.makeText(this, "Berhasil menambah user", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (db.updateUser(id, user, email, role)) {
                    Toast.makeText(this, "Berhasil update user", Toast.LENGTH_SHORT).show();
                }
            }
            loadUsers();
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}
