package com.example.latihdiri;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NotificationActivity extends AppCompatActivity {

    private RecyclerView recyclerNotifications;
    private NotificationAdapter adapter;
    private List<NotificationItem> notificationList;
    private DatabaseHelper db;
    private String currentUsername;
    private String currentRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        db = new DatabaseHelper(this);
        recyclerNotifications = findViewById(R.id.recyclerNotifications);
        recyclerNotifications.setLayoutManager(new LinearLayoutManager(this));

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        currentUsername = prefs.getString("username", "");
        currentRole = prefs.getString("role", "");

        if ("Admin".equalsIgnoreCase(currentRole)) {
            currentUsername = "admin";
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        loadNotifications();
    }

    private void loadNotifications() {
        notificationList = new ArrayList<>();

        // 1. Fetch Unread Messages
        Cursor cursorMessages = db.getUnreadMessages(currentUsername);
        if (cursorMessages != null && cursorMessages.moveToFirst()) {
            do {
                String sender = cursorMessages.getString(cursorMessages.getColumnIndexOrThrow("sender"));
                int count = cursorMessages.getInt(cursorMessages.getColumnIndexOrThrow("count"));
                String timestamp = cursorMessages.getString(cursorMessages.getColumnIndexOrThrow("timestamp"));

                notificationList.add(new NotificationItem(
                        "New Message",
                        "You have " + count + " unread message(s) from " + sender,
                        timestamp,
                        "message",
                        sender));
            } while (cursorMessages.moveToNext());
            cursorMessages.close();
        }

        // 2. Fetch Pending Orders (Based on Role)
        if ("Freelancers".equalsIgnoreCase(currentRole) || "freelancer".equalsIgnoreCase(currentRole)) {
            Cursor cursorOrders = db.getPendingOrders(currentUsername);
            if (cursorOrders != null && cursorOrders.moveToFirst()) {
                do {
                    int idOrder = cursorOrders.getInt(cursorOrders.getColumnIndexOrThrow("id_order"));
                    String client = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("client_username"));
                    String serviceName = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("service_name"));
                    String date = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("date"));

                    notificationList.add(new NotificationItem(
                            "New Order",
                            "New order for " + serviceName + " from " + client,
                            date,
                            "order",
                            String.valueOf(idOrder))); // Pass ID as extraData
                } while (cursorOrders.moveToNext());
                cursorOrders.close();
            }

            // 3. Fetch Unseen Ratings (Freelancer Only)
            Cursor cursorRatings = db.getUnseenRatings(currentUsername);
            if (cursorRatings != null && cursorRatings.moveToFirst()) {
                do {
                    int idOrder = cursorRatings.getInt(cursorRatings.getColumnIndexOrThrow("id_order"));
                    String client = cursorRatings.getString(cursorRatings.getColumnIndexOrThrow("client_username"));
                    int rating = cursorRatings.getInt(cursorRatings.getColumnIndexOrThrow("rating"));
                    String date = cursorRatings.getString(cursorRatings.getColumnIndexOrThrow("date"));

                    notificationList.add(new NotificationItem(
                            "New Rating",
                            "Client " + client + " gave you " + rating + " stars!",
                            date,
                            "rating",
                            String.valueOf(idOrder)));
                } while (cursorRatings.moveToNext());
                cursorRatings.close();
            }
        } else if ("Admin".equalsIgnoreCase(currentRole)) {
            Cursor cursorOrders = db.getAllPendingOrders();
            if (cursorOrders != null && cursorOrders.moveToFirst()) {
                do {
                    int idOrder = cursorOrders.getInt(cursorOrders.getColumnIndexOrThrow("id_order"));
                    String client = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("client_username"));
                    String serviceName = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("service_name"));
                    String date = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("date"));

                    notificationList.add(new NotificationItem(
                            "New Order (Admin)",
                            "Client " + client + " ordered " + serviceName,
                            date,
                            "order",
                            String.valueOf(idOrder))); // Pass ID as extraData
                } while (cursorOrders.moveToNext());
                cursorOrders.close();
            }
        } else {
            // Client Role: Check for Completed Orders
            Cursor cursorOrders = db.getCompletedOrders(currentUsername);
            if (cursorOrders != null && cursorOrders.moveToFirst()) {
                do {
                    int idOrder = cursorOrders.getInt(cursorOrders.getColumnIndexOrThrow("id_order"));
                    String freelancer = cursorOrders
                            .getString(cursorOrders.getColumnIndexOrThrow("freelancer_username"));
                    String serviceName = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("service_name"));
                    String date = cursorOrders.getString(cursorOrders.getColumnIndexOrThrow("date"));

                    notificationList.add(new NotificationItem(
                            "Order Completed",
                            "Your order for " + serviceName + " is ready!",
                            date,
                            "order_completed",
                            String.valueOf(idOrder)));
                } while (cursorOrders.moveToNext());
                cursorOrders.close();
            }
        }

        adapter = new NotificationAdapter(notificationList);
        recyclerNotifications.setAdapter(adapter);
    }

    // Inner Class for Notification Item Model
    private static class NotificationItem {
        String title;
        String message;
        String timestamp;
        String type; // "message" or "order"
        String extraData; // sender username for messages, order ID for orders

        public NotificationItem(String title, String message, String timestamp, String type, String extraData) {
            this.title = title;
            this.message = message;
            this.timestamp = timestamp;
            this.type = type;
            this.extraData = extraData;
        }
    }

    // Inner Class for Adapter
    private class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

        private List<NotificationItem> list;

        public NotificationAdapter(List<NotificationItem> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            NotificationItem item = list.get(position);
            holder.textTitle.setText(item.title);
            holder.textMessage.setText(item.message);

            // Format timestamp (Simple implementation)
            try {
                long time = Long.parseLong(item.timestamp);
                holder.textTime.setText(android.text.format.DateUtils.getRelativeTimeSpanString(time));
            } catch (Exception e) {
                holder.textTime.setText("Just now");
            }

            if (item.type.equals("message")) {
                holder.imgIcon.setImageResource(R.drawable.ic_notifications); // Or chat icon
            } else if (item.type.equals("rating")) {
                holder.imgIcon.setImageResource(R.drawable.ic_star); // Or star icon if available, otherwise default
            } else {
                holder.imgIcon.setImageResource(R.drawable.ic_pesanan_masuk);
            }

            holder.itemView.setOnClickListener(v -> {
                if (item.type.equals("message")) {
                    // Open Chat
                    Intent intent = new Intent(NotificationActivity.this, ChatActivity.class);
                    intent.putExtra("target_user", item.extraData);
                    startActivity(intent);

                    // Mark as read immediately
                    db.markMessagesAsRead(item.extraData, currentUsername);
                    finish(); // Close notification screen
                } else if (item.type.equals("order")) {
                    // Mark order as seen
                    try {
                        int orderId = Integer.parseInt(item.extraData);
                        db.markOrderAsSeen(orderId);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

                    // Open Orders Activity
                    if ("freelancer".equalsIgnoreCase(currentRole) || "freelancers".equalsIgnoreCase(currentRole)) {
                        Intent intent = new Intent(NotificationActivity.this, PesananMasukActivity.class);
                        intent.putExtra("username", currentUsername);
                        startActivity(intent);
                    } else if ("Admin".equalsIgnoreCase(currentRole)) {
                        Intent intent = new Intent(NotificationActivity.this, KelolaPesananActivity.class);
                        intent.putExtra("order_id", Integer.parseInt(item.extraData));
                        startActivity(intent);
                    }
                    finish();
                } else if (item.type.equals("order_completed")) {
                    // Mark order as seen
                    try {
                        int orderId = Integer.parseInt(item.extraData);
                        db.markOrderAsSeen(orderId);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

                    // Open Client Orders Activity
                    Intent intent = new Intent(NotificationActivity.this, PesananSayaActivity.class);
                    intent.putExtra("username", currentUsername);
                    startActivity(intent);
                    finish();
                } else if (item.type.equals("rating")) {
                    // Mark rating as seen
                    try {
                        int orderId = Integer.parseInt(item.extraData);
                        db.markRatingAsSeen(orderId);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

                    // Open Orders/History Activity
                    Intent intent = new Intent(NotificationActivity.this, PesananMasukActivity.class);
                    intent.putExtra("username", currentUsername);
                    startActivity(intent);
                    finish();
                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView textTitle, textMessage, textTime;
            ImageView imgIcon;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                textTitle = itemView.findViewById(R.id.textTitle);
                textMessage = itemView.findViewById(R.id.textMessage);
                textTime = itemView.findViewById(R.id.textTime);
                imgIcon = itemView.findViewById(R.id.imgIcon);
            }
        }
    }
}
