package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class FreelancerActivity extends AppCompatActivity {

    TextView textTitle, textWelcome, textTotalJasa, textTotalPesanan, textRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freelancer);

        textTitle = findViewById(R.id.textFreelancerTitle);

        String username = getIntent().getStringExtra("username");
        textTitle.setText("Freelancer");

        // 🔥 AMBIL KOMPONEN BERANDA
        textWelcome = findViewById(R.id.textWelcome);
        textTotalJasa = findViewById(R.id.textTotalJasa);
        textTotalPesanan = findViewById(R.id.textTotalPesanan);
        textRating = findViewById(R.id.textRating);

        // SET NILAI WELCOME
        textWelcome.setText("Selamat datang, " + username);

        // SEARCH BAR
        android.widget.EditText searchBar = findViewById(R.id.searchBar);

        // SEARCH BAR logic with Clear Button
        if (searchBar != null) {
            searchBar.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length() > 0) {
                        searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, R.drawable.ic_close,
                                0);
                    } else {
                        searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0);
                    }
                }

                @Override
                public void afterTextChanged(android.text.Editable s) {
                }
            });

            searchBar.setOnTouchListener((v, event) -> {
                if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    if (searchBar.getCompoundDrawables()[2] != null) {
                        if (event.getRawX() >= (searchBar.getRight()
                                - searchBar.getCompoundDrawables()[2].getBounds().width() - 50)) {
                            searchBar.setText("");
                            return true;
                        }
                    }
                }
                return false;
            });

            searchBar.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH ||
                        actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE ||
                        event != null && event.getAction() == android.view.KeyEvent.ACTION_DOWN
                                && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER) {

                    String query = searchBar.getText().toString().trim();
                    Intent i = new Intent(FreelancerActivity.this, CariJasaActivity.class);
                    i.putExtra("username", username);
                    i.putExtra("search_query", query);
                    startActivity(i);
                    return true;
                }
                return false;
            });
        }

        // 🔥 NAV BOTTOM (LinearLayout)
        android.view.View navBeranda = findViewById(R.id.navBeranda);
        android.view.View navKelolaJasa = findViewById(R.id.navKelolaJasa);
        android.view.View navPortofolio = findViewById(R.id.navPortofolio);
        android.view.View navPesananMasuk = findViewById(R.id.navPesananMasuk);
        android.view.View navProfil = findViewById(R.id.navProfil);

        // Klik beranda → tetap di halaman ini
        navBeranda.setOnClickListener(v -> {
            // Tidak membuka activity lain
        });

        // Klik Kelola Jasa → buka halaman CRUD Jasa
        navKelolaJasa.setOnClickListener(v -> {
            Intent i = new Intent(FreelancerActivity.this, KelolaJasaActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Klik Portofolio
        navPortofolio.setOnClickListener(v -> {
            Intent i = new Intent(FreelancerActivity.this, PortofolioActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Klik Pesanan Masuk
        navPesananMasuk.setOnClickListener(v -> {
            Intent i = new Intent(FreelancerActivity.this, PesananMasukActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Klik Profil
        navProfil.setOnClickListener(v -> {
            Intent i = new Intent(FreelancerActivity.this, ProfilFreelancerActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Support Chat
        findViewById(R.id.btnSupportChatFreelancer).setOnClickListener(v -> {
            Intent i = new Intent(FreelancerActivity.this, ChatActivity.class);
            i.putExtra("username", username);
            i.putExtra("otherUser", "Admin");
            startActivity(i);
        });

        // Notification Button
        findViewById(R.id.btnNotification).setOnClickListener(v -> {
            Intent i = new Intent(FreelancerActivity.this, NotificationActivity.class);
            startActivity(i);
        });

        // 🔥 QUICK MENU SHORTCUTS (from included layout)
        android.view.View navKelolaJasaShortcut = findViewById(R.id.navKelolaJasaShortcut);
        android.view.View navPesananMasukShortcut = findViewById(R.id.navPesananMasukShortcut);

        // Click listener untuk Tambah Jasa shortcut
        if (navKelolaJasaShortcut != null) {
            navKelolaJasaShortcut.setOnClickListener(v -> {
                try {
                    // Animasi scale untuk feedback visual
                    v.animate()
                            .scaleX(0.95f)
                            .scaleY(0.95f)
                            .setDuration(100)
                            .withEndAction(() -> {
                                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                            })
                            .start();

                    Intent i = new Intent(FreelancerActivity.this, KelolaJasaActivity.class);
                    i.putExtra("username", username);
                    startActivity(i);
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                } catch (Exception e) {
                    android.widget.Toast.makeText(this, "Gagal membuka Kelola Jasa", android.widget.Toast.LENGTH_SHORT)
                            .show();
                    e.printStackTrace();
                }
            });
        }

        // Click listener untuk Pesanan Masuk shortcut
        if (navPesananMasukShortcut != null) {
            navPesananMasukShortcut.setOnClickListener(v -> {
                try {
                    // Animasi scale untuk feedback visual
                    v.animate()
                            .scaleX(0.95f)
                            .scaleY(0.95f)
                            .setDuration(100)
                            .withEndAction(() -> {
                                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                            })
                            .start();

                    Intent i = new Intent(FreelancerActivity.this, PesananMasukActivity.class);
                    i.putExtra("username", username);
                    startActivity(i);
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                } catch (Exception e) {
                    android.widget.Toast
                            .makeText(this, "Gagal membuka Pesanan Masuk", android.widget.Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            });
        }

        // 🔥 INFO & TIPS FREELANCER
        android.view.View tipFreelancerCard1 = findViewById(R.id.tipFreelancerCard1);
        android.view.View tipFreelancerCard2 = findViewById(R.id.tipFreelancerCard2);

        if (tipFreelancerCard1 != null) {
            tipFreelancerCard1.setOnClickListener(v -> {
                try {
                    v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100).start())
                            .start();

                    Intent intent = new Intent(FreelancerActivity.this, DetailTipsActivity.class);
                    intent.putExtra("tip_title", "Optimalkan Portofoliomu");
                    intent.putExtra("tip_content", "Cara mengoptimalkan portofolio Anda:\n\n" +
                            "1. Pilih Hasil Terbaik: Hanya tampilkan karya terbaik Anda yang relevan dengan jasa yang ditawarkan.\n\n"
                            +
                            "2. Gambar Berkualitas Tinggi: Gunakan gambar yang jernih dan profesional sebagai thumbnail.\n\n"
                            +
                            "3. Deskripsi Singkat: Berikan penjelasan singkat tentang proyek tersebut dan peran Anda di dalamnya.\n\n"
                            +
                            "4. Rutin Update: Tambahkan karya terbaru Anda secara berkala untuk menunjukkan Anda aktif.");
                    startActivity(intent);
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                } catch (Exception e) {
                    android.widget.Toast.makeText(this, "Gagal membuka Tips", android.widget.Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            });
        }

        if (tipFreelancerCard2 != null) {
            tipFreelancerCard2.setOnClickListener(v -> {
                try {
                    v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100).start())
                            .start();

                    Intent intent = new Intent(FreelancerActivity.this, DetailTipsActivity.class);
                    intent.putExtra("tip_title", "Respon Cepat = Rating Bagus");
                    intent.putExtra("tip_content", "Mengapa respon cepat itu penting:\n\n" +
                            "1. Kepercayaan Klien: Klien lebih cenderung memesan dari freelancer yang membalas pesan dalam hitungan menit.\n\n"
                            +
                            "2. Keunggulan Kompetitif: Menjadi yang pertama merespon memberi Anda peluang lebih besar dibanding freelancer lain.\n\n"
                            +
                            "3. Rating Respon: Sistem kami memantau waktu respon Anda. Respon cepat meningkatkan visibilitas profil Anda.\n\n"
                            +
                            "4. Profesionalisme: Menunjukkan bahwa Anda serius dan menghargai waktu klien.");
                    startActivity(intent);
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                } catch (Exception e) {
                    android.widget.Toast.makeText(this, "Gagal membuka Tips", android.widget.Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkUnreadNotifications();
        updateDashboardStats();
    }

    private void updateDashboardStats() {
        DatabaseHelper db = new DatabaseHelper(this);
        String username = getIntent().getStringExtra("username");

        int totalJasa = db.getFreelancerServiceCount(username);
        int totalPesanan = db.getFreelancerOrderCount(username);
        double rating = db.getFreelancerAverageRating(username);

        textTotalJasa.setText(String.valueOf(totalJasa));
        textTotalPesanan.setText(String.valueOf(totalPesanan));
        textRating.setText(String.format("%.1f", rating));
    }

    private void checkUnreadNotifications() {
        android.view.View viewBadge = findViewById(R.id.viewBadge);
        DatabaseHelper db = new DatabaseHelper(this);
        String username = getIntent().getStringExtra("username");

        boolean hasUnread = false;

        // Check Messages
        android.database.Cursor cursorMsg = db.getUnreadMessages(username);
        if (cursorMsg != null && cursorMsg.getCount() > 0) {
            hasUnread = true;
        }
        if (cursorMsg != null)
            cursorMsg.close();

        // Check Pending Orders
        if (db.getUnseenOrdersCount(username) > 0) {
            hasUnread = true;
            // Badge on menu disabled as per request
            findViewById(R.id.badgePesananMasuk).setVisibility(android.view.View.VISIBLE);
        } else {
            findViewById(R.id.badgePesananMasuk).setVisibility(android.view.View.GONE);
        }

        // Check Unseen Ratings
        android.database.Cursor cursorRatings = db.getUnseenRatings(username);
        if (cursorRatings != null && cursorRatings.getCount() > 0) {
            hasUnread = true;
        }
        if (cursorRatings != null)
            cursorRatings.close();

        viewBadge.setVisibility(hasUnread ? android.view.View.VISIBLE : android.view.View.GONE);
    }
}
