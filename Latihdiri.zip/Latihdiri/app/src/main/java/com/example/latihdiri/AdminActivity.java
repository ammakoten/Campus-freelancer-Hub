package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class AdminActivity extends AppCompatActivity {

    TextView textTitle;
    TextView textTotalUsers, textTotalOrders, textActiveServices, textReports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        String username = getIntent().getStringExtra("username");

        // NAV BOTTOM (LinearLayout)
        android.view.View navBeranda = findViewById(R.id.navBeranda);
        android.view.View navKelolaUser = findViewById(R.id.navKelolaUser);
        android.view.View navKelolaJasa = findViewById(R.id.navKelolaJasa);
        android.view.View navKelolaPesanan = findViewById(R.id.navKelolaPesanan);
        android.view.View navProfil = findViewById(R.id.navProfil);

        // DASHBOARD BUTTONS
        android.view.View btnAddUser = findViewById(R.id.btnAddUser);
        android.view.View btnViewReports = findViewById(R.id.btnViewReports);
        android.view.View btnVerifikasi = findViewById(R.id.btnVerifikasi);
        android.view.View btnPengaturan = findViewById(R.id.btnPengaturan);
        android.widget.EditText searchBar = findViewById(R.id.searchBar);

        // STATS TEXTVIEWS
        textTotalUsers = findViewById(R.id.textTotalUsers);
        textTotalOrders = findViewById(R.id.textTotalOrders);
        textActiveServices = findViewById(R.id.textActiveServices);
        textReports = findViewById(R.id.textReports);

        searchBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, R.drawable.ic_close, 0);
                } else {
                    searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0);
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
            }
        });

        searchBar.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                if (searchBar.getCompoundDrawables()[2] != null) {
                    if (event.getRawX() >= (searchBar.getRight()
                            - searchBar.getCompoundDrawables()[2].getBounds().width() - 50)) {
                        searchBar.setText("");
                        return true;
                    }
                }
            }
            return false;
        });

        searchBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH ||
                    actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE ||
                    event != null && event.getAction() == android.view.KeyEvent.ACTION_DOWN
                            && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER) {

                String query = searchBar.getText().toString().trim();
                Intent i = new Intent(AdminActivity.this, AdminSearchActivity.class);
                i.putExtra("username", username);
                i.putExtra("search_query", query);
                startActivity(i);
                return true;
            }
            return false;
        });

        // Klik beranda → tetap di halaman ini
        navBeranda.setOnClickListener(v -> {
            // Do nothing
        });

        // Klik Kelola User
        navKelolaUser.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, KelolaAkunUserActivity.class);
            startActivity(i);
        });

        // Klik Kelola Jasa Freelancer
        navKelolaJasa.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, KelolaJasaFreelancerActivity.class);
            startActivity(i);
        });

        // Klik Kelola Pesanan
        navKelolaPesanan.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, KelolaPesananActivity.class);
            startActivity(i);
        });

        // Klik Profil
        navProfil.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, ProfilAdminActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // DASHBOARD ACTIONS
        btnAddUser.setOnClickListener(v -> {
            // Direct to KelolaAkunUserActivity for adding user
            Intent i = new Intent(AdminActivity.this, KelolaAkunUserActivity.class);
            startActivity(i);
        });

        btnViewReports.setOnClickListener(v -> {
            // Direct to KelolaPesananActivity for reports (placeholder)
            Intent i = new Intent(AdminActivity.this, KelolaPesananActivity.class);
            startActivity(i);
        });

        // Verifikasi Button - Navigate to user management for verification
        btnVerifikasi.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, KelolaAkunUserActivity.class);
            startActivity(i);
        });

        // Pengaturan Button - Navigate to admin profile/settings
        btnPengaturan.setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, ProfilAdminActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Chat Support
        findViewById(R.id.btnChatSupport).setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, ChatListActivity.class);
            startActivity(i);
        });

        // Notification Button
        findViewById(R.id.btnNotification).setOnClickListener(v -> {
            Intent i = new Intent(AdminActivity.this, NotificationActivity.class);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkUnreadNotifications();
        loadDashboardStats();
        loadRecentActivities();
    }

    private void loadDashboardStats() {
        DatabaseHelper db = new DatabaseHelper(this);
        textTotalUsers.setText(String.valueOf(db.getTotalUserCount()));
        textTotalOrders.setText(String.valueOf(db.getTotalOrderCount()));
        textActiveServices.setText(String.valueOf(db.getActiveServiceCount()));
        textReports.setText(String.valueOf(db.getReportCount()));
    }

    private void loadRecentActivities() {
        DatabaseHelper db = new DatabaseHelper(this);

        // Get container for activities
        android.widget.LinearLayout activityContainer = findViewById(R.id.activityContainer);
        if (activityContainer != null) {
            activityContainer.removeAllViews();

            // Load recent users
            android.database.Cursor userCursor = db.getRecentUsers(2);
            while (userCursor.moveToNext()) {
                String username = userCursor.getString(userCursor.getColumnIndexOrThrow("username"));
                String role = userCursor.getString(userCursor.getColumnIndexOrThrow("role"));

                // Navigate to KelolaAkunUserActivity when clicked
                android.view.View.OnClickListener listener = v -> {
                    Intent i = new Intent(AdminActivity.this, KelolaAkunUserActivity.class);
                    startActivity(i);
                };

                addActivityItem(activityContainer, "User baru mendaftar: " + username + " (" + role + ")",
                        "Baru saja", "#4CAF50", listener);
            }
            userCursor.close();

            // Load recent orders
            android.database.Cursor orderCursor = db.getRecentOrders(2);
            while (orderCursor.moveToNext()) {
                int orderId = orderCursor.getInt(orderCursor.getColumnIndexOrThrow("id_order"));
                String serviceName = orderCursor.getString(orderCursor.getColumnIndexOrThrow("service_name"));
                String status = orderCursor.getString(orderCursor.getColumnIndexOrThrow("status"));
                long date = Long.parseLong(orderCursor.getString(orderCursor.getColumnIndexOrThrow("date")));
                String timeAgo = getTimeAgo(date);

                // Navigate to KelolaPesananActivity when clicked
                android.view.View.OnClickListener listener = v -> {
                    Intent i = new Intent(AdminActivity.this, KelolaPesananActivity.class);
                    startActivity(i);
                };

                addActivityItem(activityContainer, "Pesanan: " + serviceName + " - " + status,
                        timeAgo, "#2196F3", listener);
            }
            orderCursor.close();
        }
    }

    private void addActivityItem(android.widget.LinearLayout container, String text, String time, String color,
            android.view.View.OnClickListener listener) {
        // Create horizontal layout for activity item
        android.widget.LinearLayout itemLayout = new android.widget.LinearLayout(this);
        itemLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        itemLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout.LayoutParams itemParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        itemParams.setMargins(0, 0, 0, dpToPx(12));
        itemLayout.setLayoutParams(itemParams);

        // Add colored dot
        android.view.View dot = new android.view.View(this);
        android.widget.LinearLayout.LayoutParams dotParams = new android.widget.LinearLayout.LayoutParams(
                dpToPx(8), dpToPx(8));
        dotParams.setMargins(0, 0, dpToPx(12), 0);
        dot.setLayoutParams(dotParams);
        dot.setBackgroundResource(R.drawable.bg_circle_accent);
        dot.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor(color)));
        itemLayout.addView(dot);

        // Add text
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(13);
        textView.setTextColor(getResources().getColor(R.color.black, null));
        android.widget.LinearLayout.LayoutParams textParams = new android.widget.LinearLayout.LayoutParams(
                0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        textView.setLayoutParams(textParams);
        itemLayout.addView(textView);

        // Add time
        TextView timeView = new TextView(this);
        timeView.setText(time);
        timeView.setTextSize(11);
        timeView.setTextColor(getResources().getColor(R.color.text_secondary, null));
        timeView.setGravity(android.view.Gravity.END);
        itemLayout.addView(timeView);

        container.addView(itemLayout);

        // Set the listener to the whole row
        if (listener != null) {
            itemLayout.setOnClickListener(listener);
        }

        // Add divider if not last item
        android.view.View divider = new android.view.View(this);
        android.widget.LinearLayout.LayoutParams dividerParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1));
        dividerParams.setMargins(0, 0, 0, dpToPx(12));
        divider.setLayoutParams(dividerParams);
        divider.setBackgroundColor(android.graphics.Color.parseColor("#EEEEEE"));
        container.addView(divider);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private String getTimeAgo(long timestamp) {
        long now = System.currentTimeMillis();
        long diff = now - timestamp;

        long seconds = diff / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;

        if (days > 0)
            return days + "h lalu";
        if (hours > 0)
            return hours + "j lalu";
        if (minutes > 0)
            return minutes + "m lalu";
        return "Baru saja";
    }

    private void checkUnreadNotifications() {
        android.view.View viewBadge = findViewById(R.id.viewBadge);
        DatabaseHelper db = new DatabaseHelper(this);

        boolean hasUnread = false;

        // Check Messages (Admin username is "admin")
        android.database.Cursor cursorMsg = db.getUnreadMessages("admin");
        if (cursorMsg != null && cursorMsg.getCount() > 0) {
            hasUnread = true;
        }
        if (cursorMsg != null)
            cursorMsg.close();

        // Check Pending Orders (All orders for Admin)
        if (!hasUnread) {
            if (db.getAllUnseenOrdersCount() > 0) {
                hasUnread = true;
            }
        }

        viewBadge.setVisibility(hasUnread ? android.view.View.VISIBLE : android.view.View.GONE);
    }
}
