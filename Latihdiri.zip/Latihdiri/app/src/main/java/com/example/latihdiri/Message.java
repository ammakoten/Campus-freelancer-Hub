package com.example.latihdiri;

public class Message {
    private int id;
    private String sender;
    private String receiver;
    private String message;
    private String timestamp;
    private String filePath;
    private String messageType; // "text", "image", "file"

    public Message(int id, String sender, String receiver, String message, String timestamp) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.message = message;
        this.timestamp = timestamp;
        this.messageType = "text";
        this.filePath = "";
    }

    public Message(int id, String sender, String receiver, String message, String timestamp, String filePath,
            String messageType) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.message = message;
        this.timestamp = timestamp;
        this.filePath = filePath;
        this.messageType = messageType;
    }

    public int getId() {
        return id;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getMessage() {
        return message;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getMessageType() {
        return messageType;
    }
}
