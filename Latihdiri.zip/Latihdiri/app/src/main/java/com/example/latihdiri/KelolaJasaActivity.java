package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.widget.ImageView;

public class KelolaJasaActivity extends AppCompatActivity {

    FloatingActionButton fabTambah;
    String username;
    androidx.recyclerview.widget.RecyclerView recyclerView;
    KelolaJasaAdapter adapter;
    java.util.List<Jasa> jasaList;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kelola_jasa);

        db = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        fabTambah = findViewById(R.id.fabTambahJasa);
        ImageView btnBack = findViewById(R.id.btnBack);
        recyclerView = findViewById(R.id.recyclerKelolaJasa);

        recyclerView.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this));
        jasaList = new java.util.ArrayList<>();
        adapter = new KelolaJasaAdapter(this, jasaList, this::loadJasa);
        recyclerView.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());

        fabTambah.setOnClickListener(v -> {
            Intent intent = new Intent(KelolaJasaActivity.this, TambahJasaActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        loadJasa();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadJasa();
    }

    private void loadJasa() {
        jasaList.clear();
        jasaList.clear();
        android.database.Cursor cursor;

        android.content.SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        String role = prefs.getString("role", "");

        if ("Admin".equalsIgnoreCase(role)) {
            cursor = db.getAllJasa();
        } else {
            cursor = db.getJasaByUser(username);
        }
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String user = cursor.getString(1);
                String nama = cursor.getString(2);
                String deskripsi = cursor.getString(3);
                String harga = cursor.getString(4);
                String kategori = cursor.getString(5);
                String imagePath = cursor.getString(6); // index 6 is image_path

                jasaList.add(new Jasa(id, user, nama, deskripsi, harga, kategori, imagePath));
            } while (cursor.moveToNext());
        }
        adapter.notifyDataSetChanged();
    }
}
