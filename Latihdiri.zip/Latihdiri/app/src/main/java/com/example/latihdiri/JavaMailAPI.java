package com.example.latihdiri;

// This file is deprecated and should be deleted.
// Kept as empty to prevent compilation errors if it cannot be deleted immediately.
public class JavaMailAPI {
    // Empty
}
