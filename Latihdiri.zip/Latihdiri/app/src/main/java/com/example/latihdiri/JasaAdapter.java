package com.example.latihdiri;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class JasaAdapter extends RecyclerView.Adapter<JasaAdapter.JasaViewHolder> {

    private List<Jasa> jasaList;
    private List<Jasa> jasaListFull; // Untuk search

    public JasaAdapter(List<Jasa> jasaList) {
        this.jasaList = jasaList;
        this.jasaListFull = new ArrayList<>(jasaList);
    }

    @NonNull
    @Override
    public JasaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_jasa, parent, false);
        return new JasaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JasaViewHolder holder, int position) {
        Jasa jasa = jasaList.get(position);
        holder.textNama.setText(jasa.getNamaJasa());
        holder.textKategori.setText(jasa.getKategori());
        holder.textFreelancer.setText("Oleh: " + jasa.getUsername());
        holder.textHarga.setText("Rp " + jasa.getHarga());
        if (jasa.getDeskripsi() != null) {
            holder.textDeskripsi
                    .setText(android.text.Html.fromHtml(jasa.getDeskripsi(), android.text.Html.FROM_HTML_MODE_COMPACT));
        }

        if (jasa.getImagePath() != null && !jasa.getImagePath().isEmpty()) {
            java.io.File imageFile = new java.io.File(jasa.getImagePath());
            if (imageFile.exists()) {
                holder.imgJasa.setImageURI(android.net.Uri.fromFile(imageFile));
                holder.imgJasa.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            } else {
                holder.imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
            }
        } else {
            holder.imgJasa.setImageResource(R.drawable.ic_insert_drive_file); // Placeholder
        }
    }

    @Override
    public int getItemCount() {
        return jasaList.size();
    }

    public void filter(String text) {
        jasaList.clear();
        if (text.isEmpty()) {
            jasaList.addAll(jasaListFull);
        } else {
            text = text.toLowerCase();
            for (Jasa item : jasaListFull) {
                if (item.getNamaJasa().toLowerCase().contains(text) ||
                        item.getKategori().toLowerCase().contains(text) ||
                        item.getUsername().toLowerCase().contains(text)) {
                    jasaList.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    public static class JasaViewHolder extends RecyclerView.ViewHolder {
        android.widget.ImageView imgJasa;
        TextView textNama, textKategori, textFreelancer, textHarga, textDeskripsi;

        public JasaViewHolder(@NonNull View itemView) {
            super(itemView);
            imgJasa = itemView.findViewById(R.id.imgJasaInfo);
            textNama = itemView.findViewById(R.id.textNamaJasa);
            textKategori = itemView.findViewById(R.id.textKategoriJasa);
            textFreelancer = itemView.findViewById(R.id.textFreelancerName);
            textHarga = itemView.findViewById(R.id.textHargaJasa);
            textDeskripsi = itemView.findViewById(R.id.textDeskripsi);
        }
    }
}
