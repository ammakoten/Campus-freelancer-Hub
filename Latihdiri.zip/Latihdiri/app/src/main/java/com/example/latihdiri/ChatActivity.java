package com.example.latihdiri;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView recyclerChat;
    private EditText editMessage;
    private ImageButton btnSend;
    private ImageView btnBack;
    private TextView textChatTitle;

    private DatabaseHelper db;
    private MessageAdapter adapter;
    private List<Message> messageList;
    private String currentUser;
    private String targetUser;

    private static final int PICK_FILE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        db = new DatabaseHelper(this);
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        currentUser = prefs.getString("username", "");
        String role = prefs.getString("role", "");

        // If user is Admin, force username to "admin" for chat consistency
        if ("Admin".equalsIgnoreCase(role)) {
            currentUser = "admin";
        }

        targetUser = getIntent().getStringExtra("target_user");

        if (targetUser == null) {
            targetUser = "admin"; // Default for client
        }

        recyclerChat = findViewById(R.id.recyclerChat);
        editMessage = findViewById(R.id.editMessage);
        btnSend = findViewById(R.id.btnSend);
        btnBack = findViewById(R.id.btnBack);
        textChatTitle = findViewById(R.id.textChatTitle);
        ImageButton btnAttach = findViewById(R.id.btnAttach);

        textChatTitle.setText("Chat with " + targetUser);

        messageList = new ArrayList<>();
        adapter = new MessageAdapter(this, messageList, currentUser);
        recyclerChat.setLayoutManager(new LinearLayoutManager(this));
        recyclerChat.setAdapter(adapter);

        loadMessages();

        btnSend.setOnClickListener(v -> {
            String msg = editMessage.getText().toString().trim();
            if (!msg.isEmpty()) {
                if (db.insertMessage(currentUser, targetUser, msg)) {
                    editMessage.setText("");
                    loadMessages();
                    sendNotification("Pesan Baru", "Dari " + currentUser + ": " + msg, targetUser);
                } else {
                    Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnAttach.setOnClickListener(v -> openFilePicker());

        btnBack.setOnClickListener(v -> finish());
    }

    private void openFilePicker() {
        android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            android.net.Uri fileUri = data.getData();
            saveFileAndSendMessage(fileUri);
        }
    }

    private void saveFileAndSendMessage(android.net.Uri fileUri) {
        try {
            java.io.InputStream inputStream = getContentResolver().openInputStream(fileUri);
            String fileName = "chat_" + System.currentTimeMillis();
            String mimeType = getContentResolver().getType(fileUri);
            String extension = "";
            String type = "file";

            if (mimeType != null) {
                extension = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType);
                if (mimeType.startsWith("image/")) {
                    type = "image";
                }
            }
            if (extension == null || extension.isEmpty())
                extension = "bin";

            // Try to get real filename
            android.database.Cursor returnCursor = getContentResolver().query(fileUri, null, null, null, null);
            if (returnCursor != null) {
                int nameIndex = returnCursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                returnCursor.moveToFirst();
                String originalName = returnCursor.getString(nameIndex);
                if (originalName != null)
                    fileName = originalName;
                returnCursor.close();
            } else {
                fileName += "." + extension;
            }

            java.io.File file = new java.io.File(getFilesDir(), "chat_files");
            if (!file.exists()) {
                file.mkdirs();
            }
            java.io.File destFile = new java.io.File(file, fileName);

            java.io.OutputStream outputStream = new java.io.FileOutputStream(destFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();

            // Insert into DB
            if (db.insertMessageWithFile(currentUser, targetUser, fileName, destFile.getAbsolutePath(), type)) {
                loadMessages();
            } else {
                Toast.makeText(this, "Failed to send file", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error sending file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void sendNotification(String title, String content, String targetUser) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String channelId = "chat_notifications";
            CharSequence name = "Chat Notifications";
            String description = "Notifications for new messages";
            int importance = android.app.NotificationManager.IMPORTANCE_HIGH;
            android.app.NotificationChannel channel = new android.app.NotificationChannel(channelId, name, importance);
            channel.setDescription(description);
            android.app.NotificationManager notificationManager = getSystemService(
                    android.app.NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        android.content.Intent intent = new android.content.Intent(this, ChatActivity.class);
        intent.putExtra("target_user", currentUser); // When clicked, chat with sender (which is current user here)
        intent.setFlags(
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);

        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(
                this, 0, intent,
                android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT);

        androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(this,
                "chat_notifications")
                .setSmallIcon(R.drawable.ic_notifications) // Ensure this icon exists, typically ic_notifications or
                                                           // ic_launcher
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        androidx.core.app.NotificationManagerCompat notificationManager = androidx.core.app.NotificationManagerCompat
                .from(this);
        try {
            notificationManager.notify((int) System.currentTimeMillis(), builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void loadMessages() {
        messageList.clear();
        Cursor cursor = db.getMessages(currentUser, targetUser);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String sender = cursor.getString(cursor.getColumnIndexOrThrow("sender"));
                String receiver = cursor.getString(cursor.getColumnIndexOrThrow("receiver"));
                String message = cursor.getString(cursor.getColumnIndexOrThrow("message"));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));

                String filePath = "";
                String messageType = "text";
                try {
                    filePath = cursor.getString(cursor.getColumnIndexOrThrow("file_path"));
                    messageType = cursor.getString(cursor.getColumnIndexOrThrow("message_type"));
                } catch (Exception e) {
                    // Columns might not exist if old DB
                }
                if (messageType == null)
                    messageType = "text";

                messageList.add(new Message(id, sender, receiver, message, timestamp, filePath, messageType));
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
        if (!messageList.isEmpty()) {
            recyclerChat.scrollToPosition(messageList.size() - 1);
        }
    }

    // Inner Adapter Class
    public static class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

        private Context context;
        private List<Message> messages;
        private String currentUser;

        public MessageAdapter(Context context, List<Message> messages, String currentUser) {
            this.context = context;
            this.messages = messages;
            this.currentUser = currentUser;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_chat_bubble, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Message msg = messages.get(position);

            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String time = sdf.format(new Date(Long.parseLong(msg.getTimestamp())));

            boolean isSender = msg.getSender().equals(currentUser);
            String type = msg.getMessageType();
            if (type == null)
                type = "text";

            // Reset visibility
            holder.textSend.setVisibility(View.GONE);
            holder.textReceive.setVisibility(View.GONE);
            holder.imageSend.setVisibility(View.GONE);
            holder.imageReceive.setVisibility(View.GONE);
            holder.layoutFileSend.setVisibility(View.GONE);
            holder.layoutFileReceive.setVisibility(View.GONE);
            holder.textTimeSend.setVisibility(View.GONE);
            holder.textTimeReceive.setVisibility(View.GONE);

            if (isSender) {
                // SENDER
                holder.textTimeSend.setVisibility(View.VISIBLE);
                holder.textTimeSend.setText(time);

                if (type.equals("image")) {
                    holder.imageSend.setVisibility(View.VISIBLE);
                    if (msg.getFilePath() != null) {
                        holder.imageSend.setImageURI(android.net.Uri.fromFile(new java.io.File(msg.getFilePath())));
                    }
                    holder.imageSend.setOnClickListener(v -> openFile(msg.getFilePath()));
                } else if (type.equals("file")) {
                    holder.layoutFileSend.setVisibility(View.VISIBLE);
                    holder.textFileSend.setText(msg.getMessage());
                    holder.layoutFileSend.setOnClickListener(v -> openFile(msg.getFilePath()));
                } else {
                    holder.textSend.setVisibility(View.VISIBLE);
                    holder.textSend.setText(msg.getMessage());
                }

            } else {
                // RECEIVER
                holder.textTimeReceive.setVisibility(View.VISIBLE);
                holder.textTimeReceive.setText(time);

                if (type.equals("image")) {
                    holder.imageReceive.setVisibility(View.VISIBLE);
                    if (msg.getFilePath() != null) {
                        holder.imageReceive.setImageURI(android.net.Uri.fromFile(new java.io.File(msg.getFilePath())));
                    }
                    holder.imageReceive.setOnClickListener(v -> openFile(msg.getFilePath()));
                } else if (type.equals("file")) {
                    holder.layoutFileReceive.setVisibility(View.VISIBLE);
                    holder.textFileReceive.setText(msg.getMessage());
                    holder.layoutFileReceive.setOnClickListener(v -> openFile(msg.getFilePath()));
                } else {
                    holder.textReceive.setVisibility(View.VISIBLE);
                    holder.textReceive.setText(msg.getMessage());
                }
            }
        }

        private void openFile(String filePath) {
            if (filePath == null || filePath.isEmpty())
                return;
            java.io.File file = new java.io.File(filePath);
            if (file.exists()) {
                android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(context,
                        context.getPackageName() + ".fileprovider", file);

                android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);

                String mimeType = "*/*";
                String extension = android.webkit.MimeTypeMap
                        .getFileExtensionFromUrl(android.net.Uri.fromFile(file).toString());
                if (extension != null) {
                    mimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                }
                if (mimeType == null)
                    mimeType = "*/*";

                intent.setDataAndType(uri, mimeType);
                intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);

                try {
                    context.startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(context, "No app to open this file", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "File not found", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            TextView textSend, textReceive;
            TextView textTimeSend, textTimeReceive;
            ImageView imageSend, imageReceive;
            android.widget.LinearLayout layoutFileSend, layoutFileReceive;
            TextView textFileSend, textFileReceive;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                textSend = itemView.findViewById(R.id.textSend);
                textReceive = itemView.findViewById(R.id.textReceive);
                textTimeSend = itemView.findViewById(R.id.textTimeSend);
                textTimeReceive = itemView.findViewById(R.id.textTimeReceive);

                imageSend = itemView.findViewById(R.id.imageSend);
                imageReceive = itemView.findViewById(R.id.imageReceive);

                layoutFileSend = itemView.findViewById(R.id.layoutFileSend);
                layoutFileReceive = itemView.findViewById(R.id.layoutFileReceive);

                textFileSend = itemView.findViewById(R.id.textFileSend);
                textFileReceive = itemView.findViewById(R.id.textFileReceive);
            }
        }
    }
}
