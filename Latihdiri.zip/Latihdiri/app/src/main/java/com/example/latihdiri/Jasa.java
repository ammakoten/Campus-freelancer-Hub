package com.example.latihdiri;

public class Jasa {
    private int id;
    private String username;
    private String namaJasa;
    private String deskripsi;
    private String harga;
    private String kategori;

    private String imagePath;

    public Jasa(int id, String username, String namaJasa, String deskripsi, String harga, String kategori,
            String imagePath) {
        this.id = id;
        this.username = username;
        this.namaJasa = namaJasa;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.kategori = kategori;
        this.imagePath = imagePath;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getNamaJasa() {
        return namaJasa;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getHarga() {
        return harga;
    }

    public String getKategori() {
        return kategori;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
