package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class EditJasaActivity extends AppCompatActivity {

    EditText inputNama, inputHarga, inputDeskripsi;
    android.widget.Spinner inputKategori;
    Button buttonUpdate, buttonHapus;
    DatabaseHelper db;
    int jasaId;
    String[] categories = { "Desain Grafis", "Pembuatan Website", "Penulisan", "Penerjemahan", "Video & Animasi",
            "Lainnya" };

    // Image Handling
    android.widget.ImageView imgJasa;
    android.view.View btnPilihFoto;
    android.widget.LinearLayout viewPlaceholder;
    String selectedImagePath = null;

    private static final int PERMISSION_REQUEST_STORAGE = 100;
    private static final int PICK_IMAGE_REQUEST = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_jasa);

        inputNama = findViewById(R.id.inputNamaJasa);
        inputHarga = findViewById(R.id.inputHarga);
        inputKategori = findViewById(R.id.inputKategori);
        inputDeskripsi = findViewById(R.id.inputDeskripsi);
        buttonUpdate = findViewById(R.id.buttonUpdateJasa);
        buttonHapus = findViewById(R.id.buttonHapusJasa);

        imgJasa = findViewById(R.id.imgJasa);
        btnPilihFoto = findViewById(R.id.btnPilihFoto);
        viewPlaceholder = findViewById(R.id.viewPlaceholder);

        android.widget.ImageView btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        db = new DatabaseHelper(this);

        // Setup Spinner Adapter
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        inputKategori.setAdapter(adapter);

        // Image Picker Listener
        btnPilihFoto.setOnClickListener(v -> checkPermissionAndPickImage());

        // Setup Toolbar Buttons with WYSIWYG logic (Smart Toggle)
        findViewById(R.id.btnBold).setOnClickListener(v -> toggleEmphasis(android.graphics.Typeface.BOLD));
        findViewById(R.id.btnItalic).setOnClickListener(v -> toggleEmphasis(android.graphics.Typeface.ITALIC));
        findViewById(R.id.btnUnderline).setOnClickListener(v -> toggleUnderline());

        findViewById(R.id.btnH1).setOnClickListener(v -> toggleHeading(2.0f));
        findViewById(R.id.btnH2).setOnClickListener(v -> toggleHeading(1.5f));

        // Ambil id yang dikirim lewat Intent
        jasaId = getIntent().getIntExtra("jasa_id", -1);
        if (jasaId == -1) {
            Toast.makeText(this, "ID jasa tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Ambil data jasa berdasarkan id_jasa
        Cursor c = db.getJasaById(jasaId);
        if (c != null && c.moveToFirst()) {
            inputNama.setText(c.getString(2));

            // Set Description handling HTML
            String deskripsiHtml = c.getString(3);
            if (deskripsiHtml != null) {
                inputDeskripsi
                        .setText(android.text.Html.fromHtml(deskripsiHtml, android.text.Html.FROM_HTML_MODE_COMPACT));
            }

            inputHarga.setText(c.getString(4));

            // Set Spinner Selection
            String currentCategory = c.getString(5);
            if (currentCategory != null) {
                for (int i = 0; i < categories.length; i++) {
                    if (categories[i].equals(currentCategory)) {
                        inputKategori.setSelection(i);
                        break;
                    }
                }
            }

            // Load Existing Image
            // Ensure cursor has enough columns (v16 added image_path at index 6)
            if (c.getColumnCount() > 6) {
                String imagePath = c.getString(6);
                if (imagePath != null && !imagePath.isEmpty()) {
                    selectedImagePath = imagePath; // Keep existing path
                    File imageFile = new File(imagePath);
                    if (imageFile.exists()) {
                        imgJasa.setImageURI(android.net.Uri.fromFile(imageFile));
                        imgJasa.setVisibility(android.view.View.VISIBLE);
                        viewPlaceholder.setVisibility(android.view.View.GONE);
                    }
                }
            }

            c.close();
        } else {
            if (c != null)
                c.close();
            Toast.makeText(this, "Data jasa tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Update — perhatikan: harga dipakai sebagai String (sesuai DB)
        buttonUpdate.setOnClickListener(v -> {
            String nama = inputNama.getText().toString().trim();
            String harga = inputHarga.getText().toString().trim();
            String kategori = inputKategori.getSelectedItem().toString();

            // Convert to HTML
            String deskripsi = android.text.Html.toHtml(inputDeskripsi.getText(),
                    android.text.Html.TO_HTML_PARAGRAPH_LINES_CONSECUTIVE);

            if (nama.isEmpty() || deskripsi.isEmpty() || harga.isEmpty() || kategori.isEmpty()) {
                Toast.makeText(this, "Isi semua field!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Pass selectedImagePath (null if unchanged/none, or new URI string)
            // But wait, DatabaseHelper code: "if (imagePath != null) cv.put..."
            // If I want to KEEP existing image, I must pass null OR the old path.
            // If I passed the OLD path into selectedImagePath during load, I can just pass
            // selectedImagePath here.

            boolean ok = db.updateJasa(jasaId, nama, deskripsi, harga, kategori, selectedImagePath);
            if (ok) {
                Toast.makeText(this, "Jasa berhasil diperbarui", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal memperbarui jasa", Toast.LENGTH_SHORT).show();
            }
        });

        // Hapus
        buttonHapus.setOnClickListener(v -> {
            boolean ok = db.deleteJasa(jasaId);
            if (ok) {
                Toast.makeText(this, "Jasa dihapus", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal menghapus jasa", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void toggleEmphasis(int style) {
        int start = inputDeskripsi.getSelectionStart();
        int end = inputDeskripsi.getSelectionEnd();
        android.text.Editable text = inputDeskripsi.getText();

        android.text.style.StyleSpan[] spans = text.getSpans(start, end, android.text.style.StyleSpan.class);
        boolean found = false;

        for (android.text.style.StyleSpan span : spans) {
            if (span.getStyle() == style) {
                found = true;
                int s = text.getSpanStart(span);
                int e = text.getSpanEnd(span);
                text.removeSpan(span);

                if (start == end) { // Cursor mode
                    if (s < start)
                        text.setSpan(new android.text.style.StyleSpan(style), s, start,
                                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    if (e > start)
                        text.setSpan(new android.text.style.StyleSpan(style), start, e,
                                android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                } else { // Selection mode
                    if (s < start)
                        text.setSpan(new android.text.style.StyleSpan(style), s, start,
                                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    if (e > end)
                        text.setSpan(new android.text.style.StyleSpan(style), end, e,
                                android.text.Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
                }
            }
        }

        if (!found) {
            if (start == end) {
                text.setSpan(new android.text.style.StyleSpan(style), start, end,
                        android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            } else {
                text.setSpan(new android.text.style.StyleSpan(style), start, end,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
    }

    private void toggleUnderline() {
        int start = inputDeskripsi.getSelectionStart();
        int end = inputDeskripsi.getSelectionEnd();
        android.text.Editable text = inputDeskripsi.getText();

        android.text.style.UnderlineSpan[] spans = text.getSpans(start, end, android.text.style.UnderlineSpan.class);
        boolean found = false;

        for (android.text.style.UnderlineSpan span : spans) {
            found = true;
            int s = text.getSpanStart(span);
            int e = text.getSpanEnd(span);
            text.removeSpan(span);

            if (start == end) {
                if (s < start)
                    text.setSpan(new android.text.style.UnderlineSpan(), s, start,
                            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (e > start)
                    text.setSpan(new android.text.style.UnderlineSpan(), start, e,
                            android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            } else {
                if (s < start)
                    text.setSpan(new android.text.style.UnderlineSpan(), s, start,
                            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (e > end)
                    text.setSpan(new android.text.style.UnderlineSpan(), end, e,
                            android.text.Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
            }
        }

        if (!found) {
            if (start == end) {
                text.setSpan(new android.text.style.UnderlineSpan(), start, end,
                        android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            } else {
                text.setSpan(new android.text.style.UnderlineSpan(), start, end,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
    }

    private void toggleHeading(float proportion) {
        int start = inputDeskripsi.getSelectionStart();
        int end = inputDeskripsi.getSelectionEnd();
        android.text.Editable text = inputDeskripsi.getText();

        android.text.style.RelativeSizeSpan[] spans = text.getSpans(start, end,
                android.text.style.RelativeSizeSpan.class);
        boolean existing = false;
        for (android.text.style.RelativeSizeSpan span : spans) {
            if (span.getSizeChange() == proportion) {
                existing = true;
                text.removeSpan(span);
            }
        }

        android.text.style.StyleSpan[] styleSpans = text.getSpans(start, end, android.text.style.StyleSpan.class);
        for (android.text.style.StyleSpan span : styleSpans) {
            if (span.getStyle() == android.graphics.Typeface.BOLD) {
                if (existing)
                    text.removeSpan(span);
            }
        }

        if (!existing) {
            if (start == end) {
                text.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, end,
                        android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                text.setSpan(new android.text.style.RelativeSizeSpan(proportion), start, end,
                        android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            } else {
                text.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, end,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                text.setSpan(new android.text.style.RelativeSizeSpan(proportion), start, end,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
    }

    private void checkPermissionAndPickImage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[] { Manifest.permission.READ_MEDIA_IMAGES },
                        PERMISSION_REQUEST_STORAGE);
            } else {
                openImagePicker();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[] { Manifest.permission.READ_EXTERNAL_STORAGE },
                        PERMISSION_REQUEST_STORAGE);
            } else {
                openImagePicker();
            }
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openImagePicker();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            // Copy image to internal storage
            selectedImagePath = copyImageToInternalStorage(imageUri);
            if (selectedImagePath != null) {
                imgJasa.setImageURI(Uri.fromFile(new File(selectedImagePath)));
                imgJasa.setVisibility(android.view.View.VISIBLE);
                viewPlaceholder.setVisibility(android.view.View.GONE);
            } else {
                Toast.makeText(this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String copyImageToInternalStorage(Uri sourceUri) {
        try {
            // Create service_images directory
            File imageDir = new File(getFilesDir(), "service_images");
            if (!imageDir.exists()) {
                imageDir.mkdirs();
            }

            // Generate unique filename
            String fileName = "service_" + System.currentTimeMillis() + ".jpg";
            File destFile = new File(imageDir, fileName);

            // Copy image data
            InputStream inputStream = getContentResolver().openInputStream(sourceUri);
            OutputStream outputStream = new FileOutputStream(destFile);

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            inputStream.close();
            outputStream.close();

            return destFile.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
