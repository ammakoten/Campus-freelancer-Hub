package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PortofolioActivity extends AppCompatActivity {

    LinearLayout containerPortofolio;
    ImageView btnAddPortofolio, btnBack;
    DatabaseHelper db;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portofolio);

        db = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        containerPortofolio = findViewById(R.id.containerPortofolio);
        btnAddPortofolio = findViewById(R.id.btnAddPortofolio);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        btnAddPortofolio.setOnClickListener(v -> showDialogAddEdit(null));

        loadPortofolio();
    }

    private void loadPortofolio() {
        containerPortofolio.removeAllViews();
        Cursor cursor = db.getPortofolioByUser(username);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String judul = cursor.getString(2);
                String deskripsi = cursor.getString(3);
                String imagePath = cursor.getString(4); // Not used yet for simplicity

                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerPortofolio, false);

                TextView textNama = view.findViewById(R.id.textNamaJasa);
                TextView textHarga = view.findViewById(R.id.textHargaJasa); // Reusing item_jasa layout
                TextView textKategori = view.findViewById(R.id.textKategoriJasa);
                ImageView btnEdit = view.findViewById(R.id.btnEditJasa);
                ImageView btnDelete = view.findViewById(R.id.btnDeleteJasa);

                textNama.setText(judul);
                textHarga.setText(deskripsi);
                textKategori.setVisibility(View.GONE); // Hide category for portfolio

                btnEdit.setOnClickListener(v -> showDialogAddEdit(id, judul, deskripsi));
                btnDelete.setOnClickListener(v -> {
                    db.deletePortofolio(id);
                    loadPortofolio();
                    Toast.makeText(this, "Portofolio dihapus", Toast.LENGTH_SHORT).show();
                });

                containerPortofolio.addView(view);

            } while (cursor.moveToNext());
        }
    }

    private void showDialogAddEdit(Integer id, String... data) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.activity_tambah_jasa, null); // Reuse layout or create
                                                                                            // simple one
        // For simplicity, let's create a dynamic view or reuse a simple input dialog
        // But to be proper, let's build a custom view here programmatically or use a
        // simple layout

        // Let's use a simple layout construction here for speed and correctness without
        // new files if possible,
        // but better to use a proper dialog layout. I'll use a simple programmatic
        // layout for the dialog.

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputJudul = new EditText(this);
        inputJudul.setHint("Judul Portofolio");
        layout.addView(inputJudul);

        final EditText inputDeskripsi = new EditText(this);
        inputDeskripsi.setHint("Deskripsi");
        layout.addView(inputDeskripsi);

        if (data != null && data.length > 0) {
            inputJudul.setText(data[0]);
            inputDeskripsi.setText(data[1]);
            builder.setTitle("Edit Portofolio");
        } else {
            builder.setTitle("Tambah Portofolio");
        }

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            String judul = inputJudul.getText().toString();
            String desk = inputDeskripsi.getText().toString();

            if (id == null) {
                if (db.insertPortofolio(username, judul, desk, "")) {
                    Toast.makeText(this, "Berhasil menambah portofolio", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (db.updatePortofolio(id, judul, desk, "")) {
                    Toast.makeText(this, "Berhasil update portofolio", Toast.LENGTH_SHORT).show();
                }
            }
            loadPortofolio();
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // Overload for add
    private void showDialogAddEdit(Integer id) {
        showDialogAddEdit(id, new String[] {});
    }
}
