
package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.net.Uri;
import androidx.cardview.widget.CardView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ProfilActivity extends AppCompatActivity {

    EditText inputUsername, inputEmail, inputPassword;
    Button btnSave, btnLogout;
    ImageView btnBack, imageProfile;
    CardView cardProfileImage;
    DatabaseHelper db;
    String currentUsername;
    int userId;
    String currentRole;
    Uri imageUri;
    String tempImagePath; // To store temporary path before saving

    private final ActivityResultLauncher<String> pickImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    // Copy to temp file immediately to avoid permission issues
                    String path = saveToInternalStorage(uri, "temp_profile_" + System.currentTimeMillis() + ".jpg");
                    if (path != null) {
                        tempImagePath = path;
                        imageUri = Uri.fromFile(new File(path));
                        imageProfile.setImageURI(imageUri);
                        imageProfile.setImageTintList(null);
                    } else {
                        Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        db = new DatabaseHelper(this);
        currentUsername = getIntent().getStringExtra("username");

        inputUsername = findViewById(R.id.inputUsername);
        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        btnSave = findViewById(R.id.btnSave);
        btnLogout = findViewById(R.id.btnLogout);
        btnBack = findViewById(R.id.btnBack);
        imageProfile = findViewById(R.id.imageProfile);
        cardProfileImage = findViewById(R.id.cardProfileImage);

        btnBack.setOnClickListener(v -> finish());

        loadProfile();

        cardProfileImage.setOnClickListener(v -> pickImage.launch("image/*"));

        btnSave.setOnClickListener(v -> saveProfile());

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(ProfilActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadProfile() {
        SQLiteDatabase readDb = db.getReadableDatabase();
        Cursor cursor = readDb.rawQuery("SELECT * FROM users WHERE username=?", new String[] { currentUsername });
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
            inputUsername.setText(cursor.getString(1));
            inputEmail.setText(cursor.getString(2));
            inputPassword.setText(cursor.getString(3));
            currentRole = cursor.getString(4);

            // Load image if exists
            String imagePath = db.getUserProfileImage(currentUsername);
            if (imagePath != null) {
                File imgFile = new File(imagePath);
                if (imgFile.exists()) {
                    imageProfile.setImageURI(Uri.fromFile(imgFile));
                    imageProfile.setImageTintList(null);
                }
            }
        }
        cursor.close();
    }

    private void saveProfile() {
        String newUsername = inputUsername.getText().toString();
        String newEmail = inputEmail.getText().toString();
        String newPassword = inputPassword.getText().toString();

        if (db.updateUser(userId, newUsername, newEmail, currentRole)) {
            SQLiteDatabase writeDb = db.getWritableDatabase();
            writeDb.execSQL("UPDATE users SET password=? WHERE id=?", new Object[] { newPassword, userId });

            if (tempImagePath != null) {
                // Rename temp file to permanent file
                File tempFile = new File(tempImagePath);
                String permanentFileName = "profile_" + newUsername + "_" + System.currentTimeMillis() + ".jpg";
                File permanentFile = new File(getFilesDir(), permanentFileName);

                if (tempFile.renameTo(permanentFile)) {
                    db.updateUserProfileImage(newUsername, permanentFile.getAbsolutePath());
                } else {
                    // Fallback if rename fails (e.g. different partitions), just use temp path or
                    // copy
                    db.updateUserProfileImage(newUsername, tempImagePath);
                }
            }

            Toast.makeText(this, "Profil diperbarui", Toast.LENGTH_SHORT).show();
            currentUsername = newUsername;
        } else {
            Toast.makeText(this, "Gagal memperbarui profil", Toast.LENGTH_SHORT).show();
        }
    }

    private String saveToInternalStorage(Uri uri, String fileName) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), fileName);
            OutputStream outputStream = new FileOutputStream(file);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
