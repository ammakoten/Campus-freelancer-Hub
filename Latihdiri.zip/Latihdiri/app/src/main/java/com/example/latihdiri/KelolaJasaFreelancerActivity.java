package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class KelolaJasaFreelancerActivity extends AppCompatActivity {

    LinearLayout containerJasa;
    ImageView btnBack;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kelola_jasa_freelancer);

        db = new DatabaseHelper(this);

        containerJasa = findViewById(R.id.containerJasa);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        loadAllJasa();
    }

    private void loadAllJasa() {
        containerJasa.removeAllViews();
        Cursor cursor = db.getAllJasa();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String username = cursor.getString(1);
                String nama = cursor.getString(2);
                String deskripsi = cursor.getString(3);
                String harga = cursor.getString(4);
                String kategori = cursor.getString(5);
                String imagePath = "";
                if (cursor.getColumnCount() > 6) {
                    imagePath = cursor.getString(6);
                }

                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerJasa, false);

                TextView textNama = view.findViewById(R.id.textNamaJasa);
                TextView textHarga = view.findViewById(R.id.textHargaJasa);
                TextView textKategori = view.findViewById(R.id.textKategoriJasa);
                ImageView btnEdit = view.findViewById(R.id.btnEditJasa);
                ImageView btnDelete = view.findViewById(R.id.btnDeleteJasa);

                textNama.setText(nama + " (" + username + ")");
                textHarga.setText(harga);
                textKategori.setText(kategori);

                ImageView imgJasa = view.findViewById(R.id.imgJasaInfo);
                if (imagePath != null && !imagePath.isEmpty()) {
                    imgJasa.setImageURI(android.net.Uri.parse(imagePath));
                    imgJasa.setScaleType(ImageView.ScaleType.CENTER_CROP);
                } else {
                    imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
                }

                btnEdit.setOnClickListener(v -> showDialogEdit(id, nama, deskripsi, harga, kategori));
                btnDelete.setOnClickListener(v -> {
                    db.deleteJasa(id);
                    loadAllJasa();
                    Toast.makeText(this, "Jasa dihapus", Toast.LENGTH_SHORT).show();
                });

                containerJasa.addView(view);

            } while (cursor.moveToNext());
        }
    }

    private void showDialogEdit(int id, String nama, String deskripsi, String harga, String kategori) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Jasa Freelancer");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputNama = new EditText(this);
        inputNama.setText(nama);
        layout.addView(inputNama);

        final EditText inputDeskripsi = new EditText(this);
        inputDeskripsi.setText(deskripsi);
        layout.addView(inputDeskripsi);

        final EditText inputHarga = new EditText(this);
        inputHarga.setText(harga);
        layout.addView(inputHarga);

        final EditText inputKategori = new EditText(this);
        inputKategori.setText(kategori);
        layout.addView(inputKategori);

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            if (db.updateJasa(id, inputNama.getText().toString(), inputDeskripsi.getText().toString(),
                    inputHarga.getText().toString(), inputKategori.getText().toString(), null)) {
                Toast.makeText(this, "Jasa diperbarui", Toast.LENGTH_SHORT).show();
                loadAllJasa();
            }
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}
