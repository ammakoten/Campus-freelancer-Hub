package com.example.latihdiri;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText editTextNewUsername, editTextNewEmail, editTextNewPassword;
    Spinner spinnerRole;
    Button buttonCreateAccount;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DatabaseHelper(this);

        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewEmail = findViewById(R.id.editTextNewEmail);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        spinnerRole = findViewById(R.id.spinnerRole);

        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // ✅ Isi daftar role untuk spinner
        String[] roles = { "Freelancers", "Klien" };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_item,
                roles);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        // Tombol buat akun
        buttonCreateAccount.setOnClickListener(v -> {

            String username = editTextNewUsername.getText().toString().trim();
            String email = editTextNewEmail.getText().toString().trim();
            String password = editTextNewPassword.getText().toString().trim();
            String role = spinnerRole.getSelectedItem().toString();

            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi!", Toast.LENGTH_SHORT).show();
                return;
            }

            // 🔐 Validasi Password Standar
            if (password.length() < 8) {
                Toast.makeText(this, "Password minimal 8 karakter!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.matches(".*[A-Z].*")) {
                Toast.makeText(this, "Password harus ada huruf besar (A-Z)!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.matches(".*[a-z].*")) {
                Toast.makeText(this, "Password harus ada huruf kecil (a-z)!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.matches(".*[0-9].*")) {
                Toast.makeText(this, "Password harus ada angka (0-9)!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.matches(".*[!@#$%^&*].*")) {
                Toast.makeText(this, "Password harus ada simbol (!@#$%^&*)!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = db.insertUser(username, email, password, role);

            if (inserted) {
                Toast.makeText(this, "Akun berhasil dibuat! Silakan Login", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Gagal! Username sudah digunakan!", Toast.LENGTH_LONG).show();
            }
        });

        // 🔙 Tombol kembali ke login (DIHAPUS SESUAI REQUEST)
        // buttonBack.setOnClickListener(v -> {
        // startActivity(new Intent(RegisterActivity.this, MainActivity.class));
        // });
    }
}
