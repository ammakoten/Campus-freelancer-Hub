package com.example.latihdiri;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ProfilFreelancerActivity extends AppCompatActivity {

    private ImageView imgBanner, btnBack, btnEditBanner, imgProfile;
    private CardView cardProfile;
    private TextView textName, textUsername, textRole;
    private TextView statTotalJasa, statTotalOrder, statRating;
    private TextView textBio, textSkills, textPhone, textEmail;
    private Button btnEditProfile;
    private LinearLayout containerMyServices, containerIncomingOrders, containerPortfolio; // NEW Portfolio container

    private DatabaseHelper db;
    private String currentUsername;
    private int userId;
    private boolean isPickingBanner = false;
    private boolean isPickingPortfolio = false; // Flag for portfolio image
    private EditText inputPortfolioTitle, inputPortfolioDesc; // For dialog access
    private ImageView imgPreviewPortfolio; // For dialog access

    private final ActivityResultLauncher<String> pickImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    String type = isPickingBanner ? "banner" : isPickingPortfolio ? "portfolio" : "avatar";
                    String filename = type + "_" + currentUsername + "_" + System.currentTimeMillis() + ".jpg";
                    String path = saveToInternalStorage(uri, filename);

                    if (path != null) {
                        if (isPickingBanner) {
                            db.updateUserBanner(currentUsername, path);
                            imgBanner.setImageURI(Uri.fromFile(new File(path)));
                            Toast.makeText(this, "Banner diperbarui", Toast.LENGTH_SHORT).show();
                        } else if (isPickingPortfolio) {
                            // Temporarily store path or show preview in dialog
                            // We need to store this path in a tag or variable to save it later when "Save"
                            // is clicked
                            if (imgPreviewPortfolio != null) {
                                imgPreviewPortfolio.setImageURI(Uri.fromFile(new File(path)));
                                imgPreviewPortfolio.setTag(path); // Store path in tag
                            }
                        } else {
                            db.updateUserProfileImage(currentUsername, path);
                            imgProfile.setImageURI(Uri.fromFile(new File(path)));
                            Toast.makeText(this, "Foto Profil diperbarui", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_freelancer);

        if (getSupportActionBar() != null)
            getSupportActionBar().hide();

        db = new DatabaseHelper(this);
        currentUsername = getIntent().getStringExtra("username");

        initializeViews();
        loadProfileData();
        setupListeners();
    }

    private void initializeViews() {
        imgBanner = findViewById(R.id.imgBanner);
        btnBack = findViewById(R.id.btnBack);
        btnEditBanner = findViewById(R.id.btnEditBanner);
        imgProfile = findViewById(R.id.imgProfile);
        cardProfile = findViewById(R.id.cardProfile);
        textName = findViewById(R.id.textName);
        textUsername = findViewById(R.id.textUsername);
        textRole = findViewById(R.id.textRole);
        statTotalJasa = findViewById(R.id.statTotalJasa);
        statTotalOrder = findViewById(R.id.statTotalOrder);
        statRating = findViewById(R.id.statRating);
        textBio = findViewById(R.id.textBio);
        textSkills = findViewById(R.id.textSkills);
        textPhone = findViewById(R.id.textPhone);
        textEmail = findViewById(R.id.textEmail);
        btnEditProfile = findViewById(R.id.btnEditProfile);
        containerMyServices = findViewById(R.id.containerMyServices);
        containerIncomingOrders = findViewById(R.id.containerIncomingOrders);
        containerPortfolio = findViewById(R.id.containerPortfolio); // Init Portfolio
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnEditBanner.setOnClickListener(v -> {
            isPickingBanner = true;
            pickImage.launch("image/*");
        });

        cardProfile.setOnClickListener(v -> {
            isPickingBanner = false;
            pickImage.launch("image/*");
        });

        findViewById(R.id.btnAddPortfolio).setOnClickListener(v -> showAddPortfolioDialog()); // Add Listener

        btnEditProfile.setOnClickListener(v -> showEditProfileDialog());

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            getSharedPreferences("UserSession", MODE_PRIVATE).edit().clear().apply();
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadProfileData() {
        // Load User Info
        Cursor cursor = db.getUserByUsername(currentUsername);
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0); // id
            // 1=username, 2=email, 3=password, 4=role, 5=profile_image
            // 6=full_name, 7=phone, 8=bio, 9=skills, 10=status, 11=join_date,
            // 12=banner_image

            String username = cursor.getString(1);
            String email = cursor.getString(2);
            String role = cursor.getString(4);
            String profileImg = cursor.getString(5);

            // Handle potentially missing columns if migration failed silentely (fallback)
            String fullName = cursor.getColumnCount() > 6 ? cursor.getString(6) : username;
            String phone = cursor.getColumnCount() > 7 ? cursor.getString(7) : "-";
            String bio = cursor.getColumnCount() > 8 ? cursor.getString(8) : "Belum ada bio.";
            String skills = cursor.getColumnCount() > 9 ? cursor.getString(9) : "-";
            String bannerImg = cursor.getColumnCount() > 12 ? cursor.getString(12) : null;

            textUsername.setText("@" + username);
            textEmail.setText(email);
            textRole.setText(role);
            textName.setText((fullName != null && !fullName.isEmpty()) ? fullName : username);
            textPhone.setText((phone != null && !phone.isEmpty()) ? phone : "-");
            textBio.setText((bio != null && !bio.isEmpty()) ? bio : "Belum ada bio.");
            textSkills.setText((skills != null && !skills.isEmpty()) ? skills : "-");

            // Load Images
            if (profileImg != null) {
                File f = new File(profileImg);
                if (f.exists())
                    imgProfile.setImageURI(Uri.fromFile(f));
            }
            if (bannerImg != null) {
                File f = new File(bannerImg);
                if (f.exists())
                    imgBanner.setImageURI(Uri.fromFile(f));
            }
        }
        cursor.close();

        // Load Stats
        statTotalJasa.setText(String.valueOf(db.getFreelancerServiceCount(currentUsername)));
        statTotalOrder.setText(String.valueOf(db.getFreelancerOrderCount(currentUsername)));
        double rating = db.getFreelancerAverageRating(currentUsername);
        statRating.setText(String.format("%.1f", rating));

        // Load Lists
        loadMyServices();
        loadIncomingOrders();
        loadPortfolio(); // Load Portfolio
    }

    private void loadPortfolio() {
        containerPortfolio.removeAllViews();
        Cursor cursor = db.getPortofolioByUser(currentUsername);
        if (cursor.moveToFirst()) {
            do {
                String title = cursor.getString(2);
                String desc = cursor.getString(3);
                String imgPath = cursor.getString(4);

                View view = LayoutInflater.from(this).inflate(R.layout.item_portfolio, containerPortfolio, false);
                ImageView img = view.findViewById(R.id.imgPortfolio);
                TextView tTitle = view.findViewById(R.id.textPortfolioTitle);
                TextView tDesc = view.findViewById(R.id.textPortfolioDesc);

                tTitle.setText(title);
                tDesc.setText(desc);
                if (imgPath != null) {
                    File f = new File(imgPath);
                    if (f.exists())
                        img.setImageURI(Uri.fromFile(f));
                }

                containerPortfolio.addView(view);

            } while (cursor.moveToNext());
        } else {
            // Optional: Show empty state or just leave blank
        }
        cursor.close();
    }

    private void loadMyServices() {
        containerMyServices.removeAllViews();
        Cursor cursor = db.getJasaByUser(currentUsername);
        if (cursor.moveToFirst()) {
            do {
                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerMyServices, false);

                TextView tName = view.findViewById(R.id.textNamaJasa);
                TextView tPrice = view.findViewById(R.id.textHargaJasa);
                TextView tCat = view.findViewById(R.id.textKategoriJasa);
                ImageView img = view.findViewById(R.id.imgJasaInfo);

                // Hide buttons for read-only view in profile (or keep them?)
                // User requirement implies "Managing" is done separately, but viewing is fine.
                // Let's keep them hidden or make them non-functional here to avoid clutter,
                // OR allow deep link to edit.
                view.findViewById(R.id.btnEditJasa).setVisibility(View.GONE);
                view.findViewById(R.id.btnDeleteJasa).setVisibility(View.GONE);

                tName.setText(cursor.getString(2)); // nama_jasa
                tPrice.setText(cursor.getString(4)); // harga
                tCat.setText(cursor.getString(5)); // kategori

                // Image
                if (cursor.getColumnCount() > 6) {
                    String path = cursor.getString(6);
                    if (path != null)
                        img.setImageURI(Uri.parse(path));
                }

                containerMyServices.addView(view);
            } while (cursor.moveToNext());
        } else {
            TextView empty = new TextView(this);
            empty.setText("Belum ada jasa.");
            empty.setPadding(0, 10, 0, 10);
            containerMyServices.addView(empty);
        }
        cursor.close();
    }

    private void showAddPortfolioDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Tambah Portofolio");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 10);

        // Image Preview
        imgPreviewPortfolio = new ImageView(this);
        imgPreviewPortfolio.setImageResource(R.drawable.ic_insert_drive_file); // Placeholder
        imgPreviewPortfolio.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 400);
        params.bottomMargin = 20;
        imgPreviewPortfolio.setLayoutParams(params);
        imgPreviewPortfolio.setBackgroundColor(android.graphics.Color.LTGRAY);
        layout.addView(imgPreviewPortfolio);

        imgPreviewPortfolio.setOnClickListener(v -> {
            isPickingPortfolio = true;
            isPickingBanner = false; // Reset others
            pickImage.launch("image/*");
        });

        TextView hint = new TextView(this);
        hint.setText("Klik gambar untuk upload");
        hint.setGravity(android.view.Gravity.CENTER);
        layout.addView(hint);

        inputPortfolioTitle = new EditText(this);
        inputPortfolioTitle.setHint("Judul Project");
        layout.addView(inputPortfolioTitle);

        inputPortfolioDesc = new EditText(this);
        inputPortfolioDesc.setHint("Deskripsi Singkat");
        layout.addView(inputPortfolioDesc);

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            String title = inputPortfolioTitle.getText().toString();
            String desc = inputPortfolioDesc.getText().toString();
            String path = (String) imgPreviewPortfolio.getTag();

            if (path == null) {
                Toast.makeText(this, "Harap pilih gambar", Toast.LENGTH_SHORT).show();
                return;
            }
            if (title.isEmpty()) {
                Toast.makeText(this, "Judul harus diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.insertPortofolio(currentUsername, title, desc, path)) {
                Toast.makeText(this, "Portofolio ditambahkan", Toast.LENGTH_SHORT).show();
                loadPortfolio();
            } else {
                Toast.makeText(this, "Gagal menambah", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void loadIncomingOrders() {
        containerIncomingOrders.removeAllViews();
        Cursor cursor = db.getOrdersByFreelancer(currentUsername);
        if (cursor.moveToFirst()) {
            do {
                // Display latest orders (maybe limit 5?)
                // Schema: 0id, 1client, 2freelancer, 3svcId, 4svcName, 5status, 6notes,
                // 7date...
                String client = cursor.getString(1);
                String svcName = cursor.getString(4);
                String status = cursor.getString(5);
                String notes = cursor.getString(6);

                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerIncomingOrders, false);
                TextView tName = view.findViewById(R.id.textNamaJasa); // Repurposed for Order Info
                TextView tPrice = view.findViewById(R.id.textHargaJasa);
                TextView tCat = view.findViewById(R.id.textKategoriJasa);

                view.findViewById(R.id.btnEditJasa).setVisibility(View.GONE);
                view.findViewById(R.id.btnDeleteJasa).setVisibility(View.GONE);
                view.findViewById(R.id.imgJasaInfo).setVisibility(View.GONE); // Hide service image for cleaner order
                                                                              // list

                tName.setText("Dari: " + client);
                tPrice.setText(svcName);
                tCat.setText("Status: " + status);

                if (status.equals("Pending"))
                    tCat.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
                else if (status.equals("Selesai"))
                    tCat.setTextColor(getResources().getColor(android.R.color.holo_green_dark));

                containerIncomingOrders.addView(view);

                // Add Click Listener to show Client Details
                view.setOnClickListener(v -> showClientDetailsDialog(client, svcName, notes, status));
            } while (cursor.moveToNext());
        } else {
            TextView empty = new TextView(this);
            empty.setText("Belum ada pesanan.");
            empty.setPadding(0, 10, 0, 10);
            containerIncomingOrders.addView(empty);
        }
        cursor.close();
    }

    private void showEditProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Profil");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputName = new EditText(this);
        inputName.setHint("Nama Lengkap");
        inputName.setText(textName.getText().toString());
        layout.addView(inputName);

        final EditText inputPhone = new EditText(this);
        inputPhone.setHint("Nomor HP");
        inputPhone.setText(textPhone.getText().toString());
        inputPhone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        layout.addView(inputPhone);

        final EditText inputBio = new EditText(this);
        inputBio.setHint("Bio / Deskripsi Singkat");
        inputBio.setText(textBio.getText().toString());
        layout.addView(inputBio);

        final EditText inputSkills = new EditText(this);
        inputSkills.setHint("Keahlian (pisahkan koma)");
        inputSkills.setText(textSkills.getText().toString());
        layout.addView(inputSkills);

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            if (db.updateDetailedProfile(userId,
                    inputName.getText().toString(),
                    inputPhone.getText().toString(),
                    inputBio.getText().toString(),
                    inputSkills.getText().toString())) {
                Toast.makeText(this, "Profil diperbarui", Toast.LENGTH_SHORT).show();
                loadProfileData();
            } else {
                Toast.makeText(this, "Gagal update", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private String saveToInternalStorage(Uri uri, String fileName) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), fileName);
            OutputStream outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void showClientDetailsDialog(String clientUsername, String serviceName, String notes, String status) {
        String phone = "-";

        Cursor c = db.getUserByUsername(clientUsername);
        if (c.moveToFirst()) {
            // phone is index 7
            if (c.getColumnCount() > 7) {
                phone = c.getString(7);
            }
        }
        c.close();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Detail Pesanan");
        builder.setMessage("Client: " + clientUsername + "\n" +
                "No HP: " + (phone != null && !phone.isEmpty() ? phone : "-") + "\n\n" +
                "Jasa: " + serviceName + "\n" +
                "Status: " + status + "\n" +
                "Catatan Client:\n" + notes);
        builder.setPositiveButton("Tutup", null);
        builder.show();
    }
}
