package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailTipsActivity extends AppCompatActivity {

    private TextView textTipTitleHeader, textTipTitleContent, textTipBody;
    private ImageView imgTipDetail;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tips);

        initializeViews();
        setupToolbar();
        loadTipData();
    }

    private void initializeViews() {
        textTipTitleHeader = findViewById(R.id.textTipTitleHeader);
        textTipTitleContent = findViewById(R.id.textTipTitleContent);
        textTipBody = findViewById(R.id.textTipBody);
        imgTipDetail = findViewById(R.id.imgTipDetail);
        toolbar = findViewById(R.id.toolbar);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void loadTipData() {
        String title = getIntent().getStringExtra("tip_title");
        String content = getIntent().getStringExtra("tip_content");

        if (title != null) {
            textTipTitleHeader.setText("Tips");
            textTipTitleContent.setText(title);
        }

        if (content != null) {
            textTipBody.setText(content);
        }
    }
}
