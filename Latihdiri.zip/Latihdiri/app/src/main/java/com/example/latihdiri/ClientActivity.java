package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ClientActivity extends AppCompatActivity {

    TextView textTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);

        String username = getIntent().getStringExtra("username");

        // NAV BOTTOM (LinearLayout)
        android.view.View navBeranda = findViewById(R.id.navBeranda);
        android.view.View navCariJasa = findViewById(R.id.navCariJasa);
        android.view.View navPesanJasa = findViewById(R.id.navPesanJasa);
        android.view.View navPesananSaya = findViewById(R.id.navPesananSaya);
        android.view.View navProfil = findViewById(R.id.navProfil);

        // DASHBOARD ELEMENTS
        android.widget.EditText searchBar = findViewById(R.id.searchBar);
        android.view.View btnGridLogo = findViewById(R.id.btnGridLogo);
        android.view.View btnGridWeb = findViewById(R.id.btnGridWeb);
        android.view.View btnGridApp = findViewById(R.id.btnGridApp);
        android.view.View btnGridSEO = findViewById(R.id.btnGridSEO);

        // Klik beranda → tetap di halaman ini
        navBeranda.setOnClickListener(v -> {
            // Do nothing
        });

        // Klik Cari Jasa
        navCariJasa.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Klik Pesan Jasa
        navPesanJasa.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Klik Pesanan Saya
        navPesananSaya.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, PesananSayaActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Klik Profil
        navProfil.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, ProfilClientActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // CATEGORY BUTTONS
        android.view.View btnCatPopular = findViewById(R.id.btnCatPopular);
        android.view.View btnCatDesign = findViewById(R.id.btnCatDesign);
        android.view.View btnCatWeb = findViewById(R.id.btnCatWeb);

        android.view.View.OnClickListener categoryListener = v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        };

        btnCatPopular.setOnClickListener(categoryListener);
        btnCatDesign.setOnClickListener(categoryListener);
        btnCatWeb.setOnClickListener(categoryListener);

        // SEARCH & CATEGORIES
        android.view.View.OnClickListener searchListener = v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        };

        // Search Bar Logic with Clear Button
        if (searchBar != null) {
            searchBar.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length() > 0) {
                        searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, R.drawable.ic_close,
                                0);
                    } else {
                        searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0);
                    }
                }

                @Override
                public void afterTextChanged(android.text.Editable s) {
                }
            });

            searchBar.setOnTouchListener((v, event) -> {
                if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    if (searchBar.getCompoundDrawables()[2] != null) {
                        if (event.getRawX() >= (searchBar.getRight()
                                - searchBar.getCompoundDrawables()[2].getBounds().width() - 50)) {
                            searchBar.setText("");
                            return true;
                        }
                    }
                }
                return false;
            });

            searchBar.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH ||
                        actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE ||
                        event != null && event.getAction() == android.view.KeyEvent.ACTION_DOWN
                                && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER) {

                    String query = searchBar.getText().toString().trim();
                    Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
                    i.putExtra("username", username);
                    i.putExtra("search_query", query);
                    startActivity(i);
                    return true;
                }
                return false;
            });
        }

        // Specific Category Listeners
        btnGridLogo.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            i.putExtra("search_query", "Desain Logo");
            startActivity(i);
        });

        btnGridWeb.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            i.putExtra("search_query", "Karakter");
            startActivity(i);
        });

        btnGridApp.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            i.putExtra("search_query", "Arsitek");
            startActivity(i);
        });

        btnGridSEO.setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, CariJasaActivity.class);
            i.putExtra("username", username);
            i.putExtra("search_query", "Video");
            startActivity(i);
        });

        // Support Chat
        findViewById(R.id.btnSupportChat).setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, ChatActivity.class);
            i.putExtra("target_user", "admin");
            startActivity(i);
        });

        // Notification Button
        findViewById(R.id.btnNotification).setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, NotificationActivity.class);
            startActivity(i);
        });

        // TIPS SUKSES CLICK LISTENERS
        findViewById(R.id.tipCard1).setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, DetailTipsActivity.class);
            i.putExtra("tip_title", "Cara Memilih Freelancer Tepat");
            i.putExtra("tip_content", "Berikut adalah tips untuk memilih freelancer yang tepat:\n\n" +
                    "1. Lihat Rating dan Ulasan: Selalu periksa apa yang dikatakan klien sebelumnya tentang freelancer tersebut.\n\n"
                    +
                    "2. Periksa Portofolio: Pastikan gaya kerja mereka sesuai dengan kebutuhan proyek Anda.\n\n" +
                    "3. Komunikasi: Cobalah berkomunikasi terlebih dahulu sebelum memesan untuk memastikan mereka responsif.\n\n"
                    +
                    "4. Deskripsi Jasa: Baca dengan teliti apa saja yang termasuk dalam paket jasa yang ditawarkan.");
            startActivity(i);
        });

        findViewById(R.id.tipCard2).setOnClickListener(v -> {
            Intent i = new Intent(ClientActivity.this, DetailTipsActivity.class);
            i.putExtra("tip_title", "Keamanan Transaksi");
            i.putExtra("tip_content", "Keamanan Anda adalah prioritas kami. Ikuti panduan ini:\n\n" +
                    "1. Gunakan Sistem LatihDiri: Jangan pernah melakukan pembayaran di luar aplikasi. Pembayaran melalui sistem kami menjamin dana Anda aman hingga hasil diterima.\n\n"
                    +
                    "2. Jaga Data Pribadi: Jangan memberikan informasi pribadi yang sensitif seperti password atau nomor OTP kepada siapapun.\n\n"
                    +
                    "3. Verifikasi Hasil: Pastikan Anda memeriksa hasil pekerjaan dengan teliti sebelum menandai pesanan sebagai selesai.\n\n"
                    +
                    "4. Laporkan Masalah: Jika terjadi kendala atau perilaku mencurigakan, segera hubungi tim support kami.");
            startActivity(i);
        });

        // Setup Top Freelancers RecyclerView
        setupTopFreelancers();
    }

    private void setupTopFreelancers() {
        androidx.recyclerview.widget.RecyclerView recyclerView = findViewById(R.id.recyclerTopFreelancers);
        androidx.recyclerview.widget.LinearLayoutManager layoutManager = new androidx.recyclerview.widget.LinearLayoutManager(
                this,
                androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        FreelancerAdapter adapter = new FreelancerAdapter(this);
        recyclerView.setAdapter(adapter);

        // Load freelancers from database
        loadTopFreelancers(adapter);
    }

    private void loadTopFreelancers(FreelancerAdapter adapter) {
        DatabaseHelper db = new DatabaseHelper(this);
        android.database.Cursor cursor = db.getTopFreelancers(10);

        java.util.List<FreelancerAdapter.FreelancerItem> freelancers = new java.util.ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String username = cursor.getString(cursor.getColumnIndexOrThrow("username"));
                String skills = cursor.getString(cursor.getColumnIndexOrThrow("skills"));
                double rating = cursor.getDouble(cursor.getColumnIndexOrThrow("avg_rating"));

                String profileImage = cursor.getString(cursor.getColumnIndexOrThrow("profile_image"));
                String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow("phone_number"));
                String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));

                // Default rating to 5.0 if no ratings yet
                if (rating == 0.0) {
                    rating = 5.0;
                }

                freelancers.add(new FreelancerAdapter.FreelancerItem(username, skills, rating, profileImage,
                        phoneNumber, email));
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter.setFreelancers(freelancers);
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkUnreadNotifications();
    }

    private void checkUnreadNotifications() {
        android.view.View viewBadge = findViewById(R.id.viewBadge);
        DatabaseHelper db = new DatabaseHelper(this);
        String username = getIntent().getStringExtra("username");

        boolean hasUnread = false;

        // Check Messages
        android.database.Cursor cursorMsg = db.getUnreadMessages(username);
        if (cursorMsg != null && cursorMsg.getCount() > 0) {
            hasUnread = true;
        }
        if (cursorMsg != null)
            cursorMsg.close();

        // Check Completed Orders (for Client)
        if (!hasUnread) {
            int unseenOrders = db.getUnseenCompletedOrdersCount(username);
            if (unseenOrders > 0) {
                hasUnread = true;
            }
        }

        viewBadge.setVisibility(hasUnread ? android.view.View.VISIBLE : android.view.View.GONE);
    }
}
