package com.example.latihdiri;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ProfilAdminActivity extends AppCompatActivity {

    private ImageView imgBanner, btnBack, btnEditBanner, imgProfile;
    private CardView cardProfile;
    private TextView textName, textUsername;
    private TextView textPhone, textEmail;
    private Button btnEditProfile;

    private DatabaseHelper db;
    private String currentUsername;
    private int userId;
    private boolean isPickingBanner = false;

    private final ActivityResultLauncher<String> pickImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    String type = isPickingBanner ? "banner" : "avatar";
                    String filename = type + "_" + currentUsername + "_" + System.currentTimeMillis() + ".jpg";
                    String path = saveToInternalStorage(uri, filename);

                    if (path != null) {
                        if (isPickingBanner) {
                            db.updateUserBanner(currentUsername, path);
                            imgBanner.setImageURI(Uri.fromFile(new File(path)));
                        } else {
                            db.updateUserProfileImage(currentUsername, path);
                            imgProfile.setImageURI(Uri.fromFile(new File(path)));
                        }
                        Toast.makeText(this, "Gambar diperbarui", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_admin);

        if (getSupportActionBar() != null)
            getSupportActionBar().hide();

        db = new DatabaseHelper(this);
        currentUsername = getIntent().getStringExtra("username");

        initializeViews();
        loadProfileData();
        setupListeners();
    }

    private void initializeViews() {
        imgBanner = findViewById(R.id.imgBanner);
        btnBack = findViewById(R.id.btnBack);
        btnEditBanner = findViewById(R.id.btnEditBanner);
        imgProfile = findViewById(R.id.imgProfile);
        cardProfile = findViewById(R.id.cardProfile);
        textName = findViewById(R.id.textName);
        textUsername = findViewById(R.id.textUsername);

        textPhone = findViewById(R.id.textPhone);
        textEmail = findViewById(R.id.textEmail);

        btnEditProfile = findViewById(R.id.btnEditProfile);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnEditBanner.setOnClickListener(v -> {
            isPickingBanner = true;
            pickImage.launch("image/*");
        });

        cardProfile.setOnClickListener(v -> {
            isPickingBanner = false;
            pickImage.launch("image/*");
        });

        btnEditProfile.setOnClickListener(v -> showEditProfileDialog());

        findViewById(R.id.btnManageUsers)
                .setOnClickListener(v -> startActivity(new Intent(this, KelolaAkunUserActivity.class)));

        findViewById(R.id.btnManageServices).setOnClickListener(v -> {
            Intent intent = new Intent(this, KelolaJasaActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        });

        findViewById(R.id.btnManageOrders)
                .setOnClickListener(v -> startActivity(new Intent(this, KelolaPesananActivity.class)));

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            // Clear Session
            getSharedPreferences("UserSession", MODE_PRIVATE).edit().clear().apply();
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadProfileData() {
        // Load User Info
        Cursor cursor = db.getUserByUsername(currentUsername);
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);

            String username = cursor.getString(1);
            String email = cursor.getString(2);
            String profileImg = cursor.getString(5);
            String fullName = cursor.getColumnCount() > 6 ? cursor.getString(6) : username;
            String phone = cursor.getColumnCount() > 7 ? cursor.getString(7) : null;
            String bannerImg = cursor.getColumnCount() > 12 ? cursor.getString(12) : null;

            textUsername.setText("@" + username);
            textName.setText((fullName != null && !fullName.isEmpty()) ? fullName : username);

            // Load contact information
            textEmail.setText(email != null && !email.isEmpty() ? email : "-");
            textPhone.setText(phone != null && !phone.isEmpty() ? phone : "-");

            if (profileImg != null) {
                File f = new File(profileImg);
                if (f.exists())
                    imgProfile.setImageURI(Uri.fromFile(f));
            }
            if (bannerImg != null) {
                File f = new File(bannerImg);
                if (f.exists())
                    imgBanner.setImageURI(Uri.fromFile(f));
            }
        }
        cursor.close();
    }

    private void showEditProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Profil Admin");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputName = new EditText(this);
        inputName.setHint("Nama Lengkap");
        inputName.setText(textName.getText().toString());
        layout.addView(inputName);

        builder.setView(layout);

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            // Using updateDetailedProfile (phone/bio/skills null)
            if (db.updateDetailedProfile(userId,
                    inputName.getText().toString(),
                    null, null, null)) {
                Toast.makeText(this, "Profil diperbarui", Toast.LENGTH_SHORT).show();
                loadProfileData();
            } else {
                Toast.makeText(this, "Gagal update", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Batal", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private String saveToInternalStorage(Uri uri, String fileName) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), fileName);
            OutputStream outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
