package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class CariJasaActivity extends AppCompatActivity {

    LinearLayout containerJasa;
    ImageView btnBack, btnFilter, btnSort;
    DatabaseHelper db;
    String clientUsername;
    TextView textNoResults, textFilterCount;
    EditText searchBar;

    // Filter variables
    private String currentCategory = "Semua";
    private Integer minPrice = null;
    private Integer maxPrice = null;
    private String sortBy = "newest"; // newest, price_low, price_high, rating

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cari_jasa);

        db = new DatabaseHelper(this);
        clientUsername = getIntent().getStringExtra("username");
        String initialQuery = getIntent().getStringExtra("search_query");

        containerJasa = findViewById(R.id.containerJasa);
        btnBack = findViewById(R.id.btnBack);
        btnFilter = findViewById(R.id.btnFilter);
        btnSort = findViewById(R.id.btnSort);
        textNoResults = findViewById(R.id.textNoResults);
        textFilterCount = findViewById(R.id.textFilterCount);
        searchBar = findViewById(R.id.searchBar);

        btnBack.setOnClickListener(v -> finish());

        // Filter button
        if (btnFilter != null) {
            btnFilter.setOnClickListener(v -> showFilterDialog());
        }

        // Sort button
        if (btnSort != null) {
            btnSort.setOnClickListener(v -> showSortDialog());
        }

        // Search functionality
        if (searchBar != null) {
            searchBar.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    performSearch();
                    updateClearButton(s.length() > 0);
                }

                @Override
                public void afterTextChanged(android.text.Editable s) {
                }
            });

            searchBar.setOnTouchListener((v, event) -> {
                if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    if (searchBar.getCompoundDrawables()[2] != null) {
                        if (event.getRawX() >= (searchBar.getRight()
                                - searchBar.getCompoundDrawables()[2].getBounds().width() - 50)) {
                            searchBar.setText("");
                            return true;
                        }
                    }
                }
                return false;
            });

            searchBar.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH ||
                        actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                    performSearch();
                    // Hide keyboard
                    android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(
                            android.content.Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(searchBar.getWindowToken(), 0);
                    return true;
                }
                return false;
            });
        }

        // Handle initial search from ClientActivity
        if (initialQuery != null && !initialQuery.isEmpty()) {
            if (searchBar != null) {
                searchBar.setText(initialQuery);
            }
            performSearch();
        } else {
            loadAllJasa();
        }
    }

    private void showFilterDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_filter, null);

        Spinner spinnerCategory = dialogView.findViewById(R.id.spinnerCategory);
        EditText editMinPrice = dialogView.findViewById(R.id.editMinPrice);
        EditText editMaxPrice = dialogView.findViewById(R.id.editMaxPrice);
        Button btnClearFilter = dialogView.findViewById(R.id.btnClearFilter);

        // Setup category spinner
        String[] categories = { "Semua", "Desain Logo", "Karakter", "Arsitek", "Video", "Web Development", "Mobile App",
                "SEO" };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        // Set current values
        for (int i = 0; i < categories.length; i++) {
            if (categories[i].equals(currentCategory)) {
                spinnerCategory.setSelection(i);
                break;
            }
        }
        if (minPrice != null)
            editMinPrice.setText(String.valueOf(minPrice));
        if (maxPrice != null)
            editMaxPrice.setText(String.valueOf(maxPrice));

        builder.setView(dialogView);
        builder.setTitle("Filter Jasa");

        AlertDialog dialog = builder.create();

        btnClearFilter.setOnClickListener(v -> {
            currentCategory = "Semua";
            minPrice = null;
            maxPrice = null;
            updateFilterCount();
            performSearch();
            dialog.dismiss();
            Toast.makeText(this, "Filter dibersihkan", Toast.LENGTH_SHORT).show();
        });

        builder.setPositiveButton("Terapkan", (d, which) -> {
            currentCategory = spinnerCategory.getSelectedItem().toString();

            String minStr = editMinPrice.getText().toString().trim();
            String maxStr = editMaxPrice.getText().toString().trim();

            if (!minStr.isEmpty() && !maxStr.isEmpty()) {
                try {
                    minPrice = Integer.parseInt(minStr);
                    maxPrice = Integer.parseInt(maxStr);

                    if (minPrice > maxPrice) {
                        Toast.makeText(this, "Harga minimum tidak boleh lebih besar dari maksimum", Toast.LENGTH_SHORT)
                                .show();
                        return;
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Format harga tidak valid", Toast.LENGTH_SHORT).show();
                    return;
                }
            } else {
                minPrice = null;
                maxPrice = null;
            }

            updateFilterCount();
            performSearch();
        });

        builder.setNegativeButton("Batal", null);
        builder.show();
    }

    private void showSortDialog() {
        String[] sortOptions = { "Terbaru", "Harga Terendah", "Harga Tertinggi", "Rating Tertinggi" };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Urutkan Berdasarkan");
        builder.setItems(sortOptions, (dialog, which) -> {
            switch (which) {
                case 0:
                    sortBy = "newest";
                    break;
                case 1:
                    sortBy = "price_low";
                    break;
                case 2:
                    sortBy = "price_high";
                    break;
                case 3:
                    sortBy = "rating";
                    break;
            }
            performSearch();
            Toast.makeText(this, "Diurutkan: " + sortOptions[which], Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }

    private void updateFilterCount() {
        if (textFilterCount == null)
            return;

        int filterCount = 0;
        if (!currentCategory.equals("Semua"))
            filterCount++;
        if (minPrice != null && maxPrice != null)
            filterCount++;

        if (filterCount > 0) {
            textFilterCount.setText(String.valueOf(filterCount));
            textFilterCount.setVisibility(View.VISIBLE);
        } else {
            textFilterCount.setVisibility(View.GONE);
        }
    }

    private void performSearch() {
        String query = searchBar != null ? searchBar.getText().toString().trim() : "";

        Cursor cursor;
        if (query.isEmpty() && currentCategory.equals("Semua") && minPrice == null) {
            cursor = db.getActiveServices();
        } else {
            cursor = db.searchServicesAdvanced(
                    query.isEmpty() ? null : query,
                    currentCategory.equals("Semua") ? null : currentCategory,
                    minPrice,
                    maxPrice);
        }

        displayJasa(cursor);
    }

    private void loadAllJasa() {
        Cursor cursor = db.getActiveServices();
        displayJasa(cursor);
    }

    private void displayJasa(Cursor cursor) {
        containerJasa.removeAllViews();

        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
            textNoResults.setVisibility(View.GONE);

            // Convert cursor to list for sorting
            java.util.List<ServiceItem> services = new java.util.ArrayList<>();
            do {
                ServiceItem item = new ServiceItem();
                item.id = cursor.getInt(0);
                item.freelancer = cursor.getString(1);
                item.nama = cursor.getString(2);
                item.deskripsi = cursor.getString(3);
                item.harga = cursor.getString(4);
                item.kategori = cursor.getString(5);
                item.imagePath = cursor.getColumnCount() > 6 ? cursor.getString(6) : null;
                services.add(item);
            } while (cursor.moveToNext());

            // Sort services
            sortServices(services);

            // Display sorted services
            for (ServiceItem item : services) {
                View view = LayoutInflater.from(this).inflate(R.layout.item_jasa, containerJasa, false);

                TextView textNama = view.findViewById(R.id.textNamaJasa);
                TextView textHarga = view.findViewById(R.id.textHargaJasa);
                TextView textKategori = view.findViewById(R.id.textKategoriJasa);
                ImageView btnEdit = view.findViewById(R.id.btnEditJasa);
                ImageView btnDelete = view.findViewById(R.id.btnDeleteJasa);
                ImageView imgJasa = view.findViewById(R.id.imgJasaInfo);
                ImageView btnFavorite = view.findViewById(R.id.btnFavorite);

                if (item.imagePath != null && !item.imagePath.isEmpty()) {
                    java.io.File imageFile = new java.io.File(item.imagePath);
                    if (imageFile.exists()) {
                        imgJasa.setImageURI(android.net.Uri.fromFile(imageFile));
                        imgJasa.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    } else {
                        imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
                    }
                } else {
                    imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
                }

                textNama.setText(item.nama);
                textHarga.setText(ValidationUtils.formatCurrency(item.harga));
                textKategori.setText(item.kategori + " • by " + item.freelancer);

                // View count
                int viewCount = db.getServiceViewCount(item.id);
                if (viewCount > 0) {
                    textKategori.setText(textKategori.getText() + " • " + viewCount + " views");
                }

                btnEdit.setImageResource(R.drawable.ic_add_circle);
                btnEdit.setVisibility(View.VISIBLE);
                btnEdit.setOnClickListener(v -> openServiceDetail(item.id));

                // Favorite button
                if (btnFavorite != null && clientUsername != null) {
                    btnFavorite.setVisibility(View.VISIBLE);
                    boolean isFav = db.isFavorite(clientUsername, item.id);
                    btnFavorite.setImageResource(isFav ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);

                    final int serviceId = item.id;
                    btnFavorite.setOnClickListener(v -> {
                        if (db.isFavorite(clientUsername, serviceId)) {
                            db.removeFromFavorites(clientUsername, serviceId);
                            btnFavorite.setImageResource(R.drawable.ic_favorite_border);
                            Toast.makeText(this, "Dihapus dari favorit", Toast.LENGTH_SHORT).show();
                        } else {
                            db.addToFavorites(clientUsername, serviceId);
                            btnFavorite.setImageResource(R.drawable.ic_favorite);
                            Toast.makeText(this, "Ditambahkan ke favorit", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                // Make whole card clickable
                view.setOnClickListener(v -> openServiceDetail(item.id));

                btnDelete.setVisibility(View.GONE);

                containerJasa.addView(view);
            }
        } else {
            textNoResults.setVisibility(View.VISIBLE);
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    private void sortServices(java.util.List<ServiceItem> services) {
        switch (sortBy) {
            case "price_low":
                services.sort((a, b) -> {
                    try {
                        double priceA = Double.parseDouble(a.harga);
                        double priceB = Double.parseDouble(b.harga);
                        return Double.compare(priceA, priceB);
                    } catch (NumberFormatException e) {
                        return 0;
                    }
                });
                break;
            case "price_high":
                services.sort((a, b) -> {
                    try {
                        double priceA = Double.parseDouble(a.harga);
                        double priceB = Double.parseDouble(b.harga);
                        return Double.compare(priceB, priceA);
                    } catch (NumberFormatException e) {
                        return 0;
                    }
                });
                break;
            case "rating":
                services.sort((a, b) -> {
                    double ratingA = db.getServiceAverageRating(a.id);
                    double ratingB = db.getServiceAverageRating(b.id);
                    return Double.compare(ratingB, ratingA);
                });
                break;
            case "newest":
            default:
                // Already in newest order from database
                break;
        }
    }

    private void openServiceDetail(int serviceId) {
        // Track view
        if (clientUsername != null) {
            db.incrementServiceViews(serviceId, clientUsername);
        }

        Intent intent = new Intent(CariJasaActivity.this, DetailJasaActivity.class);
        intent.putExtra("username", clientUsername);
        intent.putExtra("service_id", serviceId);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh list when returning from detail
        performSearch();
    }

    private void updateClearButton(boolean visible) {
        if (searchBar == null)
            return;
        if (visible) {
            searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, R.drawable.ic_close, 0);
        } else {
            searchBar.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0);
        }
    }

    // Helper class for service items
    private static class ServiceItem {
        int id;
        String freelancer;
        String nama;
        String deskripsi;
        String harga;
        String kategori;
        String imagePath;
    }
}
