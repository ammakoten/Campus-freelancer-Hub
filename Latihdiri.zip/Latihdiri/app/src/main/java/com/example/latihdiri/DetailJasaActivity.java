package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class DetailJasaActivity extends AppCompatActivity {

    private ImageView imgJasaDetail, imgFreelancerAvatar;
    private TextView textFreelancerName, textNamaJasa, textHarga, textKategori, textDeskripsi;
    private Button btnPesan;
    private Toolbar toolbar;

    private DatabaseHelper db;
    private int serviceId;
    private String clientUsername;
    // Data to pass to order screen
    private String freelancerUsername;
    private String serviceName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_jasa);

        db = new DatabaseHelper(this);

        serviceId = getIntent().getIntExtra("service_id", -1);
        clientUsername = getIntent().getStringExtra("username");

        initializeViews();
        setupToolbar();
        loadServiceDetails();

        btnPesan.setOnClickListener(v -> {
            if (freelancerUsername != null && serviceId != -1) {
                Intent intent = new Intent(DetailJasaActivity.this, PesanJasaActivity.class);
                intent.putExtra("username", clientUsername);
                intent.putExtra("service_id", serviceId);
                intent.putExtra("freelancer_username", freelancerUsername);
                intent.putExtra("service_name", serviceName);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Data jasa tidak valid", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initializeViews() {
        imgJasaDetail = findViewById(R.id.imgJasaDetail);
        imgFreelancerAvatar = findViewById(R.id.imgFreelancerAvatar);
        textFreelancerName = findViewById(R.id.textFreelancerName);
        textNamaJasa = findViewById(R.id.textNamaJasa);
        textHarga = findViewById(R.id.textHarga);
        textKategori = findViewById(R.id.textKategori);
        textDeskripsi = findViewById(R.id.textDeskripsi);
        btnPesan = findViewById(R.id.btnPesan);
        toolbar = findViewById(R.id.toolbar);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void loadServiceDetails() {
        Cursor cursor = db.getJasaById(serviceId);
        if (cursor != null && cursor.moveToFirst()) {
            /*
             * Schema Jasa (from DisplayJasa):
             * 0: id
             * 1: username (freelancer)
             * 2: nama_jasa
             * 3: deskripsi
             * 4: harga
             * 5: kategori
             * 6: image_path
             */
            freelancerUsername = cursor.getString(1);
            serviceName = cursor.getString(2);
            String desc = cursor.getString(3);
            String price = cursor.getString(4);
            String cat = cursor.getString(5);
            String imgPath = cursor.getColumnCount() > 6 ? cursor.getString(6) : null;

            textFreelancerName.setText(freelancerUsername);
            textNamaJasa.setText(serviceName);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                textDeskripsi.setText(android.text.Html.fromHtml(desc, android.text.Html.FROM_HTML_MODE_COMPACT));
            } else {
                textDeskripsi.setText(android.text.Html.fromHtml(desc));
            }
            textHarga.setText(price);
            textKategori.setText(cat);

            if (imgPath != null && !imgPath.isEmpty()) {
                File imageFile = new File(imgPath);
                if (imageFile.exists()) {
                    imgJasaDetail.setImageURI(Uri.fromFile(imageFile));
                } else {
                    imgJasaDetail.setImageResource(R.drawable.ic_insert_drive_file);
                }
            }

            // Load Freelancer Avatar
            String avatarPath = db.getUserProfileImage(freelancerUsername);
            if (avatarPath != null) {
                File f = new File(avatarPath);
                if (f.exists()) {
                    imgFreelancerAvatar.setImageURI(Uri.fromFile(f));
                }
            }
        } else {
            Toast.makeText(this, "Jasa tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
        }
        if (cursor != null)
            cursor.close();
    }
}
