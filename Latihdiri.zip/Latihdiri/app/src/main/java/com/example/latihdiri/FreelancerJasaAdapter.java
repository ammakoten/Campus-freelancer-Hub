package com.example.latihdiri;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FreelancerJasaAdapter extends RecyclerView.Adapter<FreelancerJasaAdapter.ViewHolder> {

    private List<Jasa> jasaList;
    private OnJasaActionListener listener;

    public interface OnJasaActionListener {
        void onEdit(Jasa jasa);

        void onDelete(Jasa jasa);
    }

    public FreelancerJasaAdapter(List<Jasa> jasaList, OnJasaActionListener listener) {
        this.jasaList = jasaList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_jasa_freelancer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Jasa jasa = jasaList.get(position);
        holder.textNama.setText(jasa.getNamaJasa());
        holder.textKategori.setText(jasa.getKategori());
        holder.textHarga.setText("Rp " + jasa.getHarga());
        holder.textDeskripsi.setText(jasa.getDeskripsi());

        holder.btnEdit.setOnClickListener(v -> listener.onEdit(jasa));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(jasa));
    }

    @Override
    public int getItemCount() {
        return jasaList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textNama, textKategori, textHarga, textDeskripsi;
        Button btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textNama = itemView.findViewById(R.id.textNamaJasa);
            textKategori = itemView.findViewById(R.id.textKategori);
            textHarga = itemView.findViewById(R.id.textHarga);
            textDeskripsi = itemView.findViewById(R.id.textDeskripsi);
            btnEdit = itemView.findViewById(R.id.buttonEdit);
            btnDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
