package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

// Updated: 2025-12-15 - Menu cepat dengan animasi modern

public class HomeFreelancerActivity extends AppCompatActivity {

    TextView textWelcome, textTotalJasa, textTotalPesanan, textRating;
    View navKelolaJasaShortcut, navPesananMasukShortcut, btnSupportChatFreelancer;
    View tipFreelancerCard1, tipFreelancerCard2;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_freelancer);

        // Ambil username dari intent
        username = getIntent().getStringExtra("username");

        // Ambil komponen dari XML
        textWelcome = findViewById(R.id.textWelcome);
        textTotalJasa = findViewById(R.id.textTotalJasa);
        textTotalPesanan = findViewById(R.id.textTotalPesanan);
        textWelcome = findViewById(R.id.textWelcome);
        textTotalJasa = findViewById(R.id.textTotalJasa);
        textTotalPesanan = findViewById(R.id.textTotalPesanan);
        textRating = findViewById(R.id.textRating);

        // Parent Layouts for Stats
        View layoutTotalJasa = (View) textTotalJasa.getParent();
        View layoutTotalPesanan = (View) textTotalPesanan.getParent();
        View layoutRating = (View) textRating.getParent();

        // Ambil menu cepat shortcuts
        navKelolaJasaShortcut = findViewById(R.id.navKelolaJasaShortcut);
        navPesananMasukShortcut = findViewById(R.id.navPesananMasukShortcut);
        btnSupportChatFreelancer = findViewById(R.id.btnSupportChatFreelancer);
        tipFreelancerCard1 = findViewById(R.id.tipFreelancerCard1);
        tipFreelancerCard2 = findViewById(R.id.tipFreelancerCard2);

        // Set welcome text
        textWelcome.setText("Selamat datang, " + username);

        // Setup click listeners untuk menu cepat
        // Setup click listeners untuk menu cepat dan stats
        setupQuickMenuListeners();
        setupStatListeners(layoutTotalJasa, layoutTotalPesanan, layoutRating);
    }

    private void setupQuickMenuListeners() {
        // Click listener untuk Tambah Jasa (navigasi ke Kelola Jasa)
        navKelolaJasaShortcut.setOnClickListener(v -> {
            try {
                // Animasi scale untuk feedback visual
                v.animate()
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .setDuration(100)
                        .withEndAction(() -> {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                        })
                        .start();

                Intent intent = new Intent(HomeFreelancerActivity.this, KelolaJasaActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                // Animasi transisi modern - slide dari kanan
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "Gagal membuka Kelola Jasa", android.widget.Toast.LENGTH_SHORT)
                        .show();
                e.printStackTrace();
            }
        });

        // Click listener untuk Pesanan Masuk
        navPesananMasukShortcut.setOnClickListener(v -> {
            try {
                // Animasi scale untuk feedback visual
                v.animate()
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .setDuration(100)
                        .withEndAction(() -> {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                        })
                        .start();

                Intent intent = new Intent(HomeFreelancerActivity.this, PesananMasukActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                // Animasi transisi modern - slide dari kanan
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "Gagal membuka Pesanan Masuk", android.widget.Toast.LENGTH_SHORT)
                        .show();
                e.printStackTrace();
            }
        });

        // Click listener untuk Support Chat (Chat dengan Admin)
        btnSupportChatFreelancer.setOnClickListener(v -> {
            try {
                // Animasi scale untuk feedback visual
                v.animate()
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .setDuration(100)
                        .withEndAction(() -> {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                        })
                        .start();

                Intent intent = new Intent(HomeFreelancerActivity.this, ChatActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("otherUser", "Admin");
                startActivity(intent);
                // Animasi transisi modern - slide dari kanan
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "Gagal membuka Chat", android.widget.Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        });

        // Click listener for Tip 1: Optimalkan Portofoliomu
        tipFreelancerCard1.setOnClickListener(v -> {
            try {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100).start())
                        .start();

                Intent intent = new Intent(HomeFreelancerActivity.this, DetailTipsActivity.class);
                intent.putExtra("tip_title", "Optimalkan Portofoliomu");
                intent.putExtra("tip_content", "Cara mengoptimalkan portofolio Anda:\n\n" +
                        "1. Pilih Hasil Terbaik: Hanya tampilkan karya terbaik Anda yang relevan dengan jasa yang ditawarkan.\n\n"
                        +
                        "2. Gambar Berkualitas Tinggi: Gunakan gambar yang jernih dan profesional sebagai thumbnail.\n\n"
                        +
                        "3. Deskripsi Singkat: Berikan penjelasan singkat tentang proyek tersebut dan peran Anda di dalamnya.\n\n"
                        +
                        "4. Rutin Update: Tambahkan karya terbaru Anda secara berkala untuk menunjukkan Anda aktif.");
                startActivity(intent);
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "Gagal membuka Tips", android.widget.Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        });

        // Click listener for Tip 2: Respon Cepat = Rating Bagus
        tipFreelancerCard2.setOnClickListener(v -> {
            try {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100).start())
                        .start();

                Intent intent = new Intent(HomeFreelancerActivity.this, DetailTipsActivity.class);
                intent.putExtra("tip_title", "Respon Cepat = Rating Bagus");
                intent.putExtra("tip_content", "Mengapa respon cepat itu penting:\n\n" +
                        "1. Kepercayaan Klien: Klien lebih cenderung memesan dari freelancer yang membalas pesan dalam hitungan menit.\n\n"
                        +
                        "2. Keunggulan Kompetitif: Menjadi yang pertama merespon memberi Anda peluang lebih besar dibanding freelancer lain.\n\n"
                        +
                        "3. Rating Respon: Sistem kami memantau waktu respon Anda. Respon cepat meningkatkan visibilitas profil Anda.\n\n"
                        +
                        "4. Profesionalisme: Menunjukkan bahwa Anda serius dan menghargai waktu klien.");
                startActivity(intent);
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "Gagal membuka Tips", android.widget.Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        });
    }

    private void setupStatListeners(View layoutJasa, View layoutPesanan, View layoutRating) {
        // Klik Total Jasa -> Kelola Jasa
        layoutJasa.setOnClickListener(v -> {
            Intent intent = new Intent(HomeFreelancerActivity.this, KelolaJasaActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // Klik Total Pesanan -> Pesanan Masuk (atau PesananSaya jika ingin list semua)
        // Disini arahkan ke PesananMasukActivity sesuai konteks freelancer
        layoutPesanan.setOnClickListener(v -> {
            Intent intent = new Intent(HomeFreelancerActivity.this, PesananMasukActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // Klik Rating -> Profil Freelancer (untuk lihat review)
        layoutRating.setOnClickListener(v -> {
            Intent intent = new Intent(HomeFreelancerActivity.this, ProfilFreelancerActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (username != null) {
            loadDashboardStats(username);
        }
    }

    private void loadDashboardStats(String username) {
        DatabaseHelper db = new DatabaseHelper(this);
        textTotalJasa.setText(String.valueOf(db.getFreelancerServiceCount(username)));
        textTotalPesanan.setText(String.valueOf(db.getFreelancerOrderCount(username)));
        textRating.setText(String.format("%.1f", db.getFreelancerAverageRating(username)));
    }
}
