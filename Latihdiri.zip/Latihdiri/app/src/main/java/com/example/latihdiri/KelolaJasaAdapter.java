package com.example.latihdiri;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class KelolaJasaAdapter extends RecyclerView.Adapter<KelolaJasaAdapter.ViewHolder> {

    private Context context;
    private List<Jasa> jasaList;
    private DatabaseHelper db;
    private Runnable onDataChangedListener;

    public KelolaJasaAdapter(Context context, List<Jasa> jasaList, Runnable onDataChangedListener) {
        this.context = context;
        this.jasaList = jasaList;
        this.onDataChangedListener = onDataChangedListener;
        this.db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_jasa, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Jasa jasa = jasaList.get(position);

        // Show Edit/Delete buttons
        holder.btnEdit.setVisibility(View.VISIBLE);
        holder.btnDelete.setVisibility(View.VISIBLE);

        holder.textNama.setText(jasa.getNamaJasa());
        holder.textKategori.setText(jasa.getKategori());
        holder.textHarga.setText("Rp " + jasa.getHarga());
        if (jasa.getDeskripsi() != null) {
            holder.textDeskripsi
                    .setText(android.text.Html.fromHtml(jasa.getDeskripsi(), android.text.Html.FROM_HTML_MODE_COMPACT));
        }
        holder.textFreelancer.setText("Oleh: " + jasa.getUsername());

        if (jasa.getImagePath() != null && !jasa.getImagePath().isEmpty()) {
            java.io.File imageFile = new java.io.File(jasa.getImagePath());
            if (imageFile.exists()) {
                holder.imgJasa.setImageURI(android.net.Uri.fromFile(imageFile));
                holder.imgJasa.setScaleType(ImageView.ScaleType.CENTER_CROP);
            } else {
                holder.imgJasa.setImageResource(R.drawable.ic_insert_drive_file);
            }
        } else {
            holder.imgJasa.setImageResource(R.drawable.ic_insert_drive_file); // Placeholder
        }

        // Edit Button
        holder.btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditJasaActivity.class);
            intent.putExtra("jasa_id", jasa.getId());
            context.startActivity(intent);
        });

        // Delete Button
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Hapus Jasa")
                    .setMessage("Apakah Anda yakin ingin menghapus jasa ini?")
                    .setPositiveButton("Ya", (dialog, which) -> {
                        if (db.deleteJasa(jasa.getId())) {
                            Toast.makeText(context, "Jasa berhasil dihapus", Toast.LENGTH_SHORT).show();
                            if (onDataChangedListener != null) {
                                onDataChangedListener.run();
                            }
                        } else {
                            Toast.makeText(context, "Gagal menghapus jasa", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Tidak", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return jasaList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textNama, textKategori, textHarga, textDeskripsi, textFreelancer;
        ImageView btnEdit, btnDelete, imgJasa;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgJasa = itemView.findViewById(R.id.imgJasaInfo);
            textNama = itemView.findViewById(R.id.textNamaJasa);
            textKategori = itemView.findViewById(R.id.textKategoriJasa);
            textHarga = itemView.findViewById(R.id.textHargaJasa);
            textDeskripsi = itemView.findViewById(R.id.textDeskripsi);
            textFreelancer = itemView.findViewById(R.id.textFreelancerName);
            btnEdit = itemView.findViewById(R.id.btnEditJasa);
            btnDelete = itemView.findViewById(R.id.btnDeleteJasa);
        }
    }
}
