package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PesananMasukActivity extends AppCompatActivity {

    LinearLayout containerPesanan;
    ImageView btnBack;
    DatabaseHelper db;
    String username;

    private static final int PICK_FILE_REQUEST = 1;
    private int selectedOrderId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesanan_masuk);

        db = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        containerPesanan = findViewById(R.id.containerPesanan);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        loadPesanan();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPesanan();
    }

    private void loadPesanan() {
        try {
            containerPesanan.removeAllViews();
            Cursor cursor = db.getOrdersByFreelancer(username);

            if (cursor == null) {
                Toast.makeText(this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
                return;
            }

            if (cursor.moveToFirst()) {
                do {
                    try {
                        int id = cursor.getInt(0);
                        String client = cursor.getString(1);
                        // String freelancer = cursor.getString(2);
                        // int serviceId = cursor.getInt(3);
                        String serviceName = cursor.getString(4);
                        String status = cursor.getString(5);
                        String notes = cursor.getString(6);
                        String date = cursor.getString(7);

                        // Safe date parsing
                        String dateString = date;
                        try {
                            if (date != null && !date.isEmpty()) {
                                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
                                dateString = sdf.format(new java.util.Date(Long.parseLong(date)));
                            }
                        } catch (Exception e) {
                            dateString = date;
                        }

                        View view = LayoutInflater.from(this).inflate(R.layout.item_order, containerPesanan, false);

                        TextView textClient = view.findViewById(R.id.textClientName);
                        TextView textService = view.findViewById(R.id.textServiceName);
                        TextView textStatus = view.findViewById(R.id.textStatus);
                        TextView textNotes = view.findViewById(R.id.textNotes);
                        TextView textDate = view.findViewById(R.id.textDate);
                        android.widget.Button btnUpdate = view.findViewById(R.id.btnUpdateStatus);
                        android.widget.Button btnUpload = view.findViewById(R.id.btnUploadResult);

                        if (textClient != null)
                            textClient.setText("Client: " + (client != null ? client : "-"));
                        if (textService != null)
                            textService.setText("Jasa: " + (serviceName != null ? serviceName : "-"));
                        if (textStatus != null)
                            textStatus.setText("Status: " + (status != null ? status : "-"));
                        if (textNotes != null)
                            textNotes.setText("Catatan: " + (notes != null ? notes : "-"));
                        if (textDate != null)
                            textDate.setText(dateString);

                        if (btnUpdate != null) {
                            String finalStatus = status;
                            btnUpdate.setOnClickListener(v -> showStatusDialog(id, finalStatus));
                        }

                        if (btnUpload != null) {
                            // Show upload button if status is "Diproses" or "Selesai"
                            if (status != null && (status.equals("Diproses") || status.equals("Selesai"))) {
                                btnUpload.setVisibility(View.VISIBLE);
                                btnUpload.setOnClickListener(v -> {
                                    selectedOrderId = id;
                                    openFilePicker();
                                });
                            } else {
                                btnUpload.setVisibility(View.GONE);
                            }
                        }

                        containerPesanan.addView(view);

                    } catch (Exception e) {
                        e.printStackTrace();
                        // Continue to next item even if one fails
                    }

                } while (cursor.moveToNext());
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showStatusDialog(int id, String currentStatus) {
        String[] statuses = { "Pending", "Diproses", "Selesai" };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Status Pesanan");
        builder.setSingleChoiceItems(statuses, -1, (dialog, which) -> {
            String newStatus = statuses[which];
            db.updateOrderStatus(id, newStatus);
            loadPesanan();
            dialog.dismiss();
            Toast.makeText(this, "Status diperbarui", Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }

    private void openFilePicker() {
        android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            android.net.Uri fileUri = data.getData();
            saveFileToInternalStorage(fileUri);
        }
    }

    private void saveFileToInternalStorage(android.net.Uri fileUri) {
        try {
            java.io.InputStream inputStream = getContentResolver().openInputStream(fileUri);
            String fileName = "order_" + selectedOrderId + "_" + System.currentTimeMillis() + ".pdf"; // Defaulting
                                                                                                      // extension for
                                                                                                      // simplicity, or
                                                                                                      // could extract
            // Try to get actual file name
            android.database.Cursor returnCursor = getContentResolver().query(fileUri, null, null, null, null);
            if (returnCursor != null) {
                int nameIndex = returnCursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                returnCursor.moveToFirst();
                String originalName = returnCursor.getString(nameIndex);
                if (originalName != null)
                    fileName = "order_" + selectedOrderId + "_" + originalName;
                returnCursor.close();
            }

            java.io.File file = new java.io.File(getFilesDir(), "order_results");
            if (!file.exists()) {
                file.mkdirs();
            }
            java.io.File destFile = new java.io.File(file, fileName);

            java.io.OutputStream outputStream = new java.io.FileOutputStream(destFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();

            // Update database
            db.updateOrderResult(selectedOrderId, destFile.getAbsolutePath());
            Toast.makeText(this, "File berhasil dikirim!", Toast.LENGTH_SHORT).show();

            // Auto update status to Selesai if not already
            db.updateOrderStatus(selectedOrderId, "Selesai");
            loadPesanan();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Gagal mengirim file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
