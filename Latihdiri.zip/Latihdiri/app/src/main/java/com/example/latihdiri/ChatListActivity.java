package com.example.latihdiri;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ChatListActivity extends AppCompatActivity {

    private RecyclerView recyclerChatList;
    private ImageView btnBack;
    private DatabaseHelper db;
    private ChatUserAdapter adapter;
    private List<String> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        db = new DatabaseHelper(this);
        recyclerChatList = findViewById(R.id.recyclerChatList);
        btnBack = findViewById(R.id.btnBack);

        userList = new ArrayList<>();
        adapter = new ChatUserAdapter(this, userList);
        recyclerChatList.setLayoutManager(new LinearLayoutManager(this));
        recyclerChatList.setAdapter(adapter);

        loadChatUsers();

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadChatUsers() {
        userList.clear();
        Cursor cursor = db.getChatUsers();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String sender = cursor.getString(cursor.getColumnIndexOrThrow("sender"));
                userList.add(sender);
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    // Inner Adapter Class
    public class ChatUserAdapter extends RecyclerView.Adapter<ChatUserAdapter.ViewHolder> {

        private Context context;
        private List<String> users;

        public ChatUserAdapter(Context context, List<String> users) {
            this.context = context;
            this.users = users;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_user_chat, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String username = users.get(position);
            holder.textUsername.setText(username);

            // Fetch last message
            Cursor cursor = db.getLastMessage("admin", username);
            if (cursor != null && cursor.moveToFirst()) {
                String message = cursor.getString(cursor.getColumnIndexOrThrow("message"));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));

                holder.textLastMessage.setText(message);

                // Format time
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
                String time = sdf.format(new java.util.Date(Long.parseLong(timestamp)));
                holder.textTime.setText(time);

                cursor.close();
            } else {
                holder.textLastMessage.setText("No messages yet");
                holder.textTime.setText("");
            }

            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra("target_user", username);
                context.startActivity(intent);
            });

            holder.itemView.setOnLongClickListener(v -> {
                new android.app.AlertDialog.Builder(context)
                        .setTitle("Hapus Chat")
                        .setMessage("Apakah anda yakin ingin menghapus chat dari " + username + "?")
                        .setPositiveButton("Hapus", (dialog, which) -> {
                            if (db.deleteChat("admin", username)) {
                                android.widget.Toast
                                        .makeText(context, "Chat berhasil dihapus", android.widget.Toast.LENGTH_SHORT)
                                        .show();
                                loadChatUsers(); // Refresh list
                            } else {
                                android.widget.Toast
                                        .makeText(context, "Gagal menghapus chat", android.widget.Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return users.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView textUsername, textLastMessage, textTime;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                textUsername = itemView.findViewById(R.id.textUsername);
                textLastMessage = itemView.findViewById(R.id.textLastMessage);
                textTime = itemView.findViewById(R.id.textTime);
            }
        }
    }
}
