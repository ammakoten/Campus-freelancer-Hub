package com.example.latihdiri;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    com.google.android.material.textfield.TextInputLayout inputLayoutUsername, inputLayoutPassword;
    Button buttonLogin;
    TextView textForgotPassword, buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        setContentView(R.layout.activity_main);

        inputLayoutUsername = findViewById(R.id.inputLayoutUsername);
        inputLayoutPassword = findViewById(R.id.inputLayoutPassword);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        textForgotPassword = findViewById(R.id.textForgotPassword);

        // 🔥 LOGIN MENGGUNAKAN SQLITE
        buttonLogin.setOnClickListener(v -> {

            // Reset Error
            inputLayoutUsername.setError(null);
            inputLayoutPassword.setError(null);

            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            boolean isValid = true;
            if (username.isEmpty()) {
                inputLayoutUsername.setError("Username tidak boleh kosong!");
                isValid = false;
            }
            if (password.isEmpty()) {
                inputLayoutPassword.setError("Password tidak boleh kosong!");
                isValid = false;
            }

            if (!isValid)
                return;

            // 🔥 HARD-CODED ADMIN LOGIN (SIMPLEST WAY)
            if (username.equals("admin") && password.equals("admin123")) {
                // Simpan Session
                android.content.SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
                android.content.SharedPreferences.Editor editor = prefs.edit();
                editor.putString("username", username);
                editor.putString("role", "Admin");
                editor.apply();

                // Redirect ke AdminActivity
                Intent intent = new Intent(MainActivity.this, AdminActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("role", "Admin");
                startActivity(intent);
                finish();
                return;
            }

            DatabaseHelper db = new DatabaseHelper(MainActivity.this);

            // CEK LOGIN DI DATABASE
            if (db.checkUser(username, password)) {

                // Ambil role berdasarkan username
                String role = db.getUserRole(username);

                // SIMPAN SESSION
                android.content.SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
                android.content.SharedPreferences.Editor editor = prefs.edit();
                editor.putString("username", username);
                editor.putString("role", role);
                editor.apply();

                // ➤ MASUK OTOMATIS SESUAI ROLE
                Intent intent;

                switch (role) {
                    case "Freelancers":
                        intent = new Intent(MainActivity.this, FreelancerActivity.class);
                        break;

                    case "Klien":
                        intent = new Intent(MainActivity.this, ClientActivity.class);
                        break;

                    case "Admin":
                        intent = new Intent(MainActivity.this, AdminActivity.class);
                        break;

                    default:
                        intent = new Intent(MainActivity.this, HomeActivity.class);
                        break;
                }

                intent.putExtra("username", username);
                intent.putExtra("role", role);
                startActivity(intent);
                finish();

            } else {
                // TAMPILKAN PESAN ERROR MERAH MODERN
                inputLayoutPassword.setError("Username atau Password salah!");
                // Toast.makeText(MainActivity.this, "Username atau password salah!",
                // Toast.LENGTH_SHORT).show();
            }
        });

        // Tombol Daftar
        buttonRegister.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Link Lupa Password
        textForgotPassword.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ForgotPasswordActivity.class);
            startActivity(intent);
        });
    }
}
