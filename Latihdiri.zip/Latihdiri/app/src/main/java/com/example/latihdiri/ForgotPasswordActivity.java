package com.example.latihdiri;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordActivity extends AppCompatActivity {

    EditText editTextEmail;
    Button buttonResetPassword;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        db = new DatabaseHelper(this);
        editTextEmail = findViewById(R.id.editTextEmail);
        buttonResetPassword = findViewById(R.id.buttonResetPassword);

        // Buat Notification Channel (Wajib untuk Android 8.0+)
        createNotificationChannel();

        buttonResetPassword.setOnClickListener(v -> {
            String email = editTextEmail.getText().toString().trim();

            if (email.isEmpty()) {
                Toast.makeText(ForgotPasswordActivity.this, "Masukkan email Anda!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Cek apakah email terdaftar
            if (db.checkEmail(email)) {
                // KIRIM EMAIL ASLI VIA JAVAMAIL
                sendResetNotification(email);
            } else {
                Toast.makeText(ForgotPasswordActivity.this, "Email tidak terdaftar!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendResetNotification(String email) {
        String resetLink = "latihdiri://reset?email=" + email;

        Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(resetLink));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(this, 0, intent,
                android.app.PendingIntent.FLAG_IMMUTABLE);

        androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(this,
                "reset_password_channel")
                .setSmallIcon(R.drawable.ic_launcher_foreground) // Pastikan icon ini ada, atau ganti dengan icon yang
                                                                 // valid
                .setContentTitle("Reset Password")
                .setContentText("Klik notifikasi ini untuk mereset password Anda.")
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        androidx.core.app.NotificationManagerCompat notificationManager = androidx.core.app.NotificationManagerCompat
                .from(this);
        if (androidx.core.app.ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            // Permission check for Android 13+
            // Di sini kita hanya menampilkan Toast simulasi jika permission belum
            // diberikan, atau abaikan untuk demo
            Toast.makeText(this, "Simulasi: Cek notifikasi Anda", Toast.LENGTH_SHORT).show();
            // Tetap kirim notifikasi jika possible atau lanjutkan
        }
        try {
            notificationManager.notify(1, builder.build());
            Toast.makeText(this, "Link reset telah dikirim ke notifikasi (Simulasi Email)", Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "Gagal mengirim notifikasi: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Notification logic dihilangkan karena diganti email asli
    /*
     * private void sendResetNotification(String email) { ... }
     */

    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            CharSequence name = "Reset Password";
            String description = "Channel untuk reset password";
            int importance = android.app.NotificationManager.IMPORTANCE_HIGH;
            android.app.NotificationChannel channel = new android.app.NotificationChannel("reset_password_channel",
                    name, importance);
            channel.setDescription(description);

            android.app.NotificationManager notificationManager = getSystemService(
                    android.app.NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
