package com.example.latihdiri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class KelolaPesananActivity extends AppCompatActivity {

    LinearLayout containerPesanan;
    ImageView btnBack;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kelola_pesanan);

        db = new DatabaseHelper(this);

        containerPesanan = findViewById(R.id.containerPesanan);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        loadOrders();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadOrders(); // Refresh orders when activity becomes visible
    }

    private void loadOrders() {
        containerPesanan.removeAllViews();
        Cursor cursor;

        int specificOrderId = getIntent().getIntExtra("order_id", -1);
        if (specificOrderId != -1) {
            cursor = db.getOrderById(specificOrderId);
        } else {
            // Check Role logic
            android.content.SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            String role = prefs.getString("role", "");
            String username = prefs.getString("username", "");

            if ("Admin".equalsIgnoreCase(role)) {
                cursor = db.getAllOrders();
            } else {
                cursor = db.getOrdersByFreelancer(username);
            }
        }

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String client = cursor.getString(1);
                String freelancer = cursor.getString(2);
                // int serviceId = cursor.getInt(3);
                String serviceName = cursor.getString(4);
                String status = cursor.getString(5);
                String notes = cursor.getString(6);
                String date = cursor.getString(7);

                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
                String dateString = "";
                try {
                    dateString = sdf.format(new java.util.Date(Long.parseLong(date)));
                } catch (Exception e) {
                    dateString = date;
                }

                View view = LayoutInflater.from(this).inflate(R.layout.item_order_admin, containerPesanan, false);

                TextView textClient = view.findViewById(R.id.textClientName);
                TextView textFreelancer = view.findViewById(R.id.textFreelancerName);
                TextView textService = view.findViewById(R.id.textServiceName);
                TextView textStatus = view.findViewById(R.id.textStatus);
                TextView textNotes = view.findViewById(R.id.textNotes);
                TextView textDate = view.findViewById(R.id.textDate);
                android.widget.Button btnUpdate = view.findViewById(R.id.btnUpdateStatus);

                textClient.setText("Client: " + client);
                textFreelancer.setText("Freelancer: " + freelancer);
                textService.setText("Jasa: " + serviceName);
                textStatus.setText("Status: " + status);
                textNotes.setText("Catatan: " + notes);
                textDate.setText(dateString);

                btnUpdate.setOnClickListener(v -> showStatusDialog(id, status));

                containerPesanan.addView(view);

            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Toast.makeText(this, "Tidak ada pesanan.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showStatusDialog(int id, String currentStatus) {
        String[] statuses = { "Pending", "Diproses", "Selesai", "Dibatalkan" };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Status Pesanan");

        final android.widget.EditText inputResult = new android.widget.EditText(this);
        inputResult.setHint("Masukkan Link/Path Hasil Kerja (Jika Selesai)");
        builder.setView(inputResult);

        builder.setSingleChoiceItems(statuses, -1, (dialog, which) -> {
            String newStatus = statuses[which];
            String resultPath = inputResult.getText().toString();

            if (newStatus.equals("Selesai")) {
                if (resultPath.isEmpty()) {
                    Toast.makeText(this, "Harap masukkan link/path hasil kerja!", Toast.LENGTH_SHORT).show();
                    return; // Don't dismiss if empty
                }
                db.updateOrderResult(id, resultPath);
            }

            db.updateOrderStatus(id, newStatus);
            loadOrders();
            dialog.dismiss();
            Toast.makeText(this, "Status & Hasil diperbarui", Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }
}
