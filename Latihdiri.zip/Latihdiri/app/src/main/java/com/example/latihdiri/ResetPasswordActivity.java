package com.example.latihdiri;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

public class ResetPasswordActivity extends AppCompatActivity {

    TextInputLayout inputLayoutNewPassword, inputLayoutConfirmPassword;
    EditText editTextNewPassword, editTextConfirmPassword;
    Button buttonSavePassword;
    DatabaseHelper db;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        db = new DatabaseHelper(this);

        // Cek apakah dibuka dari Deep Link (Email) atau Intent biasa
        android.net.Uri data = getIntent().getData();
        if (data != null && data.getQueryParameter("email") != null) {
            // Dari Link Email: latihdiri://reset?email=...
            email = data.getQueryParameter("email");
        } else {
            // Dari Intent biasa (jika ada)
            email = getIntent().getStringExtra("email");
        }

        inputLayoutNewPassword = findViewById(R.id.inputLayoutNewPassword);
        inputLayoutConfirmPassword = findViewById(R.id.inputLayoutConfirmPassword);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonSavePassword = findViewById(R.id.buttonSavePassword);

        buttonSavePassword.setOnClickListener(v -> {
            String newPassword = editTextNewPassword.getText().toString().trim();
            String confirmPassword = editTextConfirmPassword.getText().toString().trim();

            inputLayoutNewPassword.setError(null);
            inputLayoutConfirmPassword.setError(null);

            // Validasi Kosong
            boolean isValid = true;
            if (newPassword.isEmpty()) {
                inputLayoutNewPassword.setError("Password tidak boleh kosong!");
                isValid = false;
            }
            if (confirmPassword.isEmpty()) {
                inputLayoutConfirmPassword.setError("Konfirmasi password tidak boleh kosong!");
                isValid = false;
            }
            if (!isValid)
                return;

            // Validasi Match
            if (!newPassword.equals(confirmPassword)) {
                inputLayoutConfirmPassword.setError("Password tidak sama!");
                return;
            }

            // Validasi Strength (Standard)
            if (newPassword.length() < 8) {
                inputLayoutNewPassword.setError("Password minimal 8 karakter!");
                return;
            }
            if (!newPassword.matches(".*[A-Z].*")) {
                inputLayoutNewPassword.setError("Harus ada huruf besar (A-Z)!");
                return;
            }
            if (!newPassword.matches(".*[a-z].*")) {
                inputLayoutNewPassword.setError("Harus ada huruf kecil (a-z)!");
                return;
            }
            if (!newPassword.matches(".*[0-9].*")) {
                inputLayoutNewPassword.setError("Harus ada angka (0-9)!");
                return;
            }
            if (!newPassword.matches(".*[!@#$%^&*].*")) {
                inputLayoutNewPassword.setError("Harus ada simbol (!@#$%^&*)!");
                return;
            }

            // Update Database
            if (email != null && !email.isEmpty()) {
                if (db.updatePassword(email, newPassword)) {
                    Toast.makeText(ResetPasswordActivity.this, "Password berhasil diubah! Silakan login.",
                            Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ResetPasswordActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(ResetPasswordActivity.this, "Gagal mengubah password!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(ResetPasswordActivity.this, "Terjadi kesalahan (Email tidak ditemukan)",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
