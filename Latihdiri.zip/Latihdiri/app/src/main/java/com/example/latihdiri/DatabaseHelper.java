package com.example.latihdiri;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 18;

    // ... (constructor) ...

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // === TABLE USERS ===
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE, " +
                        "email TEXT, " +
                        "password TEXT, " +
                        "role TEXT, " +
                        "profile_image TEXT)");

        // === TABLE JASA ===
        db.execSQL(
                "CREATE TABLE jasa (" +
                        "id_jasa INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT, " +
                        "nama_jasa TEXT, " +
                        "deskripsi TEXT, " +
                        "harga TEXT, " +
                        "kategori TEXT, " +
                        "image_path TEXT)");

        // === TABLE PORTOFOLIO ===
        db.execSQL(
                "CREATE TABLE portofolio (" +
                        "id_portofolio INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT, " +
                        "judul TEXT, " +
                        "deskripsi TEXT, " +
                        "image_path TEXT)");

        // === TABLE ORDERS ===
        db.execSQL(
                "CREATE TABLE orders (" +
                        "id_order INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "client_username TEXT, " +
                        "freelancer_username TEXT, " +
                        "service_id INTEGER, " +
                        "service_name TEXT, " +
                        "status TEXT, " +
                        "notes TEXT, " +
                        "date TEXT, " +
                        "is_seen INTEGER DEFAULT 0, " +
                        "rating INTEGER DEFAULT 0, " +
                        "rating INTEGER DEFAULT 0, " +
                        "rating_seen INTEGER DEFAULT 0, " +
                        "result_file_path TEXT)");

        // === TABLE MESSAGES ===
        db.execSQL(
                "CREATE TABLE messages (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "sender TEXT, " +
                        "receiver TEXT, " +
                        "message TEXT, " +
                        "timestamp TEXT, " +
                        "is_read INTEGER DEFAULT 0, " +
                        "file_path TEXT, " +
                        "message_type TEXT)");

        // === TABLE REPORTS ===
        db.execSQL(
                "CREATE TABLE reports (" +
                        "id_report INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "reporter_username TEXT, " +
                        "reported_username TEXT, " +
                        "reason TEXT, " +
                        "timestamp TEXT)");

        // === TABLE FAVORITES ===
        db.execSQL(
                "CREATE TABLE favorites (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT, " +
                        "service_id INTEGER, " +
                        "timestamp TEXT)");

        // === TABLE SERVICE_VIEWS ===
        db.execSQL(
                "CREATE TABLE service_views (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "service_id INTEGER, " +
                        "viewer_username TEXT, " +
                        "timestamp TEXT)");

        // === TABLE REVIEWS ===
        db.execSQL(
                "CREATE TABLE reviews (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "order_id INTEGER, " +
                        "client_username TEXT, " +
                        "freelancer_username TEXT, " +
                        "service_id INTEGER, " +
                        "rating INTEGER, " +
                        "review_text TEXT, " +
                        "timestamp TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 3) {
            db.execSQL("DROP TABLE IF EXISTS jasa");
            db.execSQL(
                    "CREATE TABLE jasa (" +
                            "id_jasa INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "username TEXT, " +
                            "nama_jasa TEXT, " +
                            "deskripsi TEXT, " +
                            "harga TEXT, " +
                            "kategori TEXT)");
        }

        if (oldVersion < 4) {
            db.execSQL(
                    "CREATE TABLE portofolio (" +
                            "id_portofolio INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "username TEXT, " +
                            "judul TEXT, " +
                            "deskripsi TEXT, " +
                            "image_path TEXT)");
        }

        if (oldVersion < 6) {
            // Force recreate orders table to ensure correct schema
            db.execSQL("DROP TABLE IF EXISTS orders");
            db.execSQL(
                    "CREATE TABLE orders (" +
                            "id_order INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "client_username TEXT, " +
                            "freelancer_username TEXT, " +
                            "service_id INTEGER, " +
                            "service_name TEXT, " +
                            "status TEXT, " +
                            "notes TEXT, " +
                            "date TEXT)");
        }

        if (oldVersion < 7) {
            // Add profile_image column to users table
            try {
                db.execSQL("ALTER TABLE users ADD COLUMN profile_image TEXT");
            } catch (Exception e) {
                // Column might already exist if dev was testing, ignore
            }
        }

        if (oldVersion < 8) {
            // Add messages table
            db.execSQL(
                    "CREATE TABLE messages (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "sender TEXT, " +
                            "receiver TEXT, " +
                            "message TEXT, " +
                            "timestamp TEXT)");
        }

        if (oldVersion < 9) {
            // Add is_read column to messages table
            try {
                db.execSQL("ALTER TABLE messages ADD COLUMN is_read INTEGER DEFAULT 0");
            } catch (Exception e) {
                // Ignore if exists
            }
        }

        if (oldVersion < 10) {
            // Add is_seen column to orders table
            try {
                db.execSQL("ALTER TABLE orders ADD COLUMN is_seen INTEGER DEFAULT 0");
            } catch (Exception e) {
                // Ignore if exists
            }
        }

        if (oldVersion < 11) {
            // Add rating column to orders table
            try {
                db.execSQL("ALTER TABLE orders ADD COLUMN rating INTEGER DEFAULT 0");
            } catch (Exception e) {
                // Ignore
            }

            // Create reports table
            db.execSQL(
                    "CREATE TABLE reports (" +
                            "id_report INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "reporter_username TEXT, " +
                            "reported_username TEXT, " +
                            "reason TEXT, " +
                            "timestamp TEXT)");
        }

        if (oldVersion < 12) {
            // Add result_file_path column to orders table
            try {
                db.execSQL("ALTER TABLE orders ADD COLUMN result_file_path TEXT");
            } catch (Exception e) {
                // Ignore
            }
        }

        if (oldVersion < 13) {
            // Add file_path and message_type to messages table
            try {
                db.execSQL("ALTER TABLE messages ADD COLUMN file_path TEXT");
                db.execSQL("ALTER TABLE messages ADD COLUMN message_type TEXT");
            } catch (Exception e) {
                // Ignore
            }
        }

        if (oldVersion < 14) {
            // Add rating_seen column
            try {
                db.execSQL("ALTER TABLE orders ADD COLUMN rating_seen INTEGER DEFAULT 0");
            } catch (Exception e) {
                // Ignore
            }
        }

        if (oldVersion < 16) {
            // Add image_path column to jasa table (fix for missing v15 migration)
            try {
                db.execSQL("ALTER TABLE jasa ADD COLUMN image_path TEXT");
            } catch (Exception e) {
                // Ignore if exists
            }
        }

        if (oldVersion < 17) {
            // Profile Overhaul Columns
            try {
                db.execSQL("ALTER TABLE users ADD COLUMN full_name TEXT");
                db.execSQL("ALTER TABLE users ADD COLUMN phone_number TEXT");
                db.execSQL("ALTER TABLE users ADD COLUMN bio TEXT");
                db.execSQL("ALTER TABLE users ADD COLUMN skills TEXT");
                db.execSQL("ALTER TABLE users ADD COLUMN status TEXT DEFAULT 'active'");
                db.execSQL("ALTER TABLE users ADD COLUMN join_date TEXT");
                db.execSQL("ALTER TABLE users ADD COLUMN banner_image TEXT");
            } catch (Exception e) {
                // Ignore if specific column exists
            }
        }

        if (oldVersion < 18) {
            // Add new tables for enhanced features
            try {
                db.execSQL(
                        "CREATE TABLE IF NOT EXISTS favorites (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                "username TEXT, " +
                                "service_id INTEGER, " +
                                "timestamp TEXT)");

                db.execSQL(
                        "CREATE TABLE IF NOT EXISTS service_views (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                "service_id INTEGER, " +
                                "viewer_username TEXT, " +
                                "timestamp TEXT)");

                db.execSQL(
                        "CREATE TABLE IF NOT EXISTS reviews (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                "order_id INTEGER, " +
                                "client_username TEXT, " +
                                "freelancer_username TEXT, " +
                                "service_id INTEGER, " +
                                "rating INTEGER, " +
                                "review_text TEXT, " +
                                "timestamp TEXT)");

                // Add status column to jasa table
                db.execSQL("ALTER TABLE jasa ADD COLUMN status TEXT DEFAULT 'active'");

                // Add deadline column to orders table
                db.execSQL("ALTER TABLE orders ADD COLUMN deadline TEXT");
            } catch (Exception e) {
                // Ignore if exists
            }
        }
    }

    // ============================================================
    // USERS CRUD
    // ============================================================

    public boolean insertUser(String username, String email, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("email", email);
        cv.put("password", password);
        cv.put("role", role);
        return db.insert("users", null, cv) != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[] { username, password });
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public String getUserRole(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT role FROM users WHERE username=?",
                new String[] { username });

        if (cursor.moveToFirst()) {
            String role = cursor.getString(0);
            cursor.close();
            return role;
        }

        cursor.close();
        return null;
    }

    // Update Profile Image
    public boolean updateUserProfileImage(String username, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("profile_image", imageUri);
        return db.update("users", cv, "username=?", new String[] { username }) > 0;
    }

    public boolean checkEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE email=?",
                new String[] { email });
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean updatePassword(String email, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("password", newPassword);
        return db.update("users", cv, "email=?", new String[] { email }) > 0;
    }

    // Get Profile Image
    public String getUserProfileImage(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT profile_image FROM users WHERE username=?",
                new String[] { username });

        if (cursor.moveToFirst()) {
            String imagePath = cursor.getString(0);
            cursor.close();
            return imagePath;
        }

        cursor.close();
        return null;
    }

    // Update Banner Image
    public boolean updateUserBanner(String username, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("banner_image", imageUri);
        return db.update("users", cv, "username=?", new String[] { username }) > 0;
    }

    // Update Detailed Profile (Bio, Phone, Skills, Full Name)
    public boolean updateDetailedProfile(int id, String fullName, String phone, String bio, String skills) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("full_name", fullName);
        cv.put("phone_number", phone);
        cv.put("bio", bio);
        cv.put("skills", skills);
        return db.update("users", cv, "id=?", new String[] { String.valueOf(id) }) > 0;
    }

    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM users WHERE username=?", new String[] { username });
    }

    // ============================================================
    // CRUD JASA (FINAL BENAR)
    // ============================================================

    // CREATE (lengkap)
    public boolean insertJasaFull(String username, String nama, String harga, String kategori, String deskripsi,
            String imagePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("nama_jasa", nama);
        cv.put("deskripsi", deskripsi);
        cv.put("harga", harga);
        cv.put("kategori", kategori);
        cv.put("image_path", imagePath);
        return db.insert("jasa", null, cv) != -1;
    }

    // READ per freelancer
    public Cursor getJasaByUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM jasa WHERE username=?", new String[] { username });
    }

    // READ ALL (untuk Client)
    public Cursor getAllJasa() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM jasa", null);
    }

    // SEARCH JASA
    public Cursor searchJasa(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String q = "%" + query + "%";
        return db.rawQuery("SELECT * FROM jasa WHERE nama_jasa LIKE ? OR deskripsi LIKE ? OR kategori LIKE ?",
                new String[] { q, q, q });
    }

    // READ by ID
    public Cursor getJasaById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM jasa WHERE id_jasa=?", new String[] { String.valueOf(id) });
    }

    // UPDATE — versi lengkap dan benar
    public boolean updateJasa(int id, String nama, String deskripsi, String harga, String kategori, String imagePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("nama_jasa", nama);
        cv.put("deskripsi", deskripsi);
        cv.put("harga", harga);
        cv.put("kategori", kategori);
        if (imagePath != null) {
            cv.put("image_path", imagePath);
        }

        return db.update("jasa", cv, "id_jasa=?", new String[] { String.valueOf(id) }) > 0;
    }

    // DELETE
    public boolean deleteJasa(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("jasa", "id_jasa=?", new String[] { String.valueOf(id) }) > 0;
    }

    // ============================================================
    // CRUD PORTOFOLIO
    // ============================================================

    public boolean insertPortofolio(String username, String judul, String deskripsi, String imagePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("judul", judul);
        cv.put("deskripsi", deskripsi);
        cv.put("image_path", imagePath);
        return db.insert("portofolio", null, cv) != -1;
    }

    public Cursor getPortofolioByUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM portofolio WHERE username=?", new String[] { username });
    }

    public boolean updatePortofolio(int id, String judul, String deskripsi, String imagePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("judul", judul);
        cv.put("deskripsi", deskripsi);
        cv.put("image_path", imagePath);
        return db.update("portofolio", cv, "id_portofolio=?", new String[] { String.valueOf(id) }) > 0;
    }

    public boolean deletePortofolio(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("portofolio", "id_portofolio=?", new String[] { String.valueOf(id) }) > 0;
    }

    // ============================================================
    // CRUD ORDERS
    // ============================================================

    public boolean insertOrder(String clientUsername, String freelancerUsername, int serviceId, String serviceName,
            String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("client_username", clientUsername);
        cv.put("freelancer_username", freelancerUsername);
        cv.put("service_id", serviceId);
        cv.put("service_name", serviceName);
        cv.put("status", "Pending");
        cv.put("notes", notes);
        cv.put("date", String.valueOf(System.currentTimeMillis()));
        cv.put("is_seen", 0); // Default unseen
        cv.put("rating", 0); // Default no rating
        cv.put("rating_seen", 0); // Default unseen
        return db.insert("orders", null, cv) != -1;
    }

    public Cursor getOrdersByFreelancer(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE freelancer_username=?", new String[] { freelancerUsername });
    }

    public Cursor getOrdersByClient(String clientUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE client_username=?", new String[] { clientUsername });
    }

    public Cursor getAllOrders() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders", null);
    }

    public boolean updateOrderStatus(int id, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("status", status);
        return db.update("orders", cv, "id_order=?", new String[] { String.valueOf(id) }) > 0;
    }

    public Cursor getOrderById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE id_order=?", new String[] { String.valueOf(id) });
    }

    public boolean updateOrderResult(int id, String filePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("result_file_path", filePath);
        cv.put("is_seen", 0); // Reset is_seen so client gets notified
        cv.put("status", "Selesai"); // Fix: Mark as completed so logic detects it
        return db.update("orders", cv, "id_order=?", new String[] { String.valueOf(id) }) > 0;
    }

    public boolean updateOrderRating(int id, int rating) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("rating", rating);
        cv.put("rating_seen", 0); // Mark as unseen when rated so freelancer gets notified
        return db.update("orders", cv, "id_order=?", new String[] { String.valueOf(id) }) > 0;
    }

    public boolean deleteOrder(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("orders", "id_order=?", new String[] { String.valueOf(id) }) > 0;
    }

    public void markOrderAsSeen(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("is_seen", 1);
        db.update("orders", cv, "id_order=?", new String[] { String.valueOf(id) });
    }

    public void markRatingAsSeen(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("rating_seen", 1);
        db.update("orders", cv, "id_order=?", new String[] { String.valueOf(id) });
    }

    public int getUnseenOrdersCount(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM orders WHERE freelancer_username=? AND is_seen=0 AND status='Pending'",
                new String[] { freelancerUsername });
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getAllUnseenOrdersCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM orders WHERE is_seen=0 AND status='Pending'", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getUnseenCompletedOrdersCount(String clientUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM orders WHERE client_username=? AND status='Selesai' AND is_seen=0",
                new String[] { clientUsername });
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public Cursor getCompletedOrders(String clientUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM orders WHERE client_username=? AND status='Selesai' AND is_seen=0 ORDER BY date DESC",
                new String[] { clientUsername });
    }

    public Cursor getUnseenRatings(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Get orders where freelancer is the one, rating > 0, and rating_seen is 0
        return db.rawQuery(
                "SELECT * FROM orders WHERE freelancer_username=? AND rating > 0 AND rating_seen=0",
                new String[] { freelancerUsername });
    }

    public int getUnseenNotificationCount(String username, String role) {
        int count = 0;
        SQLiteDatabase db = this.getReadableDatabase();

        // 1. Unread Messages
        Cursor cursorMsg = db.rawQuery("SELECT COUNT(*) FROM messages WHERE receiver=? AND is_read=0",
                new String[] { username });
        if (cursorMsg.moveToFirst()) {
            count += cursorMsg.getInt(0);
        }
        cursorMsg.close();

        // 2. Unseen Orders / Ratings based on role
        if ("Freelancers".equalsIgnoreCase(role) || "freelancer".equalsIgnoreCase(role)) {
            // New Orders
            Cursor cursorOrders = db.rawQuery(
                    "SELECT COUNT(*) FROM orders WHERE freelancer_username=? AND is_seen=0 AND status='Pending'",
                    new String[] { username });
            if (cursorOrders.moveToFirst()) {
                count += cursorOrders.getInt(0);
            }
            cursorOrders.close();

            // New Ratings
            Cursor cursorRatings = db.rawQuery(
                    "SELECT COUNT(*) FROM orders WHERE freelancer_username=? AND rating > 0 AND rating_seen=0",
                    new String[] { username });
            if (cursorRatings.moveToFirst()) {
                count += cursorRatings.getInt(0);
            }
            cursorRatings.close();

        } else if ("Admin".equalsIgnoreCase(role)) {
            // All Pending Orders
            Cursor cursorOrders = db.rawQuery("SELECT COUNT(*) FROM orders WHERE is_seen=0 AND status='Pending'", null);
            if (cursorOrders.moveToFirst()) {
                count += cursorOrders.getInt(0);
            }
            cursorOrders.close();
        } else {
            // Client: Completed Orders
            Cursor cursorOrders = db.rawQuery(
                    "SELECT COUNT(*) FROM orders WHERE client_username=? AND status='Selesai' AND is_seen=0",
                    new String[] { username });
            if (cursorOrders.moveToFirst()) {
                count += cursorOrders.getInt(0);
            }
            cursorOrders.close();
        }

        return count;
    }

    // ============================================================
    // STATISTICS METHODS
    // ============================================================

    // Freelancer: Total Jasa
    public int getFreelancerServiceCount(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM jasa WHERE username=?", new String[] { username });
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // Freelancer: Total Orders
    public int getFreelancerOrderCount(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM orders WHERE freelancer_username=?",
                new String[] { username });
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // Freelancer: Average Rating
    public double getFreelancerAverageRating(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Only count orders that have a rating > 0
        Cursor cursor = db.rawQuery("SELECT AVG(rating) FROM orders WHERE freelancer_username=? AND rating > 0",
                new String[] { username });
        double rating = 0.0;
        if (cursor.moveToFirst()) {
            rating = cursor.getDouble(0);
        }
        cursor.close();
        return rating;
    }

    // Admin: Total Users
    public int getTotalUserCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM users", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // Admin: Total Orders
    public int getTotalOrderCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM orders", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // Admin: Active Services
    public int getActiveServiceCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM jasa", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // Admin: Reports
    public int getReportCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM reports", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // ============================================================
    // ADMIN: CRUD USERS
    // ============================================================

    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM users", null);
    }

    public boolean updateUser(int id, String username, String email, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("email", email);
        cv.put("role", role);
        return db.update("users", cv, "id=?", new String[] { String.valueOf(id) }) > 0;
    }

    public boolean deleteUser(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("users", "id=?", new String[] { String.valueOf(id) }) > 0;
    }

    // ============================================================
    // CHAT FEATURE
    // ============================================================

    public boolean insertMessage(String sender, String receiver, String message) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("sender", sender);
        cv.put("receiver", receiver);
        cv.put("message", message);
        cv.put("timestamp", String.valueOf(System.currentTimeMillis()));
        cv.put("is_read", 0); // Default unread
        cv.put("message_type", "text");
        return db.insert("messages", null, cv) != -1;
    }

    public boolean insertMessageWithFile(String sender, String receiver, String message, String filePath, String type) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("sender", sender);
        cv.put("receiver", receiver);
        cv.put("message", message); // Can be filename or description
        cv.put("timestamp", String.valueOf(System.currentTimeMillis()));
        cv.put("is_read", 0);
        cv.put("file_path", filePath);
        cv.put("message_type", type); // "image" or "file"
        return db.insert("messages", null, cv) != -1;
    }

    public Cursor getMessages(String user1, String user2) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Get messages where (sender=user1 AND receiver=user2) OR (sender=user2 AND
        // receiver=user1)
        // Ordered by timestamp ASC
        String query = "SELECT * FROM messages WHERE " +
                "(sender=? AND receiver=?) OR (sender=? AND receiver=?) " +
                "ORDER BY timestamp ASC";
        return db.rawQuery(query, new String[] { user1, user2, user2, user1 });
    }

    // Get list of users who have chatted with admin (or anyone)
    // For Admin: Get all unique senders who are NOT 'admin'
    public Cursor getChatUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        // This is a simple approach. In a real app, you might want distinct users from
        // both sender and receiver columns.
        // Assuming 'admin' is the fixed username for admin.
        String query = "SELECT DISTINCT sender FROM messages WHERE sender != 'admin'";
        return db.rawQuery(query, null);
    }

    public Cursor getLastMessage(String user1, String user2) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM messages WHERE " +
                "(sender=? AND receiver=?) OR (sender=? AND receiver=?) " +
                "ORDER BY timestamp DESC LIMIT 1";
        return db.rawQuery(query, new String[] { user1, user2, user2, user1 });
    }

    public boolean deleteChat(String user1, String user2) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete messages where (sender=user1 AND receiver=user2) OR (sender=user2 AND
        // receiver=user1)
        return db.delete("messages",
                "(sender=? AND receiver=?) OR (sender=? AND receiver=?)",
                new String[] { user1, user2, user2, user1 }) > 0;
    }

    // ============================================================
    // NOTIFICATIONS
    // ============================================================

    // Get unread messages count per sender for a receiver
    public Cursor getUnreadMessages(String receiver) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Returns: sender, count
        String query = "SELECT sender, COUNT(*) as count, MAX(timestamp) as timestamp FROM messages " +
                "WHERE receiver = ? AND is_read = 0 " +
                "GROUP BY sender ORDER BY timestamp DESC";
        return db.rawQuery(query, new String[] { receiver });
    }

    // Mark messages as read between two users
    public void markMessagesAsRead(String sender, String receiver) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("is_read", 1);
        db.update("messages", cv, "sender=? AND receiver=?", new String[] { sender, receiver });
    }

    // Get pending orders for freelancer
    public Cursor getPendingOrders(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE freelancer_username=? AND status='Pending' ORDER BY date DESC",
                new String[] { freelancerUsername });
    }

    // Get all pending orders (for Admin)
    public Cursor getAllPendingOrders() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE status='Pending' ORDER BY date DESC", null);
    }

    // ============================================================
    // FAVORITES
    // ============================================================

    public boolean addToFavorites(String username, int serviceId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if already favorited
        Cursor cursor = db.rawQuery("SELECT * FROM favorites WHERE username=? AND service_id=?",
                new String[] { username, String.valueOf(serviceId) });
        if (cursor.getCount() > 0) {
            cursor.close();
            return false; // Already favorited
        }
        cursor.close();

        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("service_id", serviceId);
        cv.put("timestamp", String.valueOf(System.currentTimeMillis()));
        return db.insert("favorites", null, cv) != -1;
    }

    public boolean removeFromFavorites(String username, int serviceId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("favorites", "username=? AND service_id=?",
                new String[] { username, String.valueOf(serviceId) }) > 0;
    }

    public Cursor getFavorites(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Join with jasa table to get service details
        String query = "SELECT j.* FROM jasa j " +
                "INNER JOIN favorites f ON j.id_jasa = f.service_id " +
                "WHERE f.username=? ORDER BY f.timestamp DESC";
        return db.rawQuery(query, new String[] { username });
    }

    public boolean isFavorite(String username, int serviceId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM favorites WHERE username=? AND service_id=?",
                new String[] { username, String.valueOf(serviceId) });
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // ============================================================
    // SERVICE VIEWS TRACKING
    // ============================================================

    public void incrementServiceViews(int serviceId, String viewerUsername) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("service_id", serviceId);
        cv.put("viewer_username", viewerUsername);
        cv.put("timestamp", String.valueOf(System.currentTimeMillis()));
        db.insert("service_views", null, cv);
    }

    public int getServiceViewCount(int serviceId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(DISTINCT viewer_username) FROM service_views WHERE service_id=?",
                new String[] { String.valueOf(serviceId) });
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // ============================================================
    // REVIEWS
    // ============================================================

    public boolean insertReview(int orderId, String clientUsername, String freelancerUsername,
            int serviceId, int rating, String reviewText) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("order_id", orderId);
        cv.put("client_username", clientUsername);
        cv.put("freelancer_username", freelancerUsername);
        cv.put("service_id", serviceId);
        cv.put("rating", rating);
        cv.put("review_text", reviewText);
        cv.put("timestamp", String.valueOf(System.currentTimeMillis()));
        return db.insert("reviews", null, cv) != -1;
    }

    public Cursor getReviewsByService(int serviceId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM reviews WHERE service_id=? ORDER BY timestamp DESC",
                new String[] { String.valueOf(serviceId) });
    }

    public Cursor getReviewsByFreelancer(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM reviews WHERE freelancer_username=? ORDER BY timestamp DESC",
                new String[] { freelancerUsername });
    }

    public double getServiceAverageRating(int serviceId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT AVG(rating) FROM reviews WHERE service_id=?",
                new String[] { String.valueOf(serviceId) });
        double rating = 0.0;
        if (cursor.moveToFirst()) {
            rating = cursor.getDouble(0);
        }
        cursor.close();
        return rating;
    }

    // ============================================================
    // SERVICE STATUS & FILTERING
    // ============================================================

    public boolean updateServiceStatus(int serviceId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("status", status);
        return db.update("jasa", cv, "id_jasa=?", new String[] { String.valueOf(serviceId) }) > 0;
    }

    public Cursor getActiveServices() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM jasa WHERE status='active' OR status IS NULL", null);
    }

    public Cursor getServicesByCategory(String category) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM jasa WHERE kategori=? AND (status='active' OR status IS NULL)",
                new String[] { category });
    }

    public Cursor getServicesByPriceRange(int minPrice, int maxPrice) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM jasa WHERE CAST(harga AS INTEGER) BETWEEN ? AND ? AND (status='active' OR status IS NULL)",
                new String[] { String.valueOf(minPrice), String.valueOf(maxPrice) });
    }

    public Cursor searchServicesAdvanced(String query, String category, Integer minPrice, Integer maxPrice) {
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder queryBuilder = new StringBuilder("SELECT * FROM jasa WHERE (status='active' OR status IS NULL)");
        java.util.ArrayList<String> args = new java.util.ArrayList<>();

        if (query != null && !query.isEmpty()) {
            queryBuilder.append(" AND (nama_jasa LIKE ? OR deskripsi LIKE ?)");
            String q = "%" + query + "%";
            args.add(q);
            args.add(q);
        }

        if (category != null && !category.isEmpty() && !category.equals("Semua")) {
            queryBuilder.append(" AND kategori=?");
            args.add(category);
        }

        if (minPrice != null && maxPrice != null) {
            queryBuilder.append(" AND CAST(harga AS INTEGER) BETWEEN ? AND ?");
            args.add(String.valueOf(minPrice));
            args.add(String.valueOf(maxPrice));
        }

        return db.rawQuery(queryBuilder.toString(), args.toArray(new String[0]));
    }

    // ============================================================
    // EARNINGS CALCULATION
    // ============================================================

    public double calculateTotalEarnings(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(CAST(j.harga AS REAL)) FROM orders o " +
                        "INNER JOIN jasa j ON o.service_id = j.id_jasa " +
                        "WHERE o.freelancer_username=? AND o.status='Selesai'",
                new String[] { freelancerUsername });
        double total = 0.0;
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(0);
        }
        cursor.close();
        return total;
    }

    public Cursor getEarningsHistory(String freelancerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT o.*, j.harga FROM orders o " +
                        "INNER JOIN jasa j ON o.service_id = j.id_jasa " +
                        "WHERE o.freelancer_username=? AND o.status='Selesai' " +
                        "ORDER BY o.date DESC",
                new String[] { freelancerUsername });
    }

    // ============================================================
    // ADMIN: SEARCH & FILTER USERS
    // ============================================================

    public Cursor searchUsers(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String q = "%" + query + "%";
        return db.rawQuery("SELECT * FROM users WHERE username LIKE ? OR email LIKE ? OR role LIKE ?",
                new String[] { q, q, q });
    }

    public Cursor getUsersByRole(String role) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM users WHERE role=?", new String[] { role });
    }

    public boolean bulkDeleteUsers(int[] userIds) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int id : userIds) {
                db.delete("users", "id=?", new String[] { String.valueOf(id) });
            }
            db.setTransactionSuccessful();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            db.endTransaction();
        }
    }

    public Cursor searchOrders(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String q = "%" + query + "%";
        return db.rawQuery(
                "SELECT * FROM orders WHERE client_username LIKE ? OR freelancer_username LIKE ? OR service_name LIKE ? OR status LIKE ?",
                new String[] { q, q, q, q });
    }

    // ============================================================
    // ADMIN: ORDER FILTERING
    // ============================================================

    public Cursor getOrdersByStatus(String status) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE status=? ORDER BY date DESC",
                new String[] { status });
    }

    public Cursor getOrdersByDateRange(long startDate, long endDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE CAST(date AS INTEGER) BETWEEN ? AND ? ORDER BY date DESC",
                new String[] { String.valueOf(startDate), String.valueOf(endDate) });
    }

    public double getTotalRevenue() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(CAST(j.harga AS REAL)) FROM orders o " +
                        "INNER JOIN jasa j ON o.service_id = j.id_jasa " +
                        "WHERE o.status='Selesai'",
                null);
        double total = 0.0;
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(0);
        }
        cursor.close();
        return total;
    }

    // ============================================================
    // GET TOP FREELANCERS
    // ============================================================

    public Cursor getTopFreelancers(int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Get freelancers with their average rating, ordered by rating DESC
        // Also fetch profile_image, phone_number, and email
        String query = "SELECT u.username, u.skills, u.profile_image, u.phone_number, u.email, " +
                "COALESCE(AVG(o.rating), 0) as avg_rating, " +
                "COUNT(o.id_order) as order_count " +
                "FROM users u " +
                "LEFT JOIN orders o ON u.username = o.freelancer_username AND o.rating > 0 " +
                "WHERE u.role = 'Freelancers' " +
                "GROUP BY u.username " +
                "ORDER BY avg_rating DESC, order_count DESC " +
                "LIMIT ?";
        return db.rawQuery(query, new String[] { String.valueOf(limit) });
    }

    // ============================================================
    // ADMIN: RECENT ACTIVITIES
    // ============================================================

    public Cursor getRecentUsers(int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Get recent users ordered by ID (assuming newer users have higher IDs)
        return db.rawQuery("SELECT * FROM users ORDER BY id DESC LIMIT ?",
                new String[] { String.valueOf(limit) });
    }

    public Cursor getRecentOrders(int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Get recent orders ordered by date DESC
        return db.rawQuery("SELECT * FROM orders ORDER BY date DESC LIMIT ?",
                new String[] { String.valueOf(limit) });
    }
}
